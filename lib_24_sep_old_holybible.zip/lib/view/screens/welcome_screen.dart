import 'package:biblebookapp/view/constants/images.dart';
import 'package:biblebookapp/view/screens/onboard_faith_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isTablet = size.width > 600; // Simple check for iPad vs iPhone

    return Scaffold(
      body: Container(
        width: size.width,
        height: size.height,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                Images.bgImage(context)), // your parchment background
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal:
                  isTablet ? size.width * 0.2 : 15, // wider margin for iPad
            ),
            child: SafeArea(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Title
                  Text(
                    "Welcome!",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: isTablet ? 34 : 30,
                      fontWeight: FontWeight.w500,
                      color: Colors.black87,
                    ),
                  ),

                  SizedBox(height: isTablet ? 20 : 12),

                  // Subtitle
                  Text(
                    "We're thankful you're here.\nLet's personalize your Bible experience\n"
                    "to make your journey more meaningful.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: isTablet ? 20 : 17,
                      height: 1.5,
                      color: Colors.black87,
                    ),
                  ),

                  SizedBox(height: isTablet ? 16 : 10),

                  // Italic line
                  Text(
                    "Just a few quick steps to get started.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: isTablet ? 18 : 15,
                      fontStyle: FontStyle.italic,
                      color: Colors.black87,
                    ),
                  ),

                  SizedBox(height: isTablet ? 40 : 24),

                  // Button
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 65),
                    child: SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF7B5C3D),
                          padding: EdgeInsets.symmetric(
                            vertical: isTablet ? 20 : 14,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        onPressed: () {
                          // Navigate next
                          Get.offAll(() => const FaithOnboardingScreen());
                        },
                        child: Text(
                          "Let's Start..",
                          style: TextStyle(
                            fontSize: isTablet ? 20 : 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
