import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:archive/archive.dart';

class BibleVersionsScreen extends StatefulWidget {
  const BibleVersionsScreen({super.key});

  @override
  BibleVersionsScreenState createState() => BibleVersionsScreenState();
}

class BibleVersionsScreenState extends State<BibleVersionsScreen> {
  List<String> zipFiles = [];
  final Map<String, String> buttonStates =
      {}; // fileName -> "Download", "Downloading", "Open"

  @override
  void initState() {
    super.initState();
    _loadZipFiles();
  }

  Future<void> _loadZipFiles() async {
    final manifestContent = await rootBundle.loadString('AssetManifest.json');
    final Map<String, dynamic> manifestMap = json.decode(manifestContent);

    final files = manifestMap.keys
        .where((path) =>
            path.startsWith("assets/zipped/") && path.endsWith(".zip"))
        .toList();

    setState(() {
      zipFiles = files.map((e) => e.split("/").last).toList(); // only filenames
      for (var f in zipFiles) {
        buttonStates[f] = "Download";
      }
    });
  }

  Future<void> extractZip(String assetName, String password) async {
    setState(() {
      buttonStates[assetName] = "Downloading...";
    });

    try {
      // Load main zip file
      final byteData = await rootBundle.load("assets/zipped/$assetName");
      final bytes = byteData.buffer.asUint8List();

      // Prepare output directory
      final dir = await getApplicationDocumentsDirectory();
      final outDir = Directory("${dir.path}/$assetName-extracted");
      if (!outDir.existsSync()) outDir.createSync(recursive: true);

      // Decode main zip
      final archive = ZipDecoder().decodeBytes(bytes);
      for (final file in archive) {
        final filename = file.name;
        final outFile = File("${outDir.path}/$filename");

        if (file.isFile) {
          await outFile.writeAsBytes(file.content);
        } else {
          outFile.createSync(recursive: true);
        }

        // If nested zips found (book.json.zip / verse_json.zip)
        if (filename == "book.json.zip" || filename == "verse_json.zip") {
          final innerBytes = outFile.readAsBytesSync();

          // ⚠️ Archive package doesn't support password → for real use, switch to flutter_archive
          final innerArchive = ZipDecoder().decodeBytes(innerBytes);
          for (final innerFile in innerArchive) {
            final innerOut = File("${outDir.path}/${innerFile.name}");
            await innerOut.writeAsBytes(innerFile.content);
          }
        }
      }

      setState(() {
        buttonStates[assetName] = "Open";
      });
    } catch (e) {
      print("Error extracting $assetName: $e");
      setState(() {
        buttonStates[assetName] = "Download";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Bible versions")),
      body: zipFiles.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: zipFiles.length,
              itemBuilder: (context, index) {
                final file = zipFiles[index];
                final state = buttonStates[file] ?? "Download";

                return ListTile(
                  title: Text(file.replaceAll(".zip", "")),
                  trailing: ElevatedButton(
                    onPressed: state == "Download"
                        ? () => extractZip(file, "YOUR_PASSWORD")
                        : state == "Open"
                            ? () {
                                // TODO: Navigate to extracted Bible data
                              }
                            : null,
                    child: Text(state),
                  ),
                );
              },
            ),
    );
  }
}
