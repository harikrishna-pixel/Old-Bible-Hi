import 'package:biblebookapp/controller/api_service.dart';
import 'package:biblebookapp/utils/book_apps_helper.dart';
import 'package:biblebookapp/view/screens/books/model/book_model.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

final bookBloc = ChangeNotifierProvider<BookBloc>((ref) => BookBloc());

class BookBloc extends ChangeNotifier {
  BookBloc();

  int currentPage = 1;
  bool isLastPage = false;
  bool isLoading = false;
  List<BookModel> books = [];

  Future getBooks(int id) async {
    try {
      if (!isLoading && !isLastPage) {
        isLoading = true;
        customNotifyListeners();
        final data = await getBookCategories(id);
        if (data.isEmpty) {
          isLastPage = true;
        }
        books = [];
        books.addAll(data);
        currentPage++;
        isLoading = false;
        await StorageHelper.saveBooksAndApps(books: books);
        customNotifyListeners();
      }
    } catch (e, _) {
      isLoading = false;
      customNotifyListeners();
      rethrow;
    }
  }

  // to indicate whether the state provider is disposed or not
  bool _isDisposed = false;

  // use the notifyListeners as below
  customNotifyListeners() {
    if (!_isDisposed) {
      notifyListeners();
    }
  }

  @override
  void dispose() {
    super.dispose();
    _isDisposed = true;
  }
}
