import 'dart:async';
import 'dart:io';

import 'package:biblebookapp/Model/product_details_model.dart' as m;
import 'package:biblebookapp/controller/api_service.dart';
import 'package:biblebookapp/controller/dashboard_controller.dart';
import 'package:biblebookapp/utils/debugprint.dart';
import 'package:biblebookapp/view/constants/colors.dart';
import 'package:biblebookapp/view/constants/constant.dart';
import 'package:biblebookapp/view/constants/images.dart';
import 'package:biblebookapp/view/constants/share_preferences.dart';
import 'package:biblebookapp/view/screens/dashboard/constants.dart';
import 'package:biblebookapp/view/screens/dashboard/home_screen.dart';
import 'package:biblebookapp/view/screens/dashboard/remove_add-screen.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_storekit/in_app_purchase_storekit.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../core/notifiers/download.notifier.dart';

final List<PurchaseDetails> _purchases = [];

class SubscriptionScreen extends StatefulWidget {
  final String sixMonthPlan;
  final String oneYearPlan;
  final String lifeTimePlan;
  final String checkad;

  const SubscriptionScreen({
    super.key,
    required this.sixMonthPlan,
    required this.oneYearPlan,
    required this.lifeTimePlan,
    required this.checkad,
  });

  @override
  State<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends State<SubscriptionScreen> {
  bool isPurchaseLoading = false;
  bool isRestoreLoading = false;
  bool userTap = false;
  int selectedindex = 0;
  List<ProductDetails> _products = [];

  DownloadProvider? _myProvider;
//// In App Purchase
  final InAppPurchase _inAppPurchase = InAppPurchase.instance;
// subscription that listens to a stream of updates to purchase details
  StreamSubscription<List<PurchaseDetails>>? _subscription;

  bool _isAvailable = false;

  // checks if a user has purchased a certain product
  PurchaseDetails? _hasUserPurchased(String productID) {
    return null;
  }

  Future<void> _buyProduct(ProductDetails prod) async {
    final connectivityResult = await Connectivity().checkConnectivity();
    if (connectivityResult[0] == ConnectivityResult.none) {
      Constants.showToast("Check your Internet connection");
    }
    if (!userTap) {
      debugPrint("Buy Product");
      try {
        setState(() {
          userTap = true;
        });
        EasyLoading.show();
        await SharPreferences.setString('OpenAd', '1');
        final PurchaseParam purchaseParam = PurchaseParam(productDetails: prod);
        _inAppPurchase.buyNonConsumable(purchaseParam: purchaseParam);
      } catch (e) {
        debugPrint('Error: $e');
      }
    }
  }

  Future<void> _verifyPurchases() async {
    PurchaseDetails? purchase = _hasUserPurchased('');
    if (purchase != null && purchase.status == PurchaseStatus.purchased) {}
  }

  restorePurchaseHandle(
      String productId, String date, DashBoardController controller) async {
    await SharPreferences.setString('OpenAd', '1');
    final dateTime = DateTime.tryParse(date) ?? DateTime.now();
    await Future.delayed(Duration(seconds: 2));
    final data = await SharPreferences.getBoolean('restorepurches');
    debugPrint("restore data 1 is $data");
    if (data == true) {
      if (productId == widget.lifeTimePlan) {
        await controller.disableAd(const Duration(days: 3650012345));
        await Future.delayed(Duration(seconds: 1));
        EasyLoading.dismiss();
        await SharPreferences.setBoolean('closead', true);
        return Get.offAll(() => HomeScreen(
              From: "premium",
              selectedVerseNumForRead: "",
              selectedBookForRead: "",
              selectedChapterForRead: "",
              selectedBookNameForRead: "",
              selectedVerseForRead: "",
            ));
      } else if (productId == widget.oneYearPlan) {
        final dur = DateTime(dateTime.year + 1, dateTime.month, dateTime.day);
        final diff = dur.difference(DateTime.now());
        await controller.disableAd(diff);
        await Future.delayed(Duration(seconds: 1));
        EasyLoading.dismiss();
        await SharPreferences.setBoolean('closead', true);
        return Get.offAll(() => HomeScreen(
              From: "premium",
              selectedVerseNumForRead: "",
              selectedBookForRead: "",
              selectedChapterForRead: "",
              selectedBookNameForRead: "",
              selectedVerseForRead: "",
            ));
      } else if (productId == widget.sixMonthPlan) {
        final dur = addSixMonths(customDate: dateTime);
        final diff = dur.difference(DateTime.now());
        await controller.disableAd(diff);
        await Future.delayed(Duration(seconds: 1));
        EasyLoading.dismiss();
        await SharPreferences.setBoolean('closead', true);
        return Get.offAll(() => HomeScreen(
              From: "premium",
              selectedVerseNumForRead: "",
              selectedBookForRead: "",
              selectedChapterForRead: "",
              selectedBookNameForRead: "",
              selectedVerseForRead: "",
            ));
      }
    }
    // final InAppPurchaseStoreKitPlatformAddition iosPlatformAddition =
    //     _inAppPurchase
    //         .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
    // await iosPlatformAddition.setDelegate(null);
    // await _subscription?.cancel();

    // await Future.delayed(Duration(seconds: 1));
    // EasyLoading.dismiss();
    // await SharPreferences.setBoolean('closead', true);
    // Get.back();
    // return Get.offAll(() => HomeScreen(
    //       From: "premium",
    //       selectedVerseNumForRead: "",
    //       selectedBookForRead: "",
    //       selectedChapterForRead: "",
    //       selectedBookNameForRead: "",
    //       selectedVerseForRead: "",
    //     ));
  }

  void _listenToPurchaseUpdated(List<PurchaseDetails> purchaseDetailsList,
      DashBoardController controller) {
    // ignore: avoid_function_literals_in_foreach_calls
    purchaseDetailsList.forEach((PurchaseDetails purchaseDetails) async {
      debugPrint("Purchase State: ${purchaseDetails.status}");
      await SharPreferences.setString('OpenAd', '1');
      if (purchaseDetails.status == PurchaseStatus.pending) {
      } else {
        setState(() {
          userTap = false;
        });

        if (purchaseDetails.status == PurchaseStatus.error) {
          debugPrint('Error: ${purchaseDetails.error}');
          DebugConsole.log(" purchases error - $purchaseDetails");
        } else if (purchaseDetails.status == PurchaseStatus.purchased ||
            purchaseDetails.status == PurchaseStatus.restored) {
          if (purchaseDetails.status == PurchaseStatus.purchased) {
            if (Platform.isIOS) {
              //  var response =
              http.post(
                Uri.parse(kDebugMode
                    ? 'https://sandbox.itunes.apple.com/verifyReceipt'
                    : 'https://buy.itunes.apple.com/verifyReceipt'),
                headers: {
                  'Accept': 'application/json',
                  'Content-Type': 'application/json',
                },
                body: {
                  'receipt-data':
                      purchaseDetails.verificationData.localVerificationData,
                  'exclude-old-transactions': true,
                  'password': controller.sharedSecret
                },
              );

              // DebugConsole.log(
              //     "  purchases sucess frist : ${purchaseDetails.purchaseID}-productId:${purchaseDetails.productID}-date:${DateTime.now()} - ${response.body}");

              // final data = parseHtmlAndExtractJson(response.body);
              await Future.delayed(Duration(seconds: 1));
              // DebugConsole.log(" purchases sucess - $data");
              await purchaseSubmit(
                  receiptData:
                      '${purchaseDetails.purchaseID}-productId:${purchaseDetails.productID}-date:${DateTime.now()}');
              final todayDate = DateTime.now();
              await SharPreferences.setBoolean("downloadreward", true);
              await Future.delayed(Duration(seconds: 1));
              if (purchaseDetails.productID == widget.sixMonthPlan) {
                final expiryDate = addSixMonths();
                final diff = expiryDate.difference(todayDate);
                await controller.disableAd(diff);
                await Future.delayed(Duration(seconds: 2));
                EasyLoading.dismiss();
                await SharPreferences.setBoolean('closead', true);
                debugPrint("restore data 2");
                return Get.offAll(() => HomeScreen(
                      From: "premium",
                      selectedVerseNumForRead: "",
                      selectedBookForRead: "",
                      selectedChapterForRead: "",
                      selectedBookNameForRead: "",
                      selectedVerseForRead: "",
                    ));
              } else if (purchaseDetails.productID == widget.oneYearPlan) {
                await controller.disableAd(const Duration(days: 366));
                await Future.delayed(Duration(seconds: 2));
                EasyLoading.dismiss();
                await SharPreferences.setBoolean('closead', true);
                debugPrint("restore data 3 ");
                return Get.offAll(() => HomeScreen(
                      From: "premium",
                      selectedVerseNumForRead: "",
                      selectedBookForRead: "",
                      selectedChapterForRead: "",
                      selectedBookNameForRead: "",
                      selectedVerseForRead: "",
                    ));
              } else if (purchaseDetails.productID == widget.lifeTimePlan) {
                await controller.disableAd(const Duration(days: 3650012345));
                await Future.delayed(Duration(seconds: 2));
                EasyLoading.dismiss();
                await SharPreferences.setBoolean('closead', true);
                debugPrint("restore data 4 ");
                return Get.offAll(() => HomeScreen(
                      From: "premium",
                      selectedVerseNumForRead: "",
                      selectedBookForRead: "",
                      selectedChapterForRead: "",
                      selectedBookNameForRead: "",
                      selectedVerseForRead: "",
                    ));
              }
            }
          } else if (purchaseDetails.status == PurchaseStatus.restored) {
            setState(() {
              isRestoreLoading = false;
            });
            EasyLoading.dismiss();
            final data = await SharPreferences.getBoolean('restorepurches');
            debugPrint("restore data 5 is $data");
            if (data == true) {
              debugPrint("restore data 6 is $data");
              await restorePurchaseHandle(purchaseDetails.productID,
                  purchaseDetails.transactionDate ?? '', controller);
            }
          }
        } else if (purchaseDetails.pendingCompletePurchase) {
          await InAppPurchase.instance.completePurchase(purchaseDetails);
          EasyLoading.dismiss();
        } else if (purchaseDetails.status == PurchaseStatus.canceled) {
          EasyLoading.dismiss();
          Constants.showToast('Something went wrong');
        }
      }
    });
  }

  _initialize() async {
    await SharPreferences.setBoolean('closead', false);
    await SharPreferences.setString('OpenAd', '1');

    // Provider.of<DownloadProvider>(context, listen: false).disableAd();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _myProvider = Provider.of<DownloadProvider>(context, listen: false);
      _myProvider?.disableAd();
    });
    if (mounted) {
      setState(() {
        isPurchaseLoading = true;
      });
    }
    // Check availability of InApp Purchases
    _isAvailable = await _inAppPurchase.isAvailable();
    debugPrint('Is Available: $_isAvailable');
    // perform our async calls only when in-app purchase is available
    if (_isAvailable) {
      await _getUserProducts();
      // _verifyPurchases();

      // listen to new purchases and rebuild the widget whenever
      // there is a new purchase after adding the new purchase to our
      // purchase list
      if (mounted) {
        setState(() {
          isPurchaseLoading = false;
        });
      }
    } else {
      if (mounted) {
        setState(() {
          isPurchaseLoading = false;
        });
      }
    }
  }

  Future<void> _getUserProducts() async {
    // setState(() {});
    await SharPreferences.setBoolean('closead', false);
    final productprovider =
        Provider.of<DownloadProvider>(context, listen: false);

    if (Platform.isIOS) {
      final InAppPurchaseStoreKitPlatformAddition iosPlatformAddition =
          _inAppPurchase
              .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
      await iosPlatformAddition.setDelegate(ExamplePaymentQueueDelegate());

      Set<String> ids = {
        widget.sixMonthPlan,
        widget.oneYearPlan,
        widget.lifeTimePlan
      };

      debugPrint(
          "all plans - $ids  ${_products.isEmpty}  ${await _inAppPurchase.queryProductDetails(ids)}");
      final datafn = await productprovider.loadProductList();

      final datacheck = datafn.map((data) {
        return ProductDetails(
          id: data.id,
          title: data.title,
          description: data.description,
          price: data.price,
          rawPrice: data.rawPrice,
          currencyCode: data.currencyCode,
          currencySymbol: data.currencySymbol,
        );
      }).toList();

      if (_products.isEmpty && datacheck.isEmpty) {
        ProductDetailsResponse response =
            await _inAppPurchase.queryProductDetails(ids);
        debugPrint(
            "all plans product 1 - ${response.error} ${response.notFoundIDs} ${response.productDetails}  ");
        await Future.delayed(Duration(seconds: 10));

        await productprovider
            .saveProductList(response.productDetails.map((iapProduct) {
          return m.ProductDetails(
            id: iapProduct.id,
            title: iapProduct.title,
            description: iapProduct.description,
            price: iapProduct.price,
            rawPrice: iapProduct.rawPrice,
            currencyCode: iapProduct.currencyCode,
            currencySymbol: iapProduct.currencySymbol,
          );
        }).toList());
        setState(() {
          _products = response.productDetails;
          _products.sort((a, b) => a.price.compareTo(b.price));
        });
      } else {
        // ProductDetailsResponse response =
        //     await _inAppPurchase.queryProductDetails(ids);
        //  await Future.delayed(Duration(seconds: 1));
        final data = await productprovider.loadProductList();

        setState(() {
          _products = data.map((data) {
            return ProductDetails(
              id: data.id,
              title: data.title,
              description: data.description,
              price: data.price,
              rawPrice: data.rawPrice,
              currencyCode: data.currencyCode,
              currencySymbol: data.currencySymbol,
            );
          }).toList();
          _products.sort((a, b) => a.price.compareTo(b.price));
        });
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _initialize();
    // WidgetsBinding.instance.addObserver(this);
    debugPrint("iap ad - WidgetsBinding");
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      _subscription = _inAppPurchase.purchaseStream.listen((data) {
        final controller = Get.find<DashBoardController>();
        _listenToPurchaseUpdated(data, controller);
        setState(() {
          _purchases.addAll(data);
          _verifyPurchases();
        });
      });
    });
    // _loadRewardedAd();
  }

  @override
  void dispose() {
    debugPrint("iap ad - dispose");

    // Call async clean-up without awaiting
    alldispose();

    super.dispose();
  }

  void alldispose() async {
    if (Platform.isIOS) {
      final InAppPurchaseStoreKitPlatformAddition iosPlatformAddition =
          _inAppPurchase
              .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
      await iosPlatformAddition.setDelegate(null);
      await _subscription?.cancel();
    }
  }

  double calculateOriginalPrice(
      double discountPercent, double discountedPrice) {
    // Convert the discount percentage to a fraction
    double discountFraction = discountPercent / 100;

    // Calculate the original price using the formula: original price = discounted price / (1 - discount fraction)
    double originalPrice = discountedPrice / (1 - discountFraction);

    return originalPrice;
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final controller =
        Get.put(DashBoardController()); // Initialize controller here
    //final controller = Get.find<DashBoardController>();

    // Move these helper functions outside the builder
    double? fakeOffer(ProductDetails product) {
      if (product.id == widget.sixMonthPlan) {
        return double.tryParse(controller.sixMonthPlanValue ?? '');
      }
      if (product.id == widget.oneYearPlan) {
        return double.tryParse(controller.oneYearPlanValue ?? '');
      }
      if (product.id == widget.lifeTimePlan) {
        return double.tryParse(controller.lifeTimePlanValue ?? '');
      }
      return null;
    }

    String getDiscountedPrice(ProductDetails product) {
      final fakeOfferPercentage = fakeOffer(product);
      if (fakeOfferPercentage != null) {
        final fakePrice =
            calculateOriginalPrice(fakeOfferPercentage, product.rawPrice);
        return '${product.currencySymbol}${fakePrice.toStringAsFixed(2)}';
      }
      return '';
    }

    // Setup purchase stream listener once
    // WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
    //   _subscription = _inAppPurchase.purchaseStream.listen((data) {
    //     _listenToPurchaseUpdated(data, controller);
    //     // Use controller update instead of setState
    //     setState(() {
    //       _purchases.addAll(data);
    //       _verifyPurchases();
    //     });
    //   });
    // });

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;

        if (_myProvider != null) {
          _myProvider?.enableAd();
        }
        await SharPreferences.setBoolean('closead', true);
        Get.offAll(() => HomeScreen(
              From: "splash",
              selectedVerseNumForRead: "",
              selectedBookForRead: "",
              selectedChapterForRead: "",
              selectedBookNameForRead: "",
              selectedVerseForRead: "",
            ));
      },
      child: Scaffold(
        body: Container(
          width: size.width,
          height: size.height,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(Images.bgImage(context)), // background texture
              fit: BoxFit.cover,
            ),
          ),
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
            ),
            child: SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Top bar
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.close, color: Colors.black),
                        onPressed: () async {
                          if (_myProvider != null) {
                            _myProvider?.enableAd();
                          }
                          await SharPreferences.setBoolean('closead', true);
                          return Get.offAll(() => HomeScreen(
                                From: "splash",
                                selectedVerseNumForRead: "",
                                selectedBookForRead: "",
                                selectedChapterForRead: "",
                                selectedBookNameForRead: "",
                                selectedVerseForRead: "",
                              ));
                        },
                      ),
                      TextButton(
                        onPressed: () async {
                          await SharPreferences.setBoolean(
                              'restorepurches', true);
                          await _inAppPurchase.restorePurchases();
                          setState(() {
                            isRestoreLoading = true;
                          });
                          await Future.delayed(Duration(seconds: 7));
                          try {
                            final res = await restorePurchase();
                            if (res['status'] == 'success') {
                              final rawData =
                                  res['data'].toString().split('-productId:');
                              if (rawData.length == 2) {
                                final data = rawData[1].split('-date:');
                                final productId = data[0].toString();
                                final date = data[1].toString();
                                await restorePurchaseHandle(
                                    productId, date, controller);
                                Constants.showToast('Restore Successful');
                              }
                            } else {
                              Constants.showToast(
                                  'No active subscription available');
                            }
                          } catch (e) {
                            Constants.showToast(
                                ' error No active subscription available');

                            DebugConsole.log(
                                "restore No active subscription available error - $e");
                          }
                          setState(() {
                            isRestoreLoading = false;
                          });
                        },
                        child: const Text(
                          "Restore Purchases",
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: size.height * 0.002),

                  // Jesus Image
                  Image.asset(
                    "assets/offer/jesus.png", // Replace with your image
                    height: size.height * 0.14,
                    fit: BoxFit.contain,
                  ),

                  const SizedBox(height: 6),

                  // Title
                  const Text(
                    "Get Closer to God with the Ultimate Bible Experience",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),

                  const SizedBox(height: 12),

                  // Features list
                  _buildFeatureItem(
                      "assets/offer/fe1.png", "Distraction-Free Bible reading"),
                  _buildFeatureItem("assets/offer/fe2.png",
                      "Get verses for what you're feeling"),
                  _buildFeatureItem(
                      "assets/offer/fe3.png", "Access all stylish themes"),
                  _buildFeatureItem(
                      "assets/offer/fe4.png", "Backup and restore your data"),
                  _buildFeatureItem(
                      "assets/offer/fe5.png", "Explore 15+ versions instantly"),

                  const SizedBox(height: 17),

                  // Choose plan text
                  const Text(
                    "CHOOSE A PLAN",
                    style: TextStyle(
                        fontWeight: FontWeight.bold, letterSpacing: 1.2),
                  ),
                  const SizedBox(height: 5),
                  const Text(
                    "Try All Features Free for 3 Days",
                    style: TextStyle(color: Colors.black54),
                  ),

                  const SizedBox(height: 6),

                  // Six months plan
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: isPurchaseLoading
                        ? Padding(
                            padding: const EdgeInsets.only(top: 12),
                            child: SizedBox(
                                height: 100,
                                width: 200,
                                child: Center(
                                    child: Column(
                                  children: [
                                    const CircularProgressIndicator.adaptive(),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text('Please wait...',
                                          style:
                                              CommanStyle.appBarStyle(context)
                                                  .copyWith(fontSize: 12)),
                                    )
                                  ],
                                ))),
                          )
                        : _products.isEmpty
                            ? Center(
                                child: Text(
                                  "We're unable to load subscription options right now.\n Please try again later",
                                  style: CommanStyle.appBarStyle(context)
                                      .copyWith(fontSize: 12),
                                  textAlign: TextAlign.center,
                                ),
                              )
                            : MediaQuery.removePadding(
                                context: context,
                                removeTop: true,
                                child: ListView.builder(
                                  shrinkWrap: true,
                                  padding: EdgeInsets.zero,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemCount: _products.length,
                                  itemBuilder: (context, index) {
                                    return InkWell(
                                      onTap: () async {
                                        // await SharPreferences.setString(
                                        //     'OpenAd', '1');
                                        // _buyProduct(_products[index]);
                                        setState(() {
                                          selectedindex = index;
                                        });
                                      },
                                      child: Stack(
                                        alignment: Alignment.topRight,
                                        children: [
                                          Container(
                                            margin: const EdgeInsets.symmetric(
                                                horizontal: 16, vertical: 8),
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 16, vertical: 12),
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: selectedindex == index
                                                      ? Colors.brown
                                                      : const Color.fromARGB(
                                                          156, 158, 158, 158),
                                                  width: 2),
                                              borderRadius:
                                                  BorderRadiusDirectional
                                                      .circular(10),
                                            ),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              children: [
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .stretch,
                                                    children: [
                                                      Text(
                                                          _products[index]
                                                              .description,
                                                          style: CommanStyle
                                                              .bw14500(
                                                                  context)),
                                                      Visibility(
                                                        visible:
                                                            getDiscountedPrice(
                                                                    _products[
                                                                        index])
                                                                .isNotEmpty,
                                                        child: Text(
                                                          getDiscountedPrice(
                                                              _products[index]),
                                                          style: CommanStyle
                                                                  .bw14400(
                                                                      context)
                                                              .copyWith(
                                                                  decoration:
                                                                      TextDecoration
                                                                          .lineThrough),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Text(
                                                    '${_products[index].price}  ',
                                                    style: CommanStyle.bw17500(
                                                        context)),
                                                const SizedBox(width: 24),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            right: 8,
                                            top: -2,
                                            child: Visibility(
                                              visible:
                                                  fakeOffer(_products[index]) !=
                                                      null,
                                              child: Image.asset(
                                                'assets/offer.png',
                                                height: 70,
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 13,
                                            top: 14,
                                            child: Visibility(
                                              visible:
                                                  fakeOffer(_products[index]) !=
                                                      null,
                                              child: RotationTransition(
                                                turns:
                                                    const AlwaysStoppedAnimation(
                                                        45 / 360),
                                                child: Text(
                                                  '${fakeOffer(_products[index])?.toStringAsFixed(0)}% off',
                                                  style: const TextStyle(
                                                    letterSpacing:
                                                        BibleInfo.letterSpacing,
                                                    fontSize: BibleInfo
                                                            .fontSizeScale *
                                                        10,
                                                    fontWeight: FontWeight.w500,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ),
                  ),

                  const SizedBox(height: 6),

                  // One Year plan

                  const Text(
                    "Auto renewal, cancel anytime",
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.black54,
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Free trial button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF7B5C3D),
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () async {
                        await SharPreferences.setString('OpenAd', '1');
                        _buyProduct(_products[selectedindex]);
                        // await controller.disableAd(const Duration(days: 3));
                        // return Get.offAll(() => HomeScreen(
                        //       From: "premium",
                        //       selectedVerseNumForRead: "",
                        //       selectedBookForRead: "",
                        //       selectedChapterForRead: "",
                        //       selectedBookNameForRead: "",
                        //       selectedVerseForRead: "",
                        //     ));
                      },
                      child: const Text(
                        "Start My Free Trial",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // Footer links
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                        onTap: () async {
                          launchUrlString(
                              'https://bibleoffice.com/terms_conditions.html');
                        },
                        child: Text(
                          "Terms of Use",
                          style: TextStyle(
                              fontSize: 12,
                              decoration: TextDecoration.underline),
                        ),
                      ),
                      GestureDetector(
                        onTap: () async {
                          launchUrlString(
                              'https://bibleoffice.com/privacy_policy.html');
                        },
                        child: Text(
                          "Privacy Policy",
                          style: TextStyle(
                              fontSize: 12,
                              decoration: TextDecoration.underline),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFeatureItem(String image, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 20),
      child: Row(
        children: [
          Image.asset(image, width: 28, height: 28), // ✅ use image, not Icon
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }
}
