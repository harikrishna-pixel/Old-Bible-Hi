import 'dart:developer';
import 'dart:io';
import 'package:audio_service/audio_service.dart';
import 'package:biblebookapp/Model/get_audio_model.dart';
import 'package:biblebookapp/utils/internet_speed_checker.dart';
import 'package:biblebookapp/view/constants/constant.dart';
import 'package:biblebookapp/view/constants/share_preferences.dart';
import 'package:biblebookapp/view/screens/dashboard/constants.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:html/parser.dart';
import 'package:popover/popover.dart';
import 'package:provider/provider.dart';
import '../../../Model/verseBookContentModel.dart';
import '../../constants/colors.dart';
import '../../constants/theme_provider.dart';
import '../../widget/country.dart';
import '../../widget/laguage.dart';
import 'package:audioplayers/audioplayers.dart';

class floatingButtun extends StatefulWidget {
  String bookName;
  String chapterNum;
  String bookNum;
  String chapterCount;
  List<VerseBookContentModel> contentList;
  GetAudioModel? audioData;
  List<ConnectivityResult>? internetConnection;
  bool textToSpeechLoad;
  late AudioPlayer audioPlayer;

  floatingButtun(
      {super.key,
      required this.textToSpeechLoad,
      required this.bookName,
      required this.chapterNum,
      required this.contentList,
      required this.chapterCount,
      required this.audioData,
      required this.bookNum,
      required this.internetConnection,
      required this.audioPlayer});

  @override
  State<floatingButtun> createState() => floatingButtunState();
}

enum TtsState { playing, stopped, paused, continued }

class floatingButtunState extends State<floatingButtun>
    with WidgetsBindingObserver {
  bool audioLoad = false;
  // GetAudioModel?  audioData;
  bool isOpenAudio = false;

  ///  *************************Audio *******************

  bool repeat = false;
  bool isAudioPlaying = false;
  // Duration duration = Duration(minutes: 10);
  // Duration position = Duration(minutes: 3);
  Duration duration = Duration.zero;
  Duration position = Duration.zero;
  String audioBaseUrl = "";
  int audioBookNum = 1;
  int audioChapterNum = 1;
  bool isPrevTTSEnabled = false;
  late AudioPlayer audioPlayer;

  // Add this for background audio
  late AudioHandler _audioHandler;
  bool _isAudioServiceInitialized = false;

  checkTTS() async {
    final ttsStatus =
        await SharPreferences.getBoolean(SharPreferences.isTtsActive);
    await Future.delayed(Duration(milliseconds: 2000));

    if (!mounted) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (isSpeech) {
        if (context.mounted) {
          setState(() {
            isPrevTTSEnabled = ttsStatus ?? false;
          });
        }
      }
    });
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    checknetwork();
    audioPlayer = widget.audioPlayer;
    setupAudioPlayer().then((_) {
      selectedChapter = int.parse(widget.chapterNum);
      audioChapterNum = int.parse(widget.chapterNum);
      audioBookNum = int.parse(widget.bookNum.toString()) + 1;
      setChapterContent();
      initTts();
      checkTTS();
    });

    audioPlayer.onPlayerStateChanged.listen((state) {
      isAudioPlaying = state == PlayerState.playing;
    });

    /// Listen to audio duration
    audioPlayer.onDurationChanged.listen((newDuration) {
      duration = newDuration;
    });
  }

  Future<void> setupAudioPlayer() async {
    await AudioPlayer.global.setAudioContext(
      AudioContext(
        android: const AudioContextAndroid(
          isSpeakerphoneOn: false,
          stayAwake: true,
          contentType: AndroidContentType.music,
          usageType: AndroidUsageType.media,
          audioFocus: AndroidAudioFocus.gain,
        ),
        iOS: AudioContextIOS(
          category: AVAudioSessionCategory.playback,
          // No defaultToSpeaker here for music
        ),
      ),
    );
  }

  initMusic() {
    /// Listen to s
    /// tates: playing, paused, stopped
    audioPlayer.onPlayerStateChanged.listen((state) {
      if (context.mounted) {
        setState(() {
          isAudioPlaying = state == PlayerState.playing;
        });
      }
    });

    /// Listen to audio duration
    audioPlayer.onDurationChanged.listen((newDuration) {
      if (context.mounted) {
        setState(() {
          duration = newDuration;
        });
      }
    });

    /// Listen to audio position
  }

  Future setAudio() async {
    // Repeat song when completed
    String? audioBasePath =
        widget.audioData?.data?.bibleAudioInfo?.audioBasepath;
    try {
      await audioPlayer.setReleaseMode(ReleaseMode.loop);
      audioBaseUrl = "$audioBasePath/$audioBookNum/$audioChapterNum.mp3";
      log('Audio Base Url:$audioBaseUrl');
      await audioPlayer.setSourceUrl(audioBaseUrl).whenComplete(() {
        log('Audio Set Completed');
      });
    } catch (e, st) {
      log('Audio Set Error: $e,$st');
      debugPrintStack(stackTrace: st);
    }
  }

  /// Text To Speech

  bool isTTSLoop = false;
  bool get isIOS => !kIsWeb && Platform.isIOS;
  bool get isAndroid => !kIsWeb && Platform.isAndroid;
  bool get isWindows => !kIsWeb && Platform.isWindows;
  bool get isWeb => kIsWeb;
  final Connectivity _connectivity = Connectivity();
  int curretNo = 0;
  String? speechText;
  int selectedChapter = 0;

  int languageSelectedColor = 0;
  List<VerseBookContentModel> selectedChapterContent = [];

  bool isSpeech = false;
  late FlutterTts flutterTts;
  String? language;
  String? engine;
  double volume = 0.5;
  double pitch = 1.25;
  double rate = 0.5;
  bool isCurrentLanguageInstalled = false;
  double turns = 0.0;
  Future<void> changeRotation() async {
    turns += 1.0 / 1.0;
  }

  String? _newVoiceText;
  int? inputLength;

  TtsState ttsState = TtsState.stopped;

  get isPlaying => ttsState == TtsState.playing;
  get isStopped => ttsState == TtsState.stopped;
  get isPaused => ttsState == TtsState.paused;
  get isContinued => ttsState == TtsState.continued;
  int start = 0;
  int end = 0;
  String allText = "";

  bool hasConnection = true;

  bool isNext = false;
  initTts() async {
    flutterTts = FlutterTts();

    _setAwaitOptions();
    await Future.delayed(Duration(milliseconds: 2000));

    if (!mounted) return;
    if (isAndroid) {
      _getDefaultEngine();
      _getDefaultVoice();
    }

    flutterTts.setStartHandler(() {
      if (context.mounted) {
        setState(() {
          ttsState = TtsState.playing;
        });
      }
    });

    flutterTts.setCancelHandler(() {
      if (context.mounted) {
        setState(() {
          ttsState = TtsState.stopped;
        });
      }
    });
    flutterTts.setPauseHandler(() {
      if (context.mounted) {
        setState(() {
          ttsState = TtsState.paused;
        });
      }
    });
    flutterTts.setContinueHandler(() {
      if (context.mounted) {
        setState(() {
          ttsState = TtsState.continued;
        });
      }
    });
    flutterTts.setCompletionHandler(() {
      if (isTTSLoop == false) {
        if (selectedChapter == int.parse(widget.chapterCount.toString()) &&
            selectedChapterContent.length == curretNo + 1) {
          _stop();
          if (context.mounted) {
            setState(() {
              isSpeech = false;
            });
          }
        } else {
          if (selectedChapter != int.parse(widget.chapterCount.toString()) &&
              selectedChapterContent.length == curretNo + 1) {
            if (context.mounted) {
              setState(() {
                selectedChapter++;
              });
              setChapterContent();
              _stop();
              isSpeech == true ? _speak() : null;
            }
          } else {
            curretNo = curretNo + 1;
            _newVoiceText = selectedChapterContent[curretNo].content;
            _speak();
          }
        }
      } else {
        _speak();
      }
    });
    flutterTts.setErrorHandler((msg) {
      if (context.mounted) {
        setState(() {
          ttsState = TtsState.stopped;
        });
      }
    });
  }

  Future<dynamic> _getLanguages() async => await flutterTts.getLanguages;
  checknetwork() async {
    await Future.delayed(Duration(milliseconds: 3000));
    await SharPreferences.setBoolean('closead', false);
    if (!mounted) return;
    if (context.mounted) {
      // final checkdata = await _connectivity.checkConnectivity();
      final speed = await InternetSpeedChecker.checkSpeed();
      if (speed != null) {
        setState(() {
          hasConnection = true;
        });
      } else {
        setState(() {
          hasConnection = false;
        });
      }
    }
    debugPrint("check network - $hasConnection");
  }

  Future _getDefaultEngine() async {
    var engine = await flutterTts.getDefaultEngine;
    if (engine != null) {}
  }

  Future _getDefaultVoice() async {
    var voice = await flutterTts.getDefaultVoice;
    if (voice != null) {}
  }

  Future _speak() async {
    await flutterTts.setVolume(volume);
    await flutterTts.setSpeechRate(rate);
    await flutterTts.setPitch(pitch);
    if (_newVoiceText != null) {
      if (_newVoiceText?.isNotEmpty ?? false) {
        final parseText = parse(_newVoiceText).body?.text ?? '';
        await flutterTts.awaitSpeakCompletion(true);
        await flutterTts.speak(parseText);
      }
    }
  }

  Future _setAwaitOptions() async {
    await flutterTts.awaitSpeakCompletion(true);
  }

  Future _stop() async {
    // await Future.delayed(Duration(seconds: 2));
    await SharPreferences.setBoolean('closead', true);
    if (!mounted) return;
    if (context.mounted) {
      var result = await flutterTts.stop();
      if (result == 1) setState(() => ttsState = TtsState.stopped);
    }
  }

  bool isInitialTime = true;
  int isInitialProgress = 1;
  int totalStartOffset = 0;
  int totalEndOffset = 0;

  closeaudio() async {
    debugPrint(" audio  stopped ");

    if (context.mounted || mounted) {
      if (isAudioPlaying) {
        await audioPlayer.stop();
        await SharPreferences.setBoolean('closead', true);
        // await audioPlayer.dispose();
      } else if (isSpeech) {
        flutterTts.stop();
      }
    }
  }

  setChapterContent() async {
    await Future.delayed(Duration(milliseconds: 2000));

    if (!mounted) return;
    selectedChapterContent.clear();
    start = 0;
    end = 0;
    if (context.mounted) {
      setState(() {
        curretNo = 0;
      });
    }
    Future.delayed(Duration.zero, () {
      for (var i = 0; i < (widget.contentList.length ?? 0); i++) {
        if (selectedChapter ==
            int.parse((widget.contentList[i].chapterNum).toString()) + 1) {
          if (context.mounted) {
            setState(() {
              start = 0;
              end = isInitialTime ? 0 : (_newVoiceText?.length ?? 0);
              selectedChapterContent.add(widget.contentList[i]);
              _newVoiceText = selectedChapterContent[curretNo].content;
            });
          }
        }
      }
    });
  }

  @override
  void dispose() {
    closeaudio();
    // audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    debugPrint("sz current width - $screenWidth ");

    bool isTTSEnabled = Platform.isAndroid
        ? widget.audioData?.data?.bibleAudioInfo
                ?.isTextToSpeechAvailableAndroid ==
            "1"
        : widget.audioData?.data?.bibleAudioInfo?.isTextToSpeechAvailableIos ==
            "1";

    if (widget.audioData?.data != null) {
      SharPreferences.setBoolean(SharPreferences.isTtsActive, isTTSEnabled);
      if (context.mounted) {
        setState(() {
          isPrevTTSEnabled = isTTSEnabled;
        });
      }
    }

    bool isMp3Enabled =
        widget.audioData?.data?.bibleAudioInfo?.isShowMp3Audio == "1";
    if (hasConnection) {
      if (isMp3Enabled || isTTSEnabled && hasConnection) {
        return Container(
          height: screenWidth > 450 ? 50 : 35,
          width: screenWidth > 450 ? 50 : 35,
          decoration: BoxDecoration(
            color: CommanColor.whiteLightModePrimary(context),
            shape: BoxShape.circle,
          ),
          child: GestureDetector(
            child: Center(
                child: isSpeech || isAudioPlaying
                    ? Icon(Icons.pause,
                        size: screenWidth > 450 ? 44 : 24,
                        color: CommanColor.darkModePrimaryWhite(context))
                    : audioLoad
                        ? SizedBox(
                            height: 18,
                            width: 18,
                            child: CircularProgressIndicator(
                              color: CommanColor.darkModePrimaryWhite(context),
                              strokeWidth: 2,
                            ))
                        : Icon(
                            !isOpenAudio ? Icons.play_arrow : Icons.close,
                            color: CommanColor.darkModePrimaryWhite(context),
                            size: !isOpenAudio
                                ? screenWidth > 450
                                    ? 43
                                    : 28
                                : 22,
                          )),
            onTap: () async {
              log('On Tap');
              if (isSpeech) {
                _stop();
                setState(() {
                  isSpeech = false;
                });
              } else if (isAudioPlaying) {
                await audioPlayer.stop();
                setState(() {
                  isAudioPlaying = false;
                });
              } else if (isTTSEnabled && !isMp3Enabled) {
                textToSpeechBottomSheet();
              } else if (isMp3Enabled && !isTTSEnabled) {
                await setAudio();
                setState(() {
                  audioLoad = false;
                });
                audioPlayerBottomSheet().then((value) {
                  setState(() {});
                });
              } else {
                setState(() {
                  isOpenAudio = true;
                  audioLoad = true;
                });
                await setAudio();
                setState(() {
                  audioLoad = false;
                });
                showPopover(
                  context: context,
                  direction: PopoverDirection.left,
                  transitionDuration: const Duration(milliseconds: 250),
                  bodyBuilder: (context) {
                    return Container(
                      color: CommanColor.whiteLightModePrimary(context),
                      padding: const EdgeInsets.symmetric(vertical: 0),
                      child: Center(
                        child: ListView(
                          physics: const NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          children: [
                            GestureDetector(
                              onTap: () {
                                if (context.mounted) {
                                  Navigator.pop(context);
                                  audioPlayerBottomSheet().then((value) {
                                    setState(() {});
                                  });
                                }
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12.0, vertical: 5),
                                child: Row(
                                  children: [
                                    Image.asset(
                                      "assets/musical_note.png",
                                      height: 22,
                                      width: 22,
                                      color: CommanColor.darkModePrimaryWhite(
                                          context),
                                    ),
                                    const SizedBox(
                                      width: 17,
                                    ),
                                    Text(
                                      "Audio",
                                      style: CommanStyle.pw14500(context),
                                    )
                                  ],
                                ),
                              ),
                            ),
                            Divider(
                              color: CommanColor.darkModePrimaryWhite(context),
                              thickness: 1.2,
                            ),
                            GestureDetector(
                              onTap: () {
                                Navigator.pop(context);
                                textToSpeechBottomSheet();
                              },
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 12.0, vertical: 5),
                                child: Row(
                                  children: [
                                    Image.asset(
                                      "assets/text_to_speech.png",
                                      height: 26,
                                      width: 26,
                                      color: CommanColor.darkModePrimaryWhite(
                                          context),
                                    ),
                                    const SizedBox(
                                      width: 15,
                                    ),
                                    Text(
                                      "Text to speech",
                                      style: CommanStyle.pw14500(context),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                  width: 180,
                  height: 100,
                  arrowDyOffset: -20,
                  barrierColor: Colors.transparent,
                  backgroundColor:
                      Provider.of<ThemeProvider>(context, listen: false)
                                  .themeMode ==
                              ThemeMode.dark
                          ? Colors.white
                          : CommanColor.lightModePrimary,
                  arrowWidth: 24,
                ).then((value) {
                  if (context.mounted) {
                    setState(() {
                      isOpenAudio = false;
                    });
                  }
                });
              }

              await checknetwork();
              if (hasConnection == false) {
                Constants.showToast("Check your Internet Connection");
              }
            },
          ),
        );
      } else {
        ///
        /// If no internet just show tts
        ///
        ///
        if (isPrevTTSEnabled || isTTSEnabled) {
          return Container(
            height: 35,
            width: 35,
            decoration: BoxDecoration(
              color: CommanColor.whiteLightModePrimary(context),
              shape: BoxShape.circle,
            ),
            child: GestureDetector(
              child: Center(
                  child: isSpeech || isAudioPlaying
                      ? Icon(Icons.pause,
                          size: 24,
                          color: CommanColor.darkModePrimaryWhite(context))
                      : audioLoad == true
                          ? SizedBox(
                              height: 18,
                              width: 18,
                              child: CircularProgressIndicator(
                                color:
                                    CommanColor.darkModePrimaryWhite(context),
                                strokeWidth: 2,
                              ))
                          : Icon(
                              isOpenAudio == false
                                  ? Icons.play_arrow
                                  : Icons.close,
                              color: CommanColor.darkModePrimaryWhite(context),
                              size: isOpenAudio == false ? 28 : 22,
                            )),
              onTap: () async {
                if (isSpeech) {
                  _stop();
                  setState(() {
                    isSpeech = false;
                  });
                } else if (isAudioPlaying) {
                  await audioPlayer.stop();
                  setState(() {
                    isAudioPlaying = false;
                  });
                } else {
                  textToSpeechBottomSheet();
                }
              },
            ),
          );
        }
      }
    } else {
      return Container(
        height: screenWidth > 450 ? 50 : 35,
        width: screenWidth > 450 ? 50 : 35,
        decoration: BoxDecoration(
          color: CommanColor.whiteLightModePrimary(context),
          shape: BoxShape.circle,
        ),
        child: GestureDetector(
          child: Center(
              child: isSpeech || isAudioPlaying
                  ? Icon(Icons.pause,
                      size: screenWidth > 450 ? 44 : 24,
                      color: CommanColor.darkModePrimaryWhite(context))
                  : audioLoad
                      ? SizedBox(
                          height: 18,
                          width: 18,
                          child: CircularProgressIndicator(
                            color: CommanColor.darkModePrimaryWhite(context),
                            strokeWidth: 2,
                          ))
                      : Icon(
                          !isOpenAudio ? Icons.play_arrow : Icons.close,
                          color: CommanColor.darkModePrimaryWhite(context),
                          size: !isOpenAudio
                              ? screenWidth > 450
                                  ? 43
                                  : 28
                              : 22,
                        )),
          onTap: () async {
            Constants.showToast("Check your Internet Connection");
          },
        ),
      );
    }
    return SizedBox();
  }

  bool get supportPause => defaultTargetPlatform != TargetPlatform.android;
  bool get supportResume => defaultTargetPlatform != TargetPlatform.android;
  String formatTime(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));

    return [
      if (duration.inHours > 0) hours,
      minutes,
      seconds,
    ].join(':');
  }

  Widget _textFromInput(int start, int end, String text) => text.length < end
      ? const SizedBox.shrink()
      : RichText(
          textAlign: TextAlign.center,
          text: TextSpan(children: <TextSpan>[
            TextSpan(
                text: start != 0 ? text.substring(0, start) : "",
                style: TextStyle(
                    color: CommanColor.lightDarkPrimary(context),
                    letterSpacing: BibleInfo.letterSpacing,
                    fontSize: BibleInfo.fontSizeScale * 16,
                    fontWeight: FontWeight.w500,
                    height: 1.3)),
            TextSpan(
              text: text.substring(start, end),
              style: CommanStyle.HighLightWordStyle(context),
            ),
            TextSpan(
                text: text.substring(end),
                style: TextStyle(
                    color: CommanColor.lightDarkPrimary(context),
                    letterSpacing: BibleInfo.letterSpacing,
                    fontSize: BibleInfo.fontSizeScale * 16,
                    fontWeight: FontWeight.w500,
                    height: 1.3)),
          ]),
        );

  Future audioPlayerBottomSheet() {
    return showModalBottomSheet(
      backgroundColor: Colors.black12,
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            audioPlayer.onPositionChanged.listen((event) {
              if (context.mounted) {
                setState(() {
                  position = event;
                });
              }
              audioPlayer.getDuration().then((value) async {
                if (event.inSeconds == value?.inSeconds &&
                    repeat == false &&
                    isNext == false) {
                  if (context.mounted) {
                    setState(() {
                      isNext = true;
                      //audioChapterNum++;
                      audioChapterNum == int.parse(widget.chapterCount)
                          ? audioChapterNum = int.parse(widget.chapterCount)
                          : audioChapterNum++;
                      audioBaseUrl =
                          "${widget.audioData?.data?.bibleAudioInfo?.audioBasepath.toString()}/$audioBookNum/$audioChapterNum.mp3";
                    });
                  }
                  await audioPlayer.setSourceUrl(audioBaseUrl);
                  isAudioPlaying = true;
                }
              });

              Future.delayed(
                const Duration(seconds: 5),
                () {
                  if (context.mounted) {
                    setState(() {
                      isNext = false;
                    });
                  }
                },
              );
            });
            return Container(
                height: 130,
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20)),
                    color: Colors.white),
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  children: [
                    const SizedBox(height: 15),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const SizedBox(
                          width: 60,
                        ),
                        Text(
                          "${widget.bookName} - $audioChapterNum",
                          style: TextStyle(
                              color: CommanColor.lightDarkPrimary(context),
                              letterSpacing: BibleInfo.letterSpacing,
                              fontSize: BibleInfo.fontSizeScale * 14,
                              fontWeight: FontWeight.w600),
                        ),
                        Row(
                          children: [
                            InkWell(
                                onTap: () async {
                                  setState(() {
                                    isAudioPlaying = false;
                                  });
                                  await audioPlayer.stop();
                                  if (context.mounted) {
                                    Navigator.pop(context);
                                  }
                                },
                                child: Icon(
                                  Icons.close,
                                  color: CommanColor.lightDarkPrimary(context),
                                  size: 20,
                                )),
                            const SizedBox(
                              width: 10,
                            ),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Text(
                          formatTime(position),
                          style: TextStyle(
                              color: CommanColor.lightDarkPrimary(context),
                              letterSpacing: BibleInfo.letterSpacing,
                              fontSize: BibleInfo.fontSizeScale * 10,
                              fontWeight: FontWeight.w400),
                        ),
                        Flexible(
                          child: Container(
                            height: 20,
                            margin: const EdgeInsets.only(left: 5, right: 3),
                            child: SliderTheme(
                              data: SliderThemeData(
                                trackHeight: 4.0,
                                thumbColor:
                                    CommanColor.lightDarkPrimary(context),
                                overlayShape: SliderComponentShape.noOverlay,
                                thumbShape: const RoundSliderThumbShape(
                                    enabledThumbRadius: 6),
                              ),
                              child: Slider(
                                min: 0,
                                max: duration.inSeconds.toDouble(),
                                value: position.inSeconds.toDouble(),
                                activeColor:
                                    CommanColor.lightDarkPrimary(context),
                                inactiveColor: CommanColor.lightGrey,
                                thumbColor:
                                    CommanColor.lightDarkPrimary(context),
                                onChanged: (newValue) async {
                                  final position =
                                      Duration(seconds: newValue.toInt());
                                  await audioPlayer.seek(position);

                                  ///Optional:Play audio if was paused
                                  await audioPlayer.resume();
                                  setState(() {});
                                },

                                // divisions: 15,
                              ),
                            ),
                          ),
                        ),
                        Text(formatTime(duration),
                            style: TextStyle(
                                color: CommanColor.lightDarkPrimary(context),
                                letterSpacing: BibleInfo.letterSpacing,
                                fontSize: BibleInfo.fontSizeScale * 10,
                                fontWeight: FontWeight.w400)),
                      ],
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: InkWell(
                              onTap: () {
                                setState(() {
                                  repeat = !repeat;
                                });
                                if (repeat == true) {
                                  audioPlayer.setReleaseMode(ReleaseMode.loop);
                                } else {}
                              },
                              child: Stack(children: [
                                Image.asset(
                                  "assets/repeat.png",
                                  color: CommanColor.lightDarkPrimary(context),
                                  height: 20,
                                  width: 20,
                                ),
                                repeat == true
                                    ? Positioned(
                                        left: 0,
                                        right: 0,
                                        top: 0,
                                        bottom: 0,
                                        child: Center(
                                            child: Text(
                                          "1",
                                          style: TextStyle(
                                              letterSpacing:
                                                  BibleInfo.letterSpacing,
                                              fontSize:
                                                  BibleInfo.fontSizeScale * 10,
                                              fontWeight: FontWeight.w600,
                                              color:
                                                  CommanColor.lightDarkPrimary(
                                                      context)),
                                          textAlign: TextAlign.center,
                                        )))
                                    : const SizedBox()
                              ])),
                        ),
                        IconButton(
                            icon: Image.asset(
                              "assets/chapt_back.png",
                              color: CommanColor.lightDarkPrimary(context),
                              height: 20,
                              width: 20,
                            ),
                            onPressed: () async {
                              setState(() async {
                                audioChapterNum > 1
                                    ? audioChapterNum--
                                    : audioChapterNum = 1;
                                audioBaseUrl =
                                    "${widget.audioData?.data?.bibleAudioInfo?.audioBasepath.toString()}/$audioBookNum/$audioChapterNum.mp3";
                                await audioPlayer.setSourceUrl(audioBaseUrl);
                              });
                            }),
                        IconButton(
                          icon: Image.asset(
                            "assets/previous_music.png",
                            color: CommanColor.lightDarkPrimary(context),
                            height: 20,
                            width: 20,
                          ),
                          onPressed: () async {
                            setState(() {
                              position.inSeconds >= 10
                                  ? position =
                                      position - const Duration(seconds: 10)
                                  : position = Duration.zero;
                            });
                            await audioPlayer.seek(position);

                            ///Optional:Play audio if was paused
                            await audioPlayer.resume();
                            setState(() {});
                          },
                        ),
                        InkWell(
                            onTap: () async {
                              if (isAudioPlaying) {
                                await audioPlayer.pause();
                              } else {
                                await audioPlayer.resume();
                              }
                              setState(() {});
                            },
                            child: Container(
                                decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color:
                                        CommanColor.lightDarkPrimary(context)),
                                padding: const EdgeInsets.all(7),
                                child: Image.asset(
                                  isAudioPlaying
                                      ? "assets/pause.png"
                                      : "assets/play.png",
                                  color: Colors.white,
                                  height: 15,
                                  width: 15,
                                ))),
                        IconButton(
                          icon: Image.asset(
                            "assets/next_music.png",
                            color: CommanColor.lightDarkPrimary(context),
                            height: 20,
                            width: 20,
                          ),
                          onPressed: () async {
                            setState(() {
                              duration.inSeconds - position.inSeconds >= 10
                                  ? position =
                                      position + const Duration(seconds: 10)
                                  : position = duration;
                            });
                            await audioPlayer.seek(position);

                            ///Optional:Play audio if was paused
                            await audioPlayer.resume();
                            setState(() {});
                          },
                        ),
                        IconButton(
                            icon: Image.asset(
                              "assets/chapt_next.png",
                              color: CommanColor.lightDarkPrimary(context),
                              height: 20,
                              width: 20,
                            ),
                            onPressed: () async {
                              if (widget.internetConnection?.first ==
                                      ConnectivityResult.wifi ||
                                  widget.internetConnection?.first ==
                                      ConnectivityResult.mobile) {
                                setState(() {
                                  isAudioPlaying = false;
                                  audioChapterNum !=
                                          int.parse(widget.chapterCount)
                                      ? audioChapterNum++
                                      : audioChapterNum =
                                          int.parse(widget.chapterCount);
                                  audioBaseUrl =
                                      "${widget.audioData?.data?.bibleAudioInfo?.audioBasepath.toString()}/$audioBookNum/$audioChapterNum.mp3";
                                  audioPlayer
                                      .setSourceUrl(audioBaseUrl)
                                      .then((_) {
                                    isAudioPlaying = true;
                                  });
                                });
                              } else {
                                Constants.showToast("No Internet Connection");
                              }
                            }),
                        Padding(
                          padding: const EdgeInsets.only(right: 10.0),
                          child: InkWell(
                            onTap: () async {
                              await audioPlayer.stop();
                            },
                            child: Image.asset(
                              "assets/stop.png",
                              color: CommanColor.lightDarkPrimary(context),
                              height: 18,
                              width: 18,
                            ),
                          ),
                        ),
                      ],
                    ),
                    // PlayerButtons(_audioPlayer, progressBar:1),
                  ],
                ));
          },
        );
      },
    ).then((value) {
      if (context.mounted) {
        setState(() {});
      }
    });
  }

  Future textToSpeechBottomSheet() {
    if (widget.textToSpeechLoad == false) {
      return showModalBottomSheet(
        backgroundColor: Colors.black12,
        context: context,
        builder: (context) {
          return StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
              flutterTts.setProgressHandler(
                  (String text, int startOffset, int endOffset, String word) {
                Future.delayed(
                  Duration.zero,
                  () {
                    if (context.mounted) {
                      setState(() {
                        allText = text;
                        start = startOffset;
                        end = endOffset;
                      });
                    }
                  },
                );
              });
              return Container(
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20)),
                      color: Colors.white),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: ListView(
                    shrinkWrap: true,
                    children: [
                      const SizedBox(height: 15),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const SizedBox(
                            width: 80,
                          ),
                          Text(
                            "${widget.bookName} $selectedChapter - ${curretNo + 1}/${selectedChapterContent.length}",
                            style: TextStyle(
                                color: CommanColor.lightDarkPrimary(context),
                                letterSpacing: BibleInfo.letterSpacing,
                                fontSize: BibleInfo.fontSizeScale * 14,
                                fontWeight: FontWeight.w600),
                          ),
                          Row(
                            children: [
                              InkWell(
                                  onTap: () {
                                    // Navigator.pop(context);
                                    showModalBottomSheet(
                                      backgroundColor: Colors.black12,
                                      context: context,
                                      builder: (context) {
                                        return StatefulBuilder(
                                          builder: (context, setModalState) {
                                            return Container(
                                                // height: 200,
                                                decoration: const BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.only(
                                                            topLeft: Radius
                                                                .circular(20),
                                                            topRight:
                                                                Radius.circular(
                                                                    20)),
                                                    color: Colors.white),
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 10),
                                                child: ListView(
                                                  shrinkWrap: true,
                                                  children: [
                                                    const SizedBox(height: 15),
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        const SizedBox(),
                                                        InkWell(
                                                          onTap: () {
                                                            changeRotation();
                                                            setModalState(() {
                                                              volume = 0.5;
                                                              pitch = 1.25;
                                                              rate = 0.5;
                                                            });
                                                          },
                                                          child: Container(
                                                            margin:
                                                                const EdgeInsets
                                                                    .only(
                                                                    left: 30),
                                                            padding:
                                                                const EdgeInsets
                                                                    .symmetric(
                                                                    horizontal:
                                                                        8,
                                                                    vertical:
                                                                        5),
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          20),
                                                              color: CommanColor
                                                                  .lightDarkPrimary(
                                                                      context),
                                                            ),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              children: [
                                                                AnimatedRotation(
                                                                  turns: turns,
                                                                  duration:
                                                                      const Duration(
                                                                          seconds:
                                                                              1),
                                                                  child:
                                                                      const Icon(
                                                                    Icons.sync,
                                                                    color: Colors
                                                                        .white,
                                                                    size: 20,
                                                                  ),
                                                                ),
                                                                const SizedBox(
                                                                  width: 5,
                                                                ),
                                                                const Text(
                                                                  "Reset",
                                                                  style: CommanStyle
                                                                      .white14500,
                                                                )
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        InkWell(
                                                            onTap: () {
                                                              Navigator.pop(
                                                                  context);
                                                            },
                                                            child: Icon(
                                                              Icons.close,
                                                              color: CommanColor
                                                                  .lightDarkPrimary(
                                                                      context),
                                                              size: 24,
                                                            )),
                                                      ],
                                                    ),
                                                    const SizedBox(height: 5),
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 10.0),
                                                          child: Column(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .start,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Image.asset(
                                                                "assets/lightMode/icons/Pitch.png",
                                                                height: 22,
                                                                width: 22,
                                                                color: CommanColor
                                                                    .lightDarkPrimary(
                                                                        context),
                                                              ),
                                                              const SizedBox(
                                                                height: 25,
                                                              ),
                                                              Image.asset(
                                                                "assets/lightMode/icons/speed.png",
                                                                height: 22,
                                                                width: 22,
                                                                color: CommanColor
                                                                    .lightDarkPrimary(
                                                                        context),
                                                              ),
                                                              const SizedBox(
                                                                height: 25,
                                                              ),
                                                              Image.asset(
                                                                "assets/lightMode/icons/volume.png",
                                                                height: 22,
                                                                width: 22,
                                                                color: CommanColor
                                                                    .lightDarkPrimary(
                                                                        context),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Text(
                                                              "Pitch",
                                                              style: TextStyle(
                                                                  color: CommanColor
                                                                      .lightDarkPrimary(
                                                                          context),
                                                                  letterSpacing:
                                                                      BibleInfo
                                                                          .letterSpacing,
                                                                  fontSize:
                                                                      BibleInfo
                                                                              .fontSizeScale *
                                                                          16,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  height: 1.3),
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                            ),
                                                            const SizedBox(
                                                              height: 25,
                                                            ),
                                                            Text(
                                                              "Speed",
                                                              style: TextStyle(
                                                                  color: CommanColor
                                                                      .lightDarkPrimary(
                                                                          context),
                                                                  letterSpacing:
                                                                      BibleInfo
                                                                          .letterSpacing,
                                                                  fontSize:
                                                                      BibleInfo
                                                                              .fontSizeScale *
                                                                          16,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  height: 1.3),
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                            ),
                                                            const SizedBox(
                                                              height: 25,
                                                            ),
                                                            Text(
                                                              "Volume",
                                                              style: TextStyle(
                                                                  color: CommanColor
                                                                      .lightDarkPrimary(
                                                                          context),
                                                                  letterSpacing:
                                                                      BibleInfo
                                                                          .letterSpacing,
                                                                  fontSize:
                                                                      BibleInfo
                                                                              .fontSizeScale *
                                                                          16,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  height: 1.3),
                                                              textAlign:
                                                                  TextAlign
                                                                      .left,
                                                            ),
                                                          ],
                                                        ),
                                                        Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            SizedBox(
                                                              width: MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .width *
                                                                  0.68,
                                                              child:
                                                                  SliderTheme(
                                                                data: SliderThemeData(
                                                                    thumbColor:
                                                                        CommanColor.lightDarkPrimary(
                                                                            context),
                                                                    thumbShape:
                                                                        const RoundSliderThumbShape(
                                                                            enabledThumbRadius:
                                                                                7)),
                                                                child: Slider(
                                                                  activeColor:
                                                                      CommanColor
                                                                          .lightDarkPrimary(
                                                                              context),
                                                                  inactiveColor:
                                                                      CommanColor
                                                                          .lightGrey,
                                                                  thumbColor: CommanColor
                                                                      .lightDarkPrimary(
                                                                          context),
                                                                  value: pitch,
                                                                  onChanged:
                                                                      (newPitch) {
                                                                    setModalState(() =>
                                                                        pitch =
                                                                            newPitch);
                                                                    setState(
                                                                        () {});
                                                                  },
                                                                  min: 0.5,
                                                                  max: 2.0,
                                                                  // divisions: 15,
                                                                  label:
                                                                      "Pitch: $pitch",
                                                                ),
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .width *
                                                                  0.68,
                                                              child:
                                                                  SliderTheme(
                                                                data: SliderThemeData(
                                                                    thumbColor:
                                                                        CommanColor.lightDarkPrimary(
                                                                            context),
                                                                    thumbShape:
                                                                        const RoundSliderThumbShape(
                                                                            enabledThumbRadius:
                                                                                7)),
                                                                child: Slider(
                                                                  activeColor:
                                                                      CommanColor
                                                                          .lightDarkPrimary(
                                                                              context),
                                                                  inactiveColor:
                                                                      CommanColor
                                                                          .lightGrey,
                                                                  thumbColor: CommanColor
                                                                      .lightDarkPrimary(
                                                                          context),
                                                                  value: rate,
                                                                  onChanged:
                                                                      (newRate) {
                                                                    setModalState(
                                                                        () => rate =
                                                                            newRate);
                                                                    setState(
                                                                        () {});
                                                                  },
                                                                  min: 0.0,
                                                                  max: 1.0,
                                                                  // divisions: 10,
                                                                  label:
                                                                      "Rate: $rate",
                                                                ),
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .width *
                                                                  0.68,
                                                              child:
                                                                  SliderTheme(
                                                                data: SliderThemeData(
                                                                    thumbColor:
                                                                        CommanColor.lightDarkPrimary(
                                                                            context),
                                                                    thumbShape:
                                                                        const RoundSliderThumbShape(
                                                                            enabledThumbRadius:
                                                                                7)),
                                                                child: Slider(
                                                                    activeColor:
                                                                        CommanColor.lightDarkPrimary(
                                                                            context),
                                                                    inactiveColor:
                                                                        CommanColor
                                                                            .lightGrey,
                                                                    thumbColor:
                                                                        CommanColor.lightDarkPrimary(
                                                                            context),
                                                                    value:
                                                                        volume,
                                                                    onChanged:
                                                                        (newVolume) {
                                                                      setModalState(() =>
                                                                          volume =
                                                                              newVolume);
                                                                      setState(
                                                                          () {});
                                                                    },
                                                                    min: 0.0,
                                                                    max: 1.0,
                                                                    // divisions: 10,
                                                                    label:
                                                                        "Volume: $volume"),
                                                              ),
                                                            ),
                                                          ],
                                                        )
                                                      ],
                                                    ),
                                                  ],
                                                ));
                                          },
                                        );
                                      },
                                    );
                                  },
                                  child: Icon(
                                    Icons.settings,
                                    color:
                                        CommanColor.lightDarkPrimary(context),
                                  )),
                              const SizedBox(
                                width: 10,
                              ),
                              InkWell(
                                  onTap: () {
                                    // Navigator.pop(context);
                                    showModalBottomSheet(
                                      backgroundColor: Colors.black12,
                                      context: context,
                                      builder: (context) {
                                        return StatefulBuilder(
                                          builder: (BuildContext context,
                                              StateSetter setModalState) {
                                            return FutureBuilder<dynamic>(
                                                future: _getLanguages(),
                                                builder: (BuildContext context,
                                                    AsyncSnapshot<dynamic>
                                                        snapshot) {
                                                  if (snapshot.hasData) {
                                                    List langList = [];
                                                    for (var i = 0;
                                                        i <
                                                            snapshot
                                                                .data.length;
                                                        i++) {
                                                      if (snapshot.data[i]
                                                              .toString()
                                                              .split("-")
                                                              .first ==
                                                          "en") {
                                                        langList.add(
                                                            snapshot.data[i]);
                                                      }
                                                    }
                                                    return Container(
                                                        height: MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .height *
                                                            0.4,
                                                        decoration: const BoxDecoration(
                                                            borderRadius: BorderRadius.only(
                                                                topLeft: Radius
                                                                    .circular(
                                                                        20),
                                                                topRight:
                                                                    Radius.circular(
                                                                        20)),
                                                            color:
                                                                Colors.white),
                                                        padding:
                                                            const EdgeInsets
                                                                .symmetric(
                                                                horizontal: 10),
                                                        child: Column(
                                                          children: [
                                                            const SizedBox(
                                                                height: 15),
                                                            Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .end,
                                                              children: [
                                                                InkWell(
                                                                    onTap: () {
                                                                      Navigator.pop(
                                                                          context);
                                                                    },
                                                                    child: Icon(
                                                                      Icons
                                                                          .close,
                                                                      color: CommanColor
                                                                          .lightDarkPrimary(
                                                                              context),
                                                                      size: 24,
                                                                    )),
                                                              ],
                                                            ),
                                                            const SizedBox(
                                                                height: 20),
                                                            SizedBox(
                                                              height: MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .height *
                                                                  0.32,
                                                              child: ListView
                                                                  .builder(
                                                                itemCount:
                                                                    langList
                                                                        .length,
                                                                physics:
                                                                    const ScrollPhysics(),
                                                                itemBuilder:
                                                                    (context,
                                                                        index) {
                                                                  var data =
                                                                      langList[
                                                                          index];

                                                                  var languageConvert =
                                                                      LanguageLocal().getDisplayLanguage(data
                                                                          .toString()
                                                                          .split(
                                                                              "-")
                                                                          .first);
                                                                  var countryConvert =
                                                                      CountryLocal().getDisplayCountry(data
                                                                          .toString()
                                                                          .split(
                                                                              "-")
                                                                          .last);

                                                                  return InkWell(
                                                                    onTap:
                                                                        () async {
                                                                      setModalState(
                                                                          () {
                                                                        languageSelectedColor =
                                                                            index;
                                                                        language =
                                                                            data;
                                                                        flutterTts.setLanguage(language ??
                                                                            '');
                                                                        if (isAndroid) {
                                                                          flutterTts
                                                                              .isLanguageInstalled(language ?? '')
                                                                              .then((value) => isCurrentLanguageInstalled = (value as bool));
                                                                        }
                                                                      });
                                                                      setState(
                                                                          () {});
                                                                    },
                                                                    child:
                                                                        Container(
                                                                      padding: const EdgeInsets
                                                                          .all(
                                                                          8.0),
                                                                      decoration: BoxDecoration(
                                                                          color: languageSelectedColor == index
                                                                              ? CommanColor.lightDarkPrimary(context)
                                                                              : Colors.transparent),
                                                                      child:
                                                                          Row(
                                                                        children: [
                                                                          Icon(
                                                                            Icons.mic,
                                                                            color: languageSelectedColor == index
                                                                                ? Colors.white
                                                                                : CommanColor.lightDarkPrimary(context),
                                                                            size:
                                                                                32,
                                                                          ),
                                                                          const SizedBox(
                                                                            width:
                                                                                20,
                                                                          ),
                                                                          // Text(),
                                                                          Text(
                                                                            "${languageConvert["name"]}",
                                                                            style: TextStyle(
                                                                                color: languageSelectedColor == index ? Colors.white : CommanColor.lightDarkPrimary(context),
                                                                                letterSpacing: BibleInfo.letterSpacing,
                                                                                fontSize: BibleInfo.fontSizeScale * 16,
                                                                                fontWeight: FontWeight.w500,
                                                                                height: 1.3),
                                                                          ),
                                                                          const Spacer(),
                                                                          SizedBox(
                                                                            width:
                                                                                MediaQuery.of(context).size.width * 0.35,
                                                                            child:
                                                                                Row(
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              children: [
                                                                                Text(
                                                                                  "${countryConvert["name"]}",
                                                                                  style: TextStyle(color: languageSelectedColor == index ? Colors.white : CommanColor.lightDarkPrimary(context), letterSpacing: BibleInfo.letterSpacing, fontSize: BibleInfo.fontSizeScale * 16, fontWeight: FontWeight.w500, height: 1.3),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  );
                                                                },
                                                              ),
                                                            ),
                                                          ],
                                                        ));
                                                  } else if (snapshot
                                                      .hasError) {
                                                    return const Text(
                                                        'Error loading languages...');
                                                  } else {
                                                    return const Text(
                                                        'Loading Languages...');
                                                  }
                                                });
                                          },
                                        );
                                      },
                                    );
                                  },
                                  child: Icon(
                                    Icons.mic,
                                    color:
                                        CommanColor.lightDarkPrimary(context),
                                  )),
                              const SizedBox(
                                width: 10,
                              ),
                              InkWell(
                                  onTap: () {
                                    _stop();
                                    setState(() {
                                      isSpeech = false;
                                    });
                                    Navigator.pop(context);
                                  },
                                  child: Icon(
                                    Icons.close,
                                    color:
                                        CommanColor.lightDarkPrimary(context),
                                  )),
                              const SizedBox(
                                width: 10,
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 25),
                      SizedBox(
                          width: MediaQuery.of(context).size.width * 0.86,
                          child: ttsState == TtsState.playing
                              ? _textFromInput(start, end, allText)
                              : Text(
                                  selectedChapterContent.length > curretNo
                                      ? parse(selectedChapterContent[curretNo]
                                                  .content)
                                              .body
                                              ?.text ??
                                          ''
                                      : 'Loading...',
                                  style: TextStyle(
                                      color:
                                          CommanColor.lightDarkPrimary(context),
                                      letterSpacing: BibleInfo.letterSpacing,
                                      fontSize: BibleInfo.fontSizeScale * 16,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3),
                                  textAlign: TextAlign.center,
                                )),
                      const SizedBox(height: 40),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                              onTap: () {
                                setState(() {
                                  isTTSLoop = !isTTSLoop;
                                });
                              },
                              child: Stack(children: [
                                Image.asset(
                                  "assets/repeat.png",
                                  color: CommanColor.lightDarkPrimary(context),
                                  height: 20,
                                  width: 20,
                                ),
                                isTTSLoop == true
                                    ? Positioned(
                                        left: 0,
                                        right: 0,
                                        top: 0,
                                        bottom: 0,
                                        child: Center(
                                            child: Text(
                                          "1",
                                          style: TextStyle(
                                              letterSpacing:
                                                  BibleInfo.letterSpacing,
                                              fontSize:
                                                  BibleInfo.fontSizeScale * 10,
                                              fontWeight: FontWeight.w600,
                                              color:
                                                  CommanColor.lightDarkPrimary(
                                                      context)),
                                          textAlign: TextAlign.center,
                                        )))
                                    : const SizedBox()
                              ])),
                          IconButton(
                              icon: Image.asset(
                                "assets/chapt_back.png",
                                color: CommanColor.lightDarkPrimary(context),
                                height: 20,
                                width: 20,
                              ),
                              onPressed: () {
                                if (selectedChapter - 1 != 0) {
                                  setState(() {
                                    selectedChapter > 1
                                        ? selectedChapter--
                                        : selectedChapter = 1;
                                  });
                                  setChapterContent();
                                  setState(() {});
                                  _stop();
                                  isSpeech == true ? _speak() : null;
                                } else {}
                              }),
                          IconButton(
                            icon: Image.asset(
                              "assets/previous_music.png",
                              color: CommanColor.lightDarkPrimary(context),
                              height: 20,
                              width: 20,
                            ),
                            onPressed: () {
                              setState(() {
                                curretNo != 0 ? curretNo = curretNo - 1 : null;
                                _newVoiceText =
                                    selectedChapterContent[curretNo].content;
                              });
                            },
                          ),
                          InkWell(
                              onTap: () {
                                setState(() {
                                  isInitialProgress = isInitialProgress + 1;
                                  isSpeech = !isSpeech;
                                });

                                isSpeech == true ? _speak() : _stop();
                                if (isInitialTime == true) {
                                  setState(() {
                                    end = _newVoiceText?.length ?? 0;
                                    isInitialTime = false;
                                  });
                                }
                              },
                              child: Container(
                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: CommanColor.lightDarkPrimary(
                                          context)),
                                  padding: const EdgeInsets.all(7),
                                  child: Image.asset(
                                    isSpeech == false
                                        ? "assets/play.png"
                                        : "assets/pause.png",
                                    color: Colors.white,
                                    height: 15,
                                    width: 15,
                                  ))),
                          IconButton(
                            icon: Image.asset(
                              "assets/next_music.png",
                              color: CommanColor.lightDarkPrimary(context),
                              height: 20,
                              width: 20,
                            ),
                            onPressed: () {
                              setState(() {
                                curretNo != selectedChapterContent.length - 1
                                    ? curretNo = curretNo + 1
                                    : null;
                                _newVoiceText =
                                    selectedChapterContent[curretNo].content;
                              });
                              _stop();
                              Future.delayed(
                                const Duration(milliseconds: 100),
                                () {
                                  isSpeech == true ? _speak() : null;
                                },
                              );
                            },
                          ),
                          IconButton(
                              icon: Image.asset(
                                "assets/chapt_next.png",
                                color: CommanColor.lightDarkPrimary(context),
                                height: 20,
                                width: 20,
                              ),
                              onPressed: () {
                                if (selectedChapter !=
                                    int.parse(widget.chapterCount.toString())) {
                                  if (context.mounted) {
                                    setState(() {
                                      selectedChapter++;
                                    });
                                    setChapterContent();
                                    setState(() {});
                                    _stop();
                                    isSpeech == true ? _speak() : null;
                                  }
                                }
                              }),
                          // Icon(Icons.pres,color: CommanColor.lightDarkPrimary(context),),
                          Padding(
                            padding: const EdgeInsets.only(right: 10.0),
                            child: InkWell(
                              onTap: () {
                                if (context.mounted) {
                                  setState(() {
                                    isSpeech = false;
                                  });
                                  _stop();
                                }
                              },
                              child: Image.asset(
                                "assets/stop.png",
                                color: CommanColor.lightDarkPrimary(context),
                                height: 18,
                                width: 18,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ));
            },
          );
        },
      ).then((value) {
        if (context.mounted) {
          setState(() {});
        }
      });
    } else {
      return Constants.showToast("Please wait");
    }
  }
}

// Define your audio handler class in a separate file (audio_handler.dart)

class AudioPlayerHandler extends BaseAudioHandler {
  final AudioPlayer _player = AudioPlayer();
  MediaItem? _currentItem;

  AudioPlayerHandler() {
    _player.onPlayerStateChanged.listen((state) {
      playbackState.add(playbackState.value.copyWith(
        playing: state == PlayerState.playing,
        processingState: _getProcessingState(state),
      ));
    });

    _player.onDurationChanged.listen((duration) {
      if (_currentItem != null) {
        mediaItem.add(_currentItem!.copyWith(duration: duration));
      }
    });

    _player.onPositionChanged.listen((position) {
      playbackState.add(playbackState.value.copyWith(
        updatePosition: position,
      ));
    });
  }

  AudioProcessingState _getProcessingState(PlayerState state) {
    switch (state) {
      case PlayerState.playing:
        return AudioProcessingState.ready;
      case PlayerState.paused:
        return AudioProcessingState.ready;
      case PlayerState.stopped:
        return AudioProcessingState.idle;
      case PlayerState.completed:
        return AudioProcessingState.completed;
      case PlayerState.disposed:
        return AudioProcessingState.idle;
    }
  }

  @override
  Future<void> play() => _player.resume();

  @override
  Future<void> pause() => _player.pause();

  @override
  Future<void> stop() {
    mediaItem.add(null);
    return _player.stop();
  }

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  Future<void> setAudio(String url, MediaItem item) async {
    _currentItem = item;
    await _player.setSourceUrl(url);
    mediaItem.add(item);
    playbackState.add(PlaybackState(
      controls: [MediaControl.play, MediaControl.pause, MediaControl.stop],
      systemActions: const {MediaAction.seek},
      processingState: AudioProcessingState.ready,
    ));
  }
}
