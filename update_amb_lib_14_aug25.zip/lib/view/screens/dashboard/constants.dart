class BibleInfo {
  static String apple_AppId = "6459793603";

  // 6484270584  //6459793603
  static String ios_Bundle_Id = "com.balaklrapps.amplifiedbible";
  static String bible_shortName = "Amplified Bible";
  static String current_Version = "1.0.30";
  static String android_Package_Name = "com.whitebibles.amplifiedbible";
  static String appID = 'd15e5a03-d755-11ef-ae3c-fa163e8c011b';
  //static int surveyAppId = 3;
  static String emailVerify = "0";

  static int appcount = 5;

  static String thankyoucontent = "";

  static String thankyoutitle = " 🙏 Help Us Keep the Bible App Free ";

  static int old_testament_count =
      39; //book count 65 - olt 39, book count 72 - olt 45
  static String new_testament_count = "27";

  static String exportText =
      'Save your Bookmarked verses, Highlights, Notes and Verse Images directly to your device. This option stores a backup file locally, which can be transferred or accessed later. You can import this file into the app whenever needed, even on another device.';
  static String importText = 'Please select the file you exported last time.';

  static String termsandConditionURL =
      "https://bibleoffice.com/terms_conditions.html";
  static String privacyPolicyURL =
      "https://bibleoffice.com/privacy_policy.html";

  static int imageMaxLines = 7;

  static const double fontSizeScale = 1.0;
  static const double letterSpacing = 0.4;
}
