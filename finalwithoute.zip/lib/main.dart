import 'dart:developer';
import 'package:biblebookapp/core/notifiers/auth/auth.notifier.dart';
import 'package:biblebookapp/core/notifiers/bottom.notifier.dart';
import 'package:biblebookapp/core/notifiers/cache.notifier.dart';
import 'package:biblebookapp/core/notifiers/download.notifier.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:biblebookapp/firebase_options.dart';
import 'package:biblebookapp/view/constants/share_preferences.dart';
import 'package:biblebookapp/view/screens/auth/splash.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart' as hooks;
import 'package:hooks_riverpod/hooks_riverpod.dart'
    hide ChangeNotifierProvider, Provider;
import 'package:provider/provider.dart';
import 'view/constants/theme_provider.dart';
import 'dart:async';
import 'package:timezone/data/latest.dart' as tz;

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  await dotenv.load(fileName: ".env");
  await GetStorage.init();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

  /// SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual);
  tz.initializeTimeZones();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  await SharPreferences.getString(SharPreferences.theme) ?? "notSave";

  configLoading();

  runApp(
    hooks.ProviderScope(
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (context) => ThemeProvider()),
          ChangeNotifierProvider(create: (context) => AuthNotifier()),
          ChangeNotifierProvider(create: (context) => CacheNotifier()),
          ChangeNotifierProvider(create: (context) => DownloadProvider()),
          ChangeNotifierProvider(
              create: (context) => HomeContentEditProvider()),
          // Add other providers here
        ],
        child: MyApp(),
      ),
    ),
  );
}

void configLoading() {
  EasyLoading.instance
    ..displayDuration = const Duration(milliseconds: 2000)
    ..indicatorType = EasyLoadingIndicatorType.fadingCircle
    ..loadingStyle = EasyLoadingStyle.custom
    ..indicatorSize = 45.0
    ..radius = 5.0
    ..backgroundColor = const Color.fromARGB(255, 130, 88, 88)
    ..textColor = Colors.white
    ..maskColor = Colors.white
    ..indicatorColor = Colors.white
    ..userInteractions = false
    ..dismissOnTap = true;
}

// var mode;
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  log('Remote Message: ${message.data}');
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
}

class MyApp extends hooks.StatefulHookConsumerWidget {
  const MyApp({super.key});

  @override
  ConsumerState<MyApp> createState() => _MyAppState();
}

class _MyAppState extends ConsumerState<MyApp> with WidgetsBindingObserver {
  bool _isAppInBackground = false;

  bool _isAppInActive = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Future<void> didChangeAppLifecycleState(AppLifecycleState state) async {
    final productprovider =
        Provider.of<DownloadProvider>(context, listen: false);
    switch (state) {
      case AppLifecycleState.paused:
        _isAppInBackground = true;
        _isAppInActive = false;
        break;
      case AppLifecycleState.inactive:
        if (_isAppInBackground) {
          _isAppInActive = true;
        }
        break;
      case AppLifecycleState.resumed:
        final checkad = await SharPreferences.getString('OpenAd') ?? "1";
        debugPrint("App is 2 $state. and $checkad   and $_isAppInActive");
        if (_isAppInBackground && checkad != '1' && _isAppInActive) {
          _isAppInBackground = false;
          _isAppInActive = false;
          await SharPreferences.setString('OpenAd', '0');
          // Only show ad if coming from background

          await initAppOpen();
          await productprovider.clearProductList();
        } else {
          await SharPreferences.setString('OpenAd', '0');
        }
        break;

      default:
        break;
    }
  }

  loadOpenAd() async {
    bool? isAdEnabledFromApi =
        await SharPreferences.getBoolean(SharPreferences.isAdsEnabledApi);
    if (isAdEnabledFromApi ?? true) {
      String? openAdUnitId =
          await SharPreferences.getString(SharPreferences.openAppId);
      AppOpenAd.load(
        adUnitId: openAdUnitId ?? '',
        request: await AdConsentManager.getAdRequest(),
        //orientation: 1,
        adLoadCallback: AppOpenAdLoadCallback(
          onAdLoaded: (ad) {
            ad.show();
          },
          onAdFailedToLoad: (error) {
            SharPreferences.setBoolean(SharPreferences.isAdsEnabled, false);
          },
        ),
      );
    }
  }

  initAppOpen() async {
    await SharPreferences.getString('test').then((value) async {
      if (value != null) {
        final data =
            await SharPreferences.getBoolean(SharPreferences.isAdsEnabled) ??
                true;
        // final data2 = await SharPreferences.getString('bottom') ?? '0';
        if (data) {
          loadOpenAd();
        }
      } else {
        await SharPreferences.setString('test', 'test');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Builder(
      builder: (context) {
        final themeProvider = Provider.of<ThemeProvider>(context);

        return GetMaterialApp(
          title: "Bible",
          debugShowCheckedModeBanner: false,
          themeMode: themeProvider.themeMode,
          theme: MyThemes.lightTheme(context, themeProvider.backgroundColor),
          darkTheme: MyThemes.darkTheme(context),
          home: const SplashScreen(),
          builder: EasyLoading.init(),
        );
      },
    );
  }
}

// class MyApp extends hooks.HookConsumerWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context, hooks.WidgetRef ref) {
//     return MultiProvider(
//       providers: [
//         ChangeNotifierProvider(create: (context) => ThemeProvider()),
//         ChangeNotifierProvider(create: (context) => AuthNotifier()),
//         ChangeNotifierProvider(create: (context) => CacheNotifier()),
//         ChangeNotifierProvider(create: (context) => DownloadProvider()),
//         // Add other providers here
//       ],
//       child: Builder(
//         builder: (context) {
//           final themeProvider = Provider.of<ThemeProvider>(context);

//           return GetMaterialApp(
//             title: "Bible",
//             debugShowCheckedModeBanner: false,
//             themeMode: themeProvider.themeMode,
//             theme: MyThemes.lightTheme(context, themeProvider.backgroundColor),
//             darkTheme: MyThemes.darkTheme(context),
//             home: const SplashScreen(),
//             builder: EasyLoading.init(),
//           );
//         },
//       ),
//     );
//   }
// }

// initAppFlow() async {
//   final existingConsent = await ConsentManager.getConsent();

//   if (existingConsent == null) {
//     bool userConsent = false;

//     if (Platform.isIOS) {
//       final status = await AppTrackingTransparency.trackingAuthorizationStatus;
//       if (status == TrackingStatus.notDetermined) {
//         final newStatus =
//             await AppTrackingTransparency.requestTrackingAuthorization();
//         userConsent = newStatus == TrackingStatus.authorized;
//       } else {
//         userConsent = status == TrackingStatus.authorized;
//       }

//       await ConsentManager.saveConsent(userConsent);
//     } else {
//       // For Android: assume tracking allowed unless you show a custom dialog
//       userConsent = true;
//       await ConsentManager.saveConsent(userConsent);
//     }
//   }

//   await MobileAds.instance.initialize();
// }

// class MyApp extends hooks.HookConsumerWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context, hooks.WidgetRef ref) {
//     return ChangeNotifierProvider(
//       create: (context) => ThemeProvider(),
//       builder: (context, _) {
//         final themeProvider = Provider.of<ThemeProvider>(context);
//         return GetMaterialApp(
//           title: "Bible",
//           debugShowCheckedModeBanner: false,
//           themeMode: themeProvider.themeMode,
//           theme: MyThemes.lightTheme(context),
//           darkTheme: MyThemes.darkTheme(context),
//           home: const SplashScreen(),
//           builder: EasyLoading.init(),
//         );
//       },
//     );
//   }
// }

// ///
// // Copyright 2013 The Flutter Authors. All rights reserved.
// // Use of this source code is governed by a BSD-style license that can be
// // found in the LICENSE file.
/*
 * Copyright (c) 2019-2023 Larry Aasen. All rights reserved.
 */

enum Availability { loading, available, unavailable }
