import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui';
import 'dart:ui' as ui;
import 'package:app_tracking_transparency/app_tracking_transparency.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:biblebookapp/Model/dailyVerseList.dart';
import 'package:biblebookapp/controller/dashboard_controller.dart';
import 'package:biblebookapp/controller/dpProvider.dart';
import 'package:biblebookapp/core/export_db.dart';
import 'package:biblebookapp/core/notifiers/auth/auth.notifier.dart';
import 'package:biblebookapp/core/notifiers/cache.notifier.dart';
import 'package:biblebookapp/core/notifiers/download.notifier.dart';
import 'package:biblebookapp/main.dart';
import 'package:biblebookapp/view/constants/colors.dart';
import 'package:biblebookapp/view/constants/theme_provider.dart';
import 'package:biblebookapp/view/screens/auth/splash.dart';
import 'package:biblebookapp/view/screens/books/books_screen.dart';
import 'package:biblebookapp/view/screens/calendar_screen/view/calendar_screen.dart';
import 'package:biblebookapp/view/screens/category_detail_screen/view/image_detail_screen.dart';
import 'package:biblebookapp/view/screens/dashboard/constants.dart';

import 'package:biblebookapp/view/screens/dashboard/mark_as_read_screen.dart';
import 'package:biblebookapp/view/screens/dashboard/myLibrary.dart';
import 'package:biblebookapp/view/screens/dashboard/Search.dart';
import 'package:biblebookapp/view/screens/dashboard/dailyverse.dart';
import 'package:biblebookapp/view/screens/dashboard/fActionButton.dart';
import 'package:biblebookapp/view/screens/dashboard/remove_add-screen.dart';
import 'package:biblebookapp/view/screens/dashboard/setting_screen.dart';
import 'package:biblebookapp/view/screens/more_apps/more_apps_screen.dart';
import 'package:biblebookapp/view/screens/profile/view/profile_screen.dart';
import 'package:biblebookapp/view/screens/quote_screen/quote_screen.dart';
import 'package:biblebookapp/view/screens/wallpaper_screen/wallpaper_screen.dart';
import 'package:biblebookapp/view/widget/adhelper.dart';
import 'package:biblebookapp/view/widget/notification_service.dart';

import 'package:biblebookapp/view/widget/verse_item_widget.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:in_app_review/in_app_review.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import 'package:scroll_to_index/scroll_to_index.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:upgrader/upgrader.dart';
import '../../../Model/verseBookContentModel.dart';
import '../../constants/changeThemeButtun.dart';
import 'package:html/parser.dart' show parse;
import '../../constants/constant.dart';
import '../../constants/images.dart';
import '../../constants/share_preferences.dart';
import '../../widget/home_content_edit_bottom_sheet.dart';
import '../authenitcation/view/login_screen.dart';
import 'book_list_screen.dart';
import 'chapterListScreen.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart' as p;

// ignore: must_be_immutable
class HomeScreen extends StatefulWidget with WidgetsBindingObserver {
  var selectedBookForRead;
  var selectedBookNameForRead;
  var selectedChapterForRead;
  var selectedVerseNumForRead;
  var selectedVerseForRead;
  var From;

  HomeScreen(
      {super.key,
      required this.selectedBookForRead,
      required this.selectedChapterForRead,
      required this.selectedVerseNumForRead,
      required this.From,
      required this.selectedBookNameForRead,
      required this.selectedVerseForRead});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final ValueNotifier<int> _rating = ValueNotifier<int>(0);

  final ValueNotifier<bool> _showFeedbackButton = ValueNotifier<bool>(false);

  final ValueNotifier<DateTime?> lastIntertitialAdPlayed = ValueNotifier(null);

  final ValueNotifier<String> adsDuration = ValueNotifier('0');
  late List<ConnectivityResult> result;
  final Connectivity _connectivity = Connectivity();
  final InAppReview inAppReview = InAppReview.instance;
  final AdService _adService = AdService();

  String? RewardAdExpireDate;
  String? selectedcolor;
  void _setRating(int rating) {
    _rating.value = rating;
    _showFeedbackButton.value = rating >= 4;
  }

  double _fontSize = 19.0;
  bool _scrollListenerAttached = false;

// daily verse
  List<DailyVerseList> dailyVerseList = [];
  final bool _hasShownVerseToday = false;
  DateTime? _lastShownTime;

  loadAds() async {
    final shouldLoadAd = await SharPreferences.shouldLoadAd();

    if (shouldLoadAd) {
      //
      //

      debugPrint("ad is called");
      _adService.loadBannerAd(() {
        if (mounted) {
          setState(() {});
        }
      });
    }
  }

  final GlobalKey _verseContainerKey = GlobalKey();
  Future<void> loadInterstitialAd(DashBoardController controller) async {
    final currentDate = DateTime.now();
    int duration = int.tryParse(adsDuration.value) ?? 0;

    if (lastIntertitialAdPlayed.value == null) {
      if (controller.isInterstitialAdLoad.value &&
          controller.adFree.value == false) {
        try {
          await controller.interstitialAd?.show();
          lastIntertitialAdPlayed.value = DateTime.now();
        } catch (e) {
          debugPrint('Eror Loading Interstitial Ad:$e');
        }
      }
    } else {
      if (duration != 0) {
        final diff =
            currentDate.difference(lastIntertitialAdPlayed.value!).inMinutes;
        if ((diff) > duration) {
          if (controller.isInterstitialAdLoad.value &&
              controller.adFree.value == false) {
            try {
              await controller.interstitialAd?.show();
              lastIntertitialAdPlayed.value = DateTime.now();
            } catch (e) {
              debugPrint('Eror Loading Interstitial Ad:$e');
            }
          }
        }
      } else {
        if (controller.isInterstitialAdLoad.value &&
            controller.adFree.value == false) {
          try {
            await controller.interstitialAd?.show();
            lastIntertitialAdPlayed.value = DateTime.now();
          } catch (e) {
            debugPrint('Eror Loading Interstitial Ad:$e');
          }
        }
      }
    }
  }

  bool isAdReady = false;

  void _handleReward() async {
    await SharPreferences.setBoolean("downloadreward", true);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('You earned a reward!, Now you can download')),
    );
    // Do your logic like increase appCount etc.
  }

  Future<void> _handleAdDismissed() async {
    if (mounted) {
      setState(() => isAdReady = false);
    }
    await SharPreferences.setString('OpenAd', '1');
    RewardedAdService.loadAd(onAdLoaded: () {
      if (mounted) {
        setState(() => isAdReady = true);
      }
    });
  }

  String? message;
  bool adsIcon = true;
  bool isLoggedIn = false;

  final AdService adService = AdService();
  int swipeCount = 0;
  int _swipeThreshold = 7;
  int appLaunchCount = 0;
  int appLaunchCountoffer = 0;
  Availability availability = Availability.loading;
  String? sixMonthPlan;
  String? oneYearPlan;
  String? lifeTimePlan;
  int clickCount = 0;
  List<DailyVerseList> filteredList = [];
  final audioPlayer = AudioPlayer();
  bool _isBottomSheetOpen = false;

  void _handledownloadClick() async {
    bool? isCheckcount = await SharPreferences.getBoolean("downloadreward");
    if (mounted) {
      setState(() async {
        clickCount++;
        if (clickCount == 3) {
          setdownloadreward();
          await SharPreferences.setString('OpenAd', '1');
          _showLimitDialog();
        }
      });
    }
  }

  Future<void> _loadFontSize() async {
    final prefs = await SharedPreferences.getInstance();
    final value = prefs.getString(SharPreferences.selectedFontSize);
    if (mounted) {
      setState(() {
        _fontSize = value != null ? double.tryParse(value) ?? 19.0 : 19.0;
      });
    }
  }

  setdownloadreward() async {
    await SharPreferences.setBoolean("downloadreward", false);
    if (mounted) {
      setState(() {
        clickCount = 0;
      });
    }
  }

  void _showLimitDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
          backgroundColor: CommanColor.white,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Get Unlimited Downloads!',
                  style: CommanStyle.bw20500(context),
                ),
                const SizedBox(height: 16),
                Text(
                  'You’ve reached your daily limit of 3 image downloads.',
                  textAlign: TextAlign.left,
                  style: CommanStyle.bw16500(context)
                      .copyWith(fontWeight: FontWeight.w400),
                ),
                const SizedBox(height: 16),
                Text('To continue downloading:',
                    style: CommanStyle.bw15500(context).copyWith(
                        fontWeight: FontWeight.w400,
                        decoration: TextDecoration.none)),
                const SizedBox(height: 20),

                // Buy Premium Row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    //Icon(Icons.diamond, color: Colors.brown),
                    Image.asset(
                      'assets/Asset1.png',
                      height: 25,
                      width: 25,
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Buy Premium',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Unlock unlimited downloads and remove all limits',
                            style: CommanStyle.bw16500(context)
                                .copyWith(fontWeight: FontWeight.w400),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Watch Ad Row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Icon(Icons.ondemand_video, color: Colors.brown),
                    Image.asset(
                      'assets/Asset5.png',
                      height: 25,
                      width: 25,
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Watch an Ad',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Instantly download this image by watching a short ad',
                            style: CommanStyle.bw16500(context)
                                .copyWith(fontWeight: FontWeight.w400),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Buttons
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(
                      onPressed: () async {
                        final sixMonthPlan =
                            await SharPreferences.getString('sixMonthPlan');
                        final oneYearPlan =
                            await SharPreferences.getString('oneYearPlan');
                        final lifeTimePlan =
                            await SharPreferences.getString('lifeTimePlan');
                        setState(() {
                          clickCount = 0;
                        });
                        if (context.mounted) {
                          Navigator.pop(context);
                          // Handle buy premium
                          adsIcon = false;
                          Get.to(() => RemoveAddScreen(
                                sixMonthPlan: sixMonthPlan ?? '',
                                oneYearPlan: oneYearPlan ?? '',
                                lifeTimePlan: lifeTimePlan ?? '',
                                onclick: () {
                                  setState(() {
                                    clickCount = 2;
                                  });
                                },
                              ));
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: CommanColor.lightModePrimary200,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      child: Text(
                        'Buy Premium',
                        textAlign: TextAlign.center,
                        style: CommanStyle.white14500.copyWith(
                            fontSize: 12, fontWeight: FontWeight.w500),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        // Handle watch ad
                        if (isAdReady) {
                          RewardedAdService.showAd(
                            onRewardEarned: _handleReward,
                            onAdDismissed: _handleAdDismissed,
                          );
                        } else {
                          Constants.showToast("Ad not available");
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: CommanColor.lightModePrimary200,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        'Watch Ad',
                        style: CommanStyle.white14500.copyWith(
                            fontSize: 12, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          )),
    );
  }

  checkuserloggedin() async {
    final adProvider = DownloadProvider();
    await adProvider.init();
    final cacheprovider = Provider.of<CacheNotifier>(context, listen: false);
    result = await _connectivity.checkConnectivity();
    await checkingappcount(result);
    final data = await cacheprovider.readCache(key: 'user');
    // final dataname = await cacheprovider.readCache(key: 'name');

    final datacount =
        await SharPreferences.getString(SharPreferences.showinterstitialrow);

    _swipeThreshold = int.parse(datacount ?? "7");

    //   debugPrint("ad count is $_swipeThreshold");
    final shouldLoadAd = await SharPreferences.shouldLoadAd();

    debugPrint("ad count is $_swipeThreshold  $shouldLoadAd");
    if (shouldLoadAd) {
      //
      //
      debugPrint("ad int is 0");
      adService.loadInterstitialAd(() {
        debugPrint("ad int is 1");
        if (mounted) {
          setState(() {});
        }
        debugPrint("ad int is 2");
      });
    }
    if (data != null) {
      if (mounted) {
        setState(() {
          isLoggedIn = true;
        });
      }
    } else {
      if (mounted) {
        setState(() {
          isLoggedIn = false;
        });
      }
    }
  }

  Future<void> _checkAndShowOfferDialog() async {
    int randomNumber = 0;
    final dataprovider = Provider.of<AuthNotifier>(context, listen: false);
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool isDialogShown = prefs.getBool('offerDialogShown') ?? false;
    appLaunchCount = prefs.getInt('launchCount') ?? 0;
    appLaunchCountoffer = prefs.getInt('launchCountoffer') ?? 0;
    //appLaunchCount++;
    // appLaunchCountoffer++;
    // await prefs.setInt('launchCount', appLaunchCount);
    await Future.delayed(
      Duration(seconds: 2),
    );
    await NotificationsServices().initialiseNotifications();
    // await prefs.setInt('launchCountoffer', appLaunchCountoffer);
    debugPrint("offer dialog is open $isDialogShown  ");

    await SharPreferences.setBoolean("downloadreward", true);

    if (isDialogShown == false) {
      // Show the dialog
      final data2 = prefs.getString("alrt") ?? '0';

      if (data2 != '1') {
        await Future.delayed(
          Duration(seconds: 1),
        );
        final check = await Permission.notification.isGranted;

        debugPrint("check nofi $check");
        if (check) {
          await SharPreferences.setString('OpenAd', '1');
          await showNotificationDialog(context, () async {
            await SharPreferences.setString('OpenAd', '1');
            return _checkAndShowOfferDialog();
          });
        } else {
          await prefs.setString("alrt", "1");
          final data = prefs.getString("notifiyalrt");
          if (data != '1') {
            await prefs.setString("notifiyalrt", '0');
          }

          _checkAndShowOfferDialog();
        }
      }

      final data = prefs.getString("notifiyalrt");

      if (data == '0') {
        Random random = Random();
        await Future.delayed(Duration(minutes: 1));
        final bookofferdata = await dataprovider.getofferbook();

        if (bookofferdata != null && bookofferdata.isNotEmpty) {
          if (mounted) {
            setState(() {
              randomNumber = random.nextInt(bookofferdata.length);
            });
          }
          await prefs.setString("notifiyalrt", '1');
          await Future.delayed(Duration.zero, () async {
            await SharPreferences.setString('OpenAd', '1');
            if (mounted) {
              return await showGiftDialog(context, bookofferdata[randomNumber]);
            }
          });
          // await Future.delayed(Duration(seconds: 2), () {});
        }
      }
    }
  }

  authObserver(User? user) async {
    if (user == null) {
      if (isLoggedIn) {
        if (mounted) {
          setState(() {
            isLoggedIn = false;
          });
        }
      }
    } else if (user.emailVerified) {
      isLoggedIn = true;
    } else {
      isLoggedIn = true;
    }
  }

  updateLoading(bool val, {String? mess}) {
    if (val) {
      EasyLoading.show(status: mess);
    } else {
      EasyLoading.dismiss();
    }
    setState(() {
      message = mess;
    });
  }

  @override
  void initState() {
    super.initState();
    _loadFontSize();
    checkuserloggedin();
    // _checkAndShowOfferDialog();
    dailyVerseData();
    _checkAndShowVerse();

    RewardedAdService.loadAd(onAdLoaded: () {
      if (mounted) {
        setState(() => isAdReady = true);
      }
    });
    // FirebaseAuth.instance.authStateChanges().listen(authObserver);
  }

  checkscreen() {
    // First get the FlutterView.
    FlutterView view = WidgetsBinding.instance.platformDispatcher.views.first;

// Dimensions in physical pixels (px)
    Size size = view.physicalSize;
    double width = size.width;
    double height = size.height;

    debugPrint("sz current width - $width ");
  }

  Future<void> requestReview(List<ConnectivityResult> connectionStatus) async {
    // bool hasConnection = connectionStatus.first == ConnectivityResult.wifi ||
    //         connectionStatus.first == ConnectivityResult.mobile
    //     ? true
    //     : false;

    if (connectionStatus.first == ConnectivityResult.wifi ||
        connectionStatus.first == ConnectivityResult.mobile) {
      if (await inAppReview.isAvailable()) {
        await inAppReview.requestReview();
      } else {
        Constants.showToast("Service not available at the moment");
      }
    } else {
      Constants.showToast("No internet connection");
    }
  }

  void _checkAndShowVerse() async {
    final prefs = await SharedPreferences.getInstance();
    // final lastShownDate = prefs.getString('last_shown_verse_date');
    // final now = DateTime.now();
    // final todayString = DateFormat('yyyy-MM-dd').format(now);
    // debugPrint("test0");
    final lastShownDateRaw = prefs.getString('last_shown_verse_date');
    final now = DateTime.now();
    final todayString = DateFormat('yyyy-MM-dd').format(now);
    debugPrint("test0");

// Format last shown date safely
    String lastShownDateFormatted = '';
    if (lastShownDateRaw != null) {
      try {
        final parsed = DateTime.parse(lastShownDateRaw);
        lastShownDateFormatted = DateFormat('yyyy-MM-dd').format(parsed);
      } catch (e) {
        debugPrint('⚠️ Invalid lastShownDate format: $lastShownDateRaw');
      }
    }
    // Check if we've shown a verse today
    if (lastShownDateFormatted != todayString) {
      // Wait for 3 minutes
      debugPrint("test1");
      Future.delayed(Duration(seconds: 2), () {
        debugPrint("test2");
        if (context.mounted) {
          debugPrint("test3");

          return _showDailyVerseBottomSheet(_fontSize);
        }
      });
    }
  }

  _showDailyVerseBottomSheet(fontSize) async {
    final prefs = await SharedPreferences.getInstance();
    if (dailyVerseList.isEmpty || !mounted) return;

    // Find today's verse
    final todayString = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final todayVerse = dailyVerseList.firstWhere(
      (verse) => verse.date.toString().startsWith(todayString),
      orElse: () => dailyVerseList.first,
    );

    // Random background image
    final random = Random();
    final bgImages = [
      "assets/im1.jpg",
      "assets/im2.jpg",
      "assets/im3.jpg",
      "assets/im4.jpg",
      "assets/im5.jpg",
    ];
    String randomBgImage = bgImages[random.nextInt(bgImages.length)];
    // Save today's date to prefs
    await prefs.setString('last_shown_verse_date', todayString);
    await Future.delayed(Duration(seconds: 1));
    if (_isBottomSheetOpen) return;

    _isBottomSheetOpen = true;

    await showModalBottomSheet(
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      context: context,
      enableDrag: false,
      builder: (context) {
        double screenWidth = MediaQuery.of(context).size.width;
        return StatefulBuilder(
            builder: (BuildContext context, StateSetter setState) {
          return FractionallySizedBox(
            heightFactor: screenWidth < 380
                ? 0.85
                : screenWidth > 450
                    ? 0.79
                    : 0.73,
            child: GestureDetector(
              onTap: () {
                setState(
                  () {
                    randomBgImage = bgImages[random.nextInt(bgImages.length)];
                  },
                );
              },
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(5)),
                  // image: DecorationImage(
                  //   image: AssetImage(randomBgImage),
                  //   fit: BoxFit.cover,
                  // ),
                ),
                padding: EdgeInsets.all(7),
                child: Column(
                  //  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: EdgeInsets.all(screenWidth < 380 ? 3 : 8.0),
                      child: RepaintBoundary(
                        key: _verseContainerKey,
                        child: FramedVerseContainer(
                          backgroundImagePath: randomBgImage,
                          showFrame: Random()
                              .nextBool(), // or true/false based on your logic
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 4.0),
                                  child: Align(
                                    alignment: Alignment.topCenter,
                                    child: Text(
                                      "Verse of the Day",
                                      style: TextStyle(
                                        color: CommanColor.white,
                                        decoration: TextDecoration.underline,
                                        decorationColor: Colors
                                            .white, // Set your desired color
                                        decorationThickness: 2.0,
                                        fontSize: screenWidth < 380
                                            ? 16
                                            : screenWidth > 450
                                                ? 34
                                                : 20,
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                  ),
                                ),

                                SizedBox(height: 2),
                                Align(
                                  alignment: Alignment.center,
                                  child: AutoSizeHtmlWidget(
                                    html: todayVerse.verse.toString(),
                                    maxLines: 16,
                                    color: CommanColor.white,
                                    maxFontSize: screenWidth < 380
                                        ? BibleInfo.fontSizeScale * 14.5
                                        : screenWidth > 450
                                            ? BibleInfo.fontSizeScale * 31
                                            : DashBoardController()
                                                    .fontSize
                                                    .value -
                                                0.9,
                                    minFontSize:
                                        screenWidth < 380 ? 11.5 : 10.9,
                                  ),
                                  // HtmlWidget(
                                  //   todayVerse.verse.toString(),
                                  //   textStyle: TextStyle(
                                  //     color: CommanColor.white,
                                  //     fontSize: screenWidth < 380
                                  //         ? BibleInfo.fontSizeScale * 14
                                  //         : screenWidth > 450
                                  //             ? BibleInfo.fontSizeScale * 31
                                  //             : fontSize,
                                  //   ),
                                  // ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 3.0),
                                  child: Align(
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      "${todayVerse.book} ${todayVerse.chapter}:${todayVerse.verseNum}",
                                      style: TextStyle(
                                        color: CommanColor.white,
                                        fontStyle: FontStyle.italic,
                                        fontSize: screenWidth < 380
                                            ? 14
                                            : screenWidth > 450
                                                ? BibleInfo.fontSizeScale * 28
                                                : fontSize - 4,
                                      ),
                                    ),
                                  ),
                                ),

                                // Verse content
                                // Expanded(
                                //   child: HtmlWidget(
                                //     todayVerse.verse.toString(),
                                //     textStyle: TextStyle(
                                //       color: Colors.black,
                                //       fontSize: screenWidth < 380
                                //           ? BibleInfo.fontSizeScale * 14
                                //           : screenWidth > 450
                                //               ? BibleInfo.fontSizeScale * 30
                                //               : fontSize,
                                //     ),
                                //     customWidgetBuilder: (element) {
                                //       return Padding(
                                //         padding: const EdgeInsets.only(top: 6),
                                //         child: Align(
                                //           alignment: Alignment.centerRight,
                                //           child: Text(
                                //             "${todayVerse.book} ${todayVerse.chapter}:${todayVerse.verseNum}",
                                //             style: TextStyle(
                                //               color: Colors.black87,
                                //               fontStyle: FontStyle.italic,
                                //               fontSize: screenWidth < 380
                                //                   ? 14
                                //                   : screenWidth > 450
                                //                       ? BibleInfo
                                //                               .fontSizeScale *
                                //                           28
                                //                       : fontSize,
                                //             ),
                                //           ),
                                //         ),
                                //       );
                                //     },
                                //   ),
                                // ),

                                // Verse reference
                                // Padding(
                                //   padding:
                                //       const EdgeInsets.symmetric(vertical: 4),
                                //   child: Row(
                                //     mainAxisAlignment: MainAxisAlignment.end,
                                //     children: [
                                //       Text(
                                //         "${todayVerse.book} ${todayVerse.chapter}:${todayVerse.verseNum}",
                                //         style: TextStyle(
                                //           color: Colors.black,
                                //           fontSize: screenWidth < 380
                                //               ? 14
                                //               : screenWidth > 450
                                //                   ? 22
                                //                   : 14.5,
                                //           fontStyle: FontStyle.italic,
                                //         ),
                                //         textAlign: TextAlign.center,
                                //       ),
                                //     ],
                                //   ),
                                // ),

                                // App attribution
                                Padding(
                                  padding:
                                      const EdgeInsets.only(top: 4, right: 6),
                                  child: Align(
                                    alignment: Alignment.bottomLeft,
                                    child: Opacity(
                                      opacity: 0.8,
                                      child: Image.asset(
                                        "assets/Icon-1024.png",
                                        height: screenWidth < 380
                                            ? 24
                                            : screenWidth > 450
                                                ? 50
                                                : 30,
                                        width: screenWidth < 380
                                            ? 24
                                            : screenWidth > 450
                                                ? 50
                                                : 30,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.end,
                    //   children: [
                    //     SizedBox(height: 7),
                    //     Text(
                    //       DateFormat('dd/MM/yyyy').format(DateTime.now()),
                    //       style: TextStyle(
                    //         color: Colors.black,
                    //         fontSize: 16,
                    //       ),
                    //       textAlign: TextAlign.center,
                    //     ),
                    //   ],
                    // ),

                    // SizedBox(height: 20),

                    // // Verse content
                    // Expanded(
                    //   child: SingleChildScrollView(
                    //     child: Column(
                    //       children: [
                    //         HtmlWidget(
                    //           todayVerse.verse.toString(),
                    //           textStyle: const TextStyle(
                    //             color: Colors.black,
                    //             fontSize: BibleInfo.fontSizeScale * 20,
                    //           ),
                    //         )

                    //         // Text(
                    //         //   todayVerse.verse.toString(),
                    //         //   style: TextStyle(
                    //         //     fontSize: 20,
                    //         //     color: Colors.black,
                    //         //     height: 1.5,
                    //         //   ),
                    //         //   textAlign: TextAlign.center,
                    //         // ),
                    //       ],
                    //     ),
                    //   ),
                    // ),

                    // SizedBox(height: 7),

                    // // Verse reference
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.end,
                    //   children: [
                    //     Text(
                    //       "${todayVerse.book} ${todayVerse.chapter}:${todayVerse.verseNum}",
                    //       style: TextStyle(
                    //         color: Colors.black,
                    //         fontSize: 18,
                    //         fontStyle: FontStyle.italic,
                    //       ),
                    //       textAlign: TextAlign.center,
                    //     ),
                    //   ],
                    // ),

                    // SizedBox(height: 29),

                    // // App attribution
                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.center,
                    //   children: [
                    //     Image.asset(
                    //       "assets/Icon-1024.png",
                    //       height: 30,
                    //       width: 30,
                    //     ),
                    //     SizedBox(width: 10),
                    //     Column(
                    //       crossAxisAlignment: CrossAxisAlignment.start,
                    //       children: [
                    //         Text(
                    //           BibleInfo.bible_shortName,
                    //           style: TextStyle(
                    //             color: Colors.black,
                    //             fontSize: 16,
                    //           ),
                    //         ),
                    //         Text(
                    //           "Search in AppStore",
                    //           style: TextStyle(
                    //             color: Colors.black,
                    //             fontSize: 14,
                    //           ),
                    //         ),
                    //       ],
                    //     ),
                    //   ],
                    // ),

                    SizedBox(
                        height: screenWidth < 380
                            ? 5
                            : screenWidth > 450
                                ? 13
                                : 9),

                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          GestureDetector(
                            onTap: () async {
                              Provider.of<DownloadProvider>(context,
                                      listen: false)
                                  .incrementBookmarkCount(context);
                              // final box =
                              //     context.findRenderObject() as RenderBox?;
                              // await Share.share(
                              //   "${todayVerse.verse}\n\n${todayVerse.book} ${todayVerse.chapter}:${todayVerse.verseNum}\n\nDownload app: ${Platform.isAndroid ? 'https://play.google.com/store/apps/details?id=${(await PackageInfo.fromPlatform()).packageName}' : 'https://itunes.apple.com/app/id${BibleInfo.apple_AppId}'}",
                              //   sharePositionOrigin:
                              //       box!.localToGlobal(Offset.zero) & box.size,
                              // );
                              // Capture the verse as an image
                              RenderRepaintBoundary boundary =
                                  _verseContainerKey.currentContext
                                          ?.findRenderObject()
                                      as RenderRepaintBoundary;
                              ui.Image image =
                                  await boundary.toImage(pixelRatio: 3.0);
                              ByteData? byteData = await image.toByteData(
                                  format: ui.ImageByteFormat.png);
                              Uint8List pngBytes =
                                  byteData!.buffer.asUint8List();
                              //  await saveAndShare(pngBytes, "", "");
                              final directory = await getTemporaryDirectory();
                              final image1 =
                                  File("${directory.path}/dailyverse.png");
                              image1.writeAsBytesSync(pngBytes);
                              // Share the image using XFile
                              final xFile = XFile(image1.path);
                              //await Share.shareXFiles([xFile]);
                              await Share.shareXFiles([xFile],
                                  subject: '${BibleInfo.bible_shortName} app',
                                  text: "",
                                  sharePositionOrigin: Rect.fromPoints(
                                      const Offset(2, 2), const Offset(3, 3)));
                            },
                            child: Container(
                              width: screenWidth < 380
                                  ? 39
                                  : screenWidth > 450
                                      ? 67
                                      : 45,
                              height: screenWidth < 380
                                  ? 39
                                  : screenWidth > 450
                                      ? 67
                                      : 45,
                              padding: EdgeInsets.all(1),
                              decoration: BoxDecoration(
                                color: CommanColor.darkPrimaryColor
                                    .withValues(alpha: 0.7),
                                shape: BoxShape.circle,
                              ),
                              child: Center(
                                child: Image.asset(
                                  "assets/icons/share34.png",
                                  height: screenWidth < 380
                                      ? 21
                                      : screenWidth > 450
                                          ? 40
                                          : 25,
                                  width: screenWidth < 380
                                      ? 21
                                      : screenWidth > 450
                                          ? 40
                                          : 25,
                                ),
                                // Icon(Icons.share,
                                //     color: Colors.white,
                                //     size: screenWidth < 380
                                //         ? 19
                                //         : screenWidth > 450
                                //             ? 25
                                //             : 23),
                              ),
                              // ElevatedButton(
                              //   onPressed: () async {
                              //     final box =
                              //         context.findRenderObject() as RenderBox?;
                              //     await Share.share(
                              //       "${todayVerse.verse}\n\n${todayVerse.book} ${todayVerse.chapter}:${todayVerse.verseNum}\n\nDownload app: ${Platform.isAndroid ? 'https://play.google.com/store/apps/details?id=${(await PackageInfo.fromPlatform()).packageName}' : 'https://itunes.apple.com/app/id${BibleInfo.apple_AppId}'}",
                              //       sharePositionOrigin:
                              //           box!.localToGlobal(Offset.zero) & box.size,
                              //     );
                              //   },
                              //   style: ElevatedButton.styleFrom(
                              //     backgroundColor: CommanColor.darkPrimaryColor,
                              //     shape: CircleBorder(),
                              //     padding: EdgeInsets.all(15),
                              //     elevation: 2,
                              //   ),
                              //   child: Icon(Icons.share,
                              //       color: Colors.white, size: 24),
                              // ),
                            ),
                          ),

                          // Amen Button
                          ElevatedButton.icon(
                            onPressed: () {
                              // ScaffoldMessenger.of(context).showSnackBar(
                              //   SnackBar(content: Text("Amen!")),
                              // );
                              Constants.showToast("Amen!");
                              Navigator.of(context).pop();
                            },
                            icon: Image.asset(
                              "assets/icons/cross1.png",
                              height: screenWidth < 380
                                  ? 19
                                  : screenWidth > 450
                                      ? 40
                                      : 25,
                              width: screenWidth < 380
                                  ? 19
                                  : screenWidth > 450
                                      ? 40
                                      : 25,
                            ),
                            label: Text("AMEN",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: screenWidth < 380
                                        ? 14
                                        : screenWidth > 450
                                            ? 19
                                            : null)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: CommanColor.darkPrimaryColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 20,
                                  vertical: screenWidth < 380
                                      ? 6
                                      : screenWidth > 450
                                          ? 16
                                          : 12),
                            ),
                          ),
                          GestureDetector(
                            onTap: () async {
                              try {
                                // Show loading indicator
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Row(
                                      children: [
                                        CircularProgressIndicator(
                                            color: Colors.white),
                                        SizedBox(width: 10),
                                        Text("Saving verse...",
                                            style:
                                                TextStyle(color: Colors.white)),
                                      ],
                                    ),
                                    backgroundColor: Colors.black87,
                                    duration: Duration(seconds: 2),
                                  ),
                                );

                                // Capture the verse as an image
                                RenderRepaintBoundary boundary =
                                    _verseContainerKey.currentContext
                                            ?.findRenderObject()
                                        as RenderRepaintBoundary;
                                ui.Image image =
                                    await boundary.toImage(pixelRatio: 3.0);
                                ByteData? byteData = await image.toByteData(
                                    format: ui.ImageByteFormat.png);
                                Uint8List pngBytes =
                                    byteData!.buffer.asUint8List();

                                await saveImageIntoLocal(pngBytes, context);
                                // Show success message
                                ScaffoldMessenger.of(context)
                                    .hideCurrentSnackBar();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      Platform.isAndroid
                                          ? "Verse saved to Gallery"
                                          : "Verse saved to Photos",
                                      style: TextStyle(color: Colors.white),
                                    ),
                                    backgroundColor: Colors.green,
                                    behavior: SnackBarBehavior.floating,
                                    duration: Duration(seconds: 2),
                                  ),
                                );
                              } catch (e) {
                                ScaffoldMessenger.of(context)
                                    .hideCurrentSnackBar();
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                        "Failed to save: ${e.toString()}",
                                        style: TextStyle(color: Colors.white)),
                                    backgroundColor: Colors.red,
                                    behavior: SnackBarBehavior.floating,
                                    duration: Duration(seconds: 2),
                                  ),
                                );
                              }
                            },
                            child: Container(
                              width: screenWidth < 380
                                  ? 39
                                  : screenWidth > 450
                                      ? 67
                                      : 45,
                              height: screenWidth < 380
                                  ? 39
                                  : screenWidth > 450
                                      ? 67
                                      : 45,
                              padding: EdgeInsets.all(1),
                              decoration: BoxDecoration(
                                color: CommanColor.darkPrimaryColor
                                    .withValues(alpha: 0.7),
                                shape: BoxShape.circle,
                              ),
                              child: Center(
                                child: Image.asset(
                                  "assets/icons/download34.png",
                                  height: screenWidth < 380
                                      ? 21
                                      : screenWidth > 450
                                          ? 40
                                          : 25,
                                  width: screenWidth < 380
                                      ? 21
                                      : screenWidth > 450
                                          ? 40
                                          : 25,
                                ),
                                //  Icon(Icons.download,
                                //     color: Colors.white,
                                //     size: screenWidth < 380
                                //         ? 19
                                //         : screenWidth > 450
                                //             ? 25
                                //             : 23),
                              ),
                            ),
                          ),
                        ]),
                    SizedBox(
                      height: 1,
                    )
                  ],
                ),
              ),
            ),
          );
        });
      },
    );
    _isBottomSheetOpen = false;
    if (_isBottomSheetOpen == false) {
      await _checkAndShowOfferDialog();
    }
    // showModalBottomSheet(
    //   context: context,
    //   builder: (context) {
    //     return Container(
    //       padding: EdgeInsets.all(16),
    //       child: Column(
    //         mainAxisSize: MainAxisSize.min,
    //         children: [
    //           Text(
    //             "Today's Verse",
    //             style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
    //           ),
    //           SizedBox(height: 16),
    //           Text(
    //             "${todayVerse.book} ${todayVerse.chapter}:${todayVerse.verseNum}",
    //             style: TextStyle(fontWeight: FontWeight.bold),
    //           ),
    //           SizedBox(height: 8),
    //           Text(todayVerse.verse.toString()),
    //           SizedBox(height: 16),
    //           ElevatedButton(
    //             onPressed: () => Navigator.pop(context),
    //             child: Text("Close"),
    //           ),
    //         ],
    //       ),
    //     );
    //   },
    // );
  }

  Future<void> dailyVerseData() async {
    final prefs = await SharedPreferences.getInstance();
    final dbClient = await DBHelper().db;
    if (dbClient == null) return;

    final today = DateTime.now();
    final todayString = DateFormat('yyyy-MM-dd').format(today);

    // Check for cached list in SharedPreferences
    final storedListJson = prefs.getString('filtered_verse_list');
    if (storedListJson != null && storedListJson.isNotEmpty) {
      final List<dynamic> decodedList = jsonDecode(storedListJson);
      filteredList = decodedList
          .map((e) => DailyVerseList.fromJson(e as Map<String, dynamic>))
          .toList();

      debugPrint("Loaded dailyVerseList from SharedPreferences");
    } else {
      // Load from database
      List<String> selectedCategories =
          prefs.getStringList('selected_categories') ?? [];

      final tableName =
          selectedCategories.isEmpty ? "dailyVerses" : "dailyVersesnew";

      List<Map<String, dynamic>> dailyVerses =
          await dbClient.rawQuery("SELECT * FROM $tableName");

      filteredList.clear();

      for (var i in dailyVerses) {
        String verseDateString = i["Date"];
        DateTime verseDate;
        try {
          verseDate = DateTime.parse(verseDateString);
        } catch (e) {
          debugPrint("Invalid date format: ${i["Date"]}");
          continue;
        }

        final verseDateOnly = DateFormat('yyyy-MM-dd').format(verseDate);
        if (verseDateOnly.compareTo(todayString) > 0) {
          continue;
        }

        List<Map<String, dynamic>> bookData = await dbClient.rawQuery(
          "SELECT DISTINCT title FROM book WHERE book_num = ? LIMIT 1",
          [i["Book_Id"]],
        );

        String bookName =
            bookData.isNotEmpty ? bookData.first["title"] as String : "Unknown";

        filteredList.add(DailyVerseList(
          categoryName: "${i["Category_Name"]}",
          categoryId: int.parse("${i["Category_Id"]}"),
          book: bookName,
          bookId: int.parse("${i["Book_Id"]}"),
          chapter: int.parse("${i["Chapter"]}"),
          verse: "${i["Verse"]}",
          date: "${i["Date"]}",
          verseNum: int.parse("${i["Verse_Num"]}"),
        ));
      }

      // Sort
      filteredList.sort((a, b) {
        DateTime dateA = DateTime.parse(a.date.toString());
        DateTime dateB = DateTime.parse(b.date.toString());

        if (dateA.toString().substring(0, 10) == todayString) return -1;
        if (dateB.toString().substring(0, 10) == todayString) return 1;

        return dateB.compareTo(dateA);
      });

      // Store to SharedPreferences
      final encodedList =
          jsonEncode(filteredList.map((e) => e.toJson()).toList());
      await prefs.setString('filtered_verse_list', encodedList);
      debugPrint("Stored dailyVerseList to SharedPreferences");
    }

    if (mounted) {
      setState(() {
        dailyVerseList = filteredList;
      });
    }

    debugPrint("dailyVerseList final: $dailyVerseList");
  }

  // dailyVerseData() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   List<String> selectedCategories =
  //       prefs.getStringList('selected_categories') ??
  //           [

  //           ];

  //   final dbClient = await DBHelper().db;
  //   if (dbClient == null) return;

  //   final data = selectedCategories.isEmpty ? "dailyVerses" : "dailyVersesnew";

  //   debugPrint("list of $selectedCategories. $data");

  //   List<Map<String, dynamic>> dailyVerses =
  //       await dbClient.rawQuery("SELECT * FROM $data");

  //   final today = DateTime.now();
  //   final todayString = DateFormat('yyyy-MM-dd').format(today);

  //   for (var i in dailyVerses) {
  //     // Parse date from DB
  //     String verseDateString = i["Date"];
  //     DateTime verseDate;

  //     try {
  //       verseDate = DateTime.parse(verseDateString);
  //     } catch (e) {
  //       debugPrint("Invalid date format: ${i["Date"]}");
  //       continue;
  //     }

  //     // // Exclude future verses (after today)
  //     // if (verseDate.isAfter(today)) {
  //     //   continue;
  //     // }

  //     // Compare just the date (ignore time)
  //     final verseDateOnly = DateFormat('yyyy-MM-dd').format(verseDate);
  //     final todayOnly = DateFormat('yyyy-MM-dd').format(today);

  //     if (verseDateOnly.compareTo(todayOnly) > 0) {
  //       continue;
  //     }

  //     // Get book title using bookId
  //     List<Map<String, dynamic>> bookData = await dbClient.rawQuery(
  //       "SELECT DISTINCT title FROM book WHERE book_num = ? LIMIT 1",
  //       [i["Book_Id"]],
  //     );

  //     String bookName =
  //         bookData.isNotEmpty ? bookData.first["title"] as String : "Unknown";

  //     filteredList.add(DailyVerseList(
  //       categoryName: "${i["Category_Name"]}",
  //       categoryId: int.parse("${i["Category_Id"]}"),
  //       book: bookName,
  //       bookId: int.parse("${i["Book_Id"]}"),
  //       chapter: int.parse("${i["Chapter"]}"),
  //       verse: "${i["Verse"]}",
  //       date: "${i["Date"]}",
  //       verseNum: int.parse("${i["Verse_Num"]}"),
  //     ));
  //   }

  //   // Sort the list with today's verse first, then older verses in descending order
  //   filteredList.sort((a, b) {
  //     DateTime dateA = DateTime.parse(a.date.toString());
  //     DateTime dateB = DateTime.parse(b.date.toString());
  //     if (dateA.isAtSameMomentAs(dateB)) return 0;
  //     // Today's verse comes first
  //     if (dateA.toString().substring(0, 10) == todayString) return -1;
  //     if (dateB.toString().substring(0, 10) == todayString) return 1;
  //     // Then sort older verses by date (newest to oldest)
  //     return dateB.compareTo(dateA);
  //   });

  //   debugPrint("dailyVerseList - ${filteredList[0].book}");
  //   if (mounted) {
  //     setState(() {
  //       dailyVerseList = filteredList;
  //     });
  //   }
  //   debugPrint("dailyVerseList - $dailyVerseList");
  // }

  @override
  void dispose() {
    if (mounted) {
      if (audioPlayer.state == PlayerState.playing) {
        audioPlayer.dispose();
      }
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    String appStoreId = BibleInfo.apple_AppId;
    String microsoftStoreId = '';

    Future<void> openStoreListing() async {
      await inAppReview.openStoreListing(
        appStoreId: appStoreId,
        microsoftStoreId: microsoftStoreId,
      );
    }

    Future<void> checkAvailability() async {
      try {
        final isAvailable = await inAppReview.isAvailable();

        // This plugin cannot be tested on Android by installing your app
        // locally. See https://github.com/britannio/in_app_review#testing for
        // more information.
        availability = isAvailable && !Platform.isAndroid
            ? Availability.available
            : Availability.unavailable;
      } catch (_) {
        availability = Availability.unavailable;
      }
    }

    Future<void> showOfferDialog(DashBoardController controller) {
      return showDialog(
          context: context,
          builder: (context) {
            return Dialog(
              backgroundColor: CommanColor.whiteAndDark(context),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        GestureDetector(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Icon(
                              Icons.close,
                              size: 20,
                              color: CommanColor.whiteLightModePrimary(context),
                            ))
                      ],
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          vertical: 16, horizontal: 28),
                      decoration: const BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.fitWidth,
                              image: AssetImage('assets/promo.png'))),
                      child: IntrinsicWidth(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(
                              'assets/#0000ffff.png',
                              height: 24,
                            ),
                            const SizedBox(width: 10),
                            Text(
                              '${controller.lifeTimePlanValue}% OFF',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white),
                            )
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      'You are a valuable user!\nWe offer you a special offer on\npremium purchase for a life-time\n access. Enjoy!',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: CommanColor.whiteLightModePrimary(context)),
                    ),
                    const SizedBox(height: 10),
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                        Get.to(() => RemoveAddScreen(
                              sixMonthPlan: controller.sixMonthPlan ?? '',
                              oneYearPlan: controller.oneYearPlan ?? '',
                              lifeTimePlan: controller.lifeTimePlan ?? '',
                              onclick: () {},
                            ));
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            vertical: 6, horizontal: 20),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          color: CommanColor.whiteLightModePrimary(context),
                        ),
                        child: Text(
                          'Activate',
                          style: TextStyle(
                              fontWeight: FontWeight.w500,
                              color: CommanColor.darkModePrimaryWhite(context)),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            );
          });
    }

    // Run the availability check on first build
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await checkAvailability();
      // Future.delayed(Duration.zero, () {
      //   if (context.mounted) {
      //     DebugConsole.show(context);
      //   }
      // });
    });

    // Future<void> refreshData() async {
    //   // Your refresh logic here
    //   await Future.delayed(Duration(seconds: 2)); // Simulate network request
    //   setState(() {});
    // }

    double screenWidth = MediaQuery.of(context).size.width;
    debugPrint("sz current width - $screenWidth ");
    var bibleName = BibleInfo.bible_shortName;
    return UpgradeAlert(
      upgrader: Upgrader(
        countryCode: 'US',
        languageCode: 'en',
      ),
      child: GetX<DashBoardController>(
        init: DashBoardController(),
        initState: (state) async {
          WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
            SharedPreferences prefs = await SharedPreferences.getInstance();
            appLaunchCount = prefs.getInt('launchCount') ?? 0;
            // appLaunchCount++;

            debugPrint(" lanuchCount is - $appLaunchCount ");
            if (appLaunchCount == 2) {
              // setState(() {
              //   appLaunchCount = 3;
              // });
              debugPrint(" lanuchCount 2 is - $appLaunchCount ");
              final data = prefs.getString("review") ?? "1";

              if (data == '1') {
                Future.delayed(
                  Duration(minutes: 1),
                  () async {
                    await prefs.setInt('launchCount', 3);
                    await prefs.setString('review', '2');
                    appLaunchCount = prefs.getInt('launchCount') ?? 0;
                    debugPrint("lanuchCount 3 is - $appLaunchCount");
                    return await requestReview(result);
                  },
                );
              }
            }
          });

          Future.delayed(Duration.zero, () async {
            int saveRating =
                await SharPreferences.getInt(SharPreferences.saveRating) ?? 0;
            String lastViewRatingDateTime =
                await SharPreferences.getString(SharPreferences.lastViewTime) ??
                    "";
            String lastRatingDateTime = await SharPreferences.getString(
                    SharPreferences.ratingDateTime) ??
                "";
            if (lastRatingDateTime != "") {
              final startTime = DateFormat('dd-MM-yyyy HH:mm')
                  .parse(lastViewRatingDateTime.toString());
              final currentTime = DateTime.now();
              int diffDy = currentTime.difference(startTime).inDays;
              if (saveRating <= 4 && diffDy > 3) {
                //! i
                Future.delayed(
                  Duration(minutes: 2),
                  () {
                    // showDialog(
                    //     context: context,
                    //     builder: (BuildContext) {
                    //       return AlertDialog(
                    //           shape: RoundedRectangleBorder(
                    //               borderRadius: BorderRadius.circular(15)),
                    //           insetPadding:
                    //               const EdgeInsets.symmetric(horizontal: 15),
                    //           content: Column(
                    //             mainAxisSize: MainAxisSize.min,
                    //             children: [
                    //               Image.asset(
                    //                 "assets/feedbacklogo.png",
                    //                 height: 140,
                    //                 width: 140,
                    //                 color: Colors.brown,
                    //               ),
                    //               ValueListenableBuilder<int>(
                    //                 valueListenable: _rating,
                    //                 builder:
                    //                     (context, int value, Widget? child) {
                    //                   String feedbackText = '';
                    //                   String feedbackText1 = "";
                    //                   TextStyle style;
                    //                   TextStyle style1;
                    //                   Color? colour;
                    //                   if (value == 0) {
                    //                     feedbackText = 'Leave Your Experience,';
                    //                     feedbackText1 = 'Let it Shine Bright';
                    //                     style = const TextStyle(
                    //                         letterSpacing:
                    //                             BibleInfo.letterSpacing,
                    //                         fontSize:
                    //                             BibleInfo.fontSizeScale * 13,
                    //                         fontWeight: FontWeight.bold,
                    //                         color: Colors.brown);
                    //                     style1 = const TextStyle(
                    //                         letterSpacing:
                    //                             BibleInfo.letterSpacing,
                    //                         fontSize:
                    //                             BibleInfo.fontSizeScale * 13,
                    //                         fontWeight: FontWeight.bold,
                    //                         color: Colors.brown);
                    //                     colour = Colors.grey[500];
                    //                   } else if (value <= 3) {
                    //                     feedbackText = 'Please help us';
                    //                     feedbackText1 =
                    //                         'with your valuable feedback';
                    //                     style = const TextStyle(
                    //                         letterSpacing:
                    //                             BibleInfo.letterSpacing,
                    //                         fontSize:
                    //                             BibleInfo.fontSizeScale * 13,
                    //                         fontWeight: FontWeight.bold,
                    //                         color: Colors.brown);
                    //                     style1 = const TextStyle(
                    //                         letterSpacing:
                    //                             BibleInfo.letterSpacing,
                    //                         fontSize:
                    //                             BibleInfo.fontSizeScale * 13,
                    //                         fontWeight: FontWeight.bold,
                    //                         color: Colors.brown);
                    //                     colour = Colors.brown[500];
                    //                   } else {
                    //                     feedbackText = 'Great!';
                    //                     feedbackText1 =
                    //                         'Give your rating on store';
                    //                     style = const TextStyle(
                    //                         letterSpacing:
                    //                             BibleInfo.letterSpacing,
                    //                         fontSize:
                    //                             BibleInfo.fontSizeScale * 13,
                    //                         fontWeight: FontWeight.bold,
                    //                         color: Colors.brown);
                    //                     style1 = const TextStyle(
                    //                         letterSpacing:
                    //                             BibleInfo.letterSpacing,
                    //                         fontSize:
                    //                             BibleInfo.fontSizeScale * 20,
                    //                         fontWeight: FontWeight.bold,
                    //                         color: Colors.brown);
                    //                     colour = Colors.brown[500];
                    //                   }
                    //                   return Column(
                    //                     children: [
                    //                       Text(feedbackText, style: style1),
                    //                       const SizedBox(height: 16),
                    //                       Text(
                    //                         feedbackText1,
                    //                         style: style,
                    //                       ),
                    //                       const SizedBox(
                    //                         height: 10,
                    //                       ),
                    //                       Row(
                    //                         mainAxisAlignment:
                    //                             MainAxisAlignment.center,
                    //                         children: <Widget>[
                    //                           for (int i = 1; i <= 5; i++)
                    //                             GestureDetector(
                    //                               onTap: () {
                    //                                 _setRating(i);
                    //                                 state.controller!.rating
                    //                                     .value = i;
                    //                               },
                    //                               child: Icon(
                    //                                 Icons.star,
                    //                                 size: 40,
                    //                                 color: value >= i
                    //                                     ? Colors.brown
                    //                                     : Colors.grey,
                    //                               ),
                    //                             ),
                    //                         ],
                    //                       ),
                    //                       const SizedBox(height: 16),
                    //                       Row(
                    //                         mainAxisAlignment:
                    //                             MainAxisAlignment.center,
                    //                         children: [
                    //                           ElevatedButton(
                    //                             style: ElevatedButton.styleFrom(
                    //                                 backgroundColor:
                    //                                     Colors.grey[500]),
                    //                             child: const Text('Not Now',
                    //                                 style: TextStyle(
                    //                                     color: Colors.white)),
                    //                             onPressed: () {
                    //                               Navigator.of(context).pop();
                    //                               SharPreferences.setString(
                    //                                   SharPreferences
                    //                                       .lastViewTime,
                    //                                   "$currentTime");
                    //                             },
                    //                           ),
                    //                           const SizedBox(width: 50),
                    //                           ValueListenableBuilder<bool>(
                    //                             valueListenable:
                    //                                 _showFeedbackButton,
                    //                             builder: (context, bool value,
                    //                                 Widget? child) {
                    //                               if (!value) {
                    //                                 return SizedBox(
                    //                                   height: 40,
                    //                                   width: 120,
                    //                                   child: ElevatedButton(
                    //                                     style: ElevatedButton
                    //                                         .styleFrom(
                    //                                             backgroundColor:
                    //                                                 colour),
                    //                                     child: const Text(
                    //                                       'Feedback',
                    //                                       style: TextStyle(
                    //                                           color:
                    //                                               Colors.white),
                    //                                     ),
                    //                                     onPressed: () async {
                    //                                       Get.back();
                    //                                       SharPreferences.setInt(
                    //                                           SharPreferences
                    //                                               .saveRating,
                    //                                           state
                    //                                               .controller!
                    //                                               .rating
                    //                                               .value);
                    //                                       // SharPreferences.setBoolean(SharPreferences.dailyCheack, true);
                    //                                       SharPreferences.setString(
                    //                                           SharPreferences
                    //                                               .ratingDateTime,
                    //                                           "$currentTime");

                    //                                       const url =
                    //                                           'https://bibleoffice.com/m_feedback/API/feedback_form/index.php';
                    //                                       if (await canLaunch(
                    //                                           url)) {
                    //                                         await launch(url);
                    //                                       } else {
                    //                                         throw 'Could not launch $url';
                    //                                       }
                    //                                     },
                    //                                   ),
                    //                                 );
                    //                               } else {
                    //                                 return SizedBox(
                    //                                   height: 40,
                    //                                   width: 120,
                    //                                   child: ElevatedButton(
                    //                                     style: ElevatedButton
                    //                                         .styleFrom(
                    //                                             backgroundColor:
                    //                                                 colour),
                    //                                     child: const Text(
                    //                                       'Rate Us',
                    //                                       style: TextStyle(
                    //                                           color:
                    //                                               Colors.white),
                    //                                     ),
                    //                                     onPressed: () async {
                    //                                       Get.back();
                    //                                       SharPreferences.setInt(
                    //                                           SharPreferences
                    //                                               .saveRating,
                    //                                           state
                    //                                               .controller!
                    //                                               .rating
                    //                                               .value);
                    //                                       SharPreferences.setString(
                    //                                           SharPreferences
                    //                                               .ratingDateTime,
                    //                                           "$currentTime");
                    //                                       String appId;
                    //                                       appId = BibleInfo
                    //                                           .apple_AppId;
                    //                                       if (Platform
                    //                                           .isAndroid) {
                    //                                         final appPackageName =
                    //                                             (await PackageInfo
                    //                                                     .fromPlatform())
                    //                                                 .packageName;
                    //                                         try {
                    //                                           launchUrl(Uri.parse(
                    //                                               "market://details?id=$appPackageName"));
                    //                                         } on PlatformException {
                    //                                           launchUrl(Uri.parse(
                    //                                               "https://play.google.com/store/apps/details?id=$appPackageName"));
                    //                                         }
                    //                                       } else if (Platform
                    //                                           .isIOS) {
                    //                                         launchUrl(Uri.parse(
                    //                                             "https://itunes.apple.com/app/id$appId"));
                    //                                       }
                    //                                     },
                    //                                   ),
                    //                                 );
                    //                               }
                    //                             },
                    //                           ),
                    //                         ],
                    //                       ),
                    //                     ],
                    //                   );
                    //                 },
                    //               ),
                    //             ],
                    //           ));
                    //     });
                  },
                );
              }
            }
          });

          Future.delayed(const Duration(milliseconds: 1), () {
            if (!_scrollListenerAttached) {
              _scrollListenerAttached = true;
              state.controller?.autoScrollController.value.addListener(() {
                final direction = state.controller?.autoScrollController.value
                    .position.userScrollDirection;
                if (direction == ScrollDirection.reverse ||
                    direction == ScrollDirection.forward) {
                  state.controller?.scrollHideShowIcon.value = false;
                  Future.delayed(const Duration(milliseconds: 1), () {
                    state.controller?.scrollHideShowIcon.value = true;
                  });
                }
              });
            }
            // state.controller?.autoScrollController.value.addListener(() {
            //   if (state.controller?.autoScrollController.value.position
            //               .userScrollDirection ==
            //           ScrollDirection.reverse ||
            //       state.controller?.autoScrollController.value.position
            //               .userScrollDirection ==
            //           ScrollDirection.forward) {
            //     state.controller?.scrollHideShowIcon.value = false;
            //     Future.delayed(const Duration(milliseconds: 1), () {
            //       state.controller?.scrollHideShowIcon.value = true;
            //     });
            //   }
            // });
          });

          if (state.controller!.selectedChapter.value != "") {
            state.controller!.selectChapterChange.value =
                int.parse(state.controller!.selectedChapter.value);
          }
          state.controller!.selectedBookNumForRead.value =
              widget.selectedBookForRead.toString();
          state.controller!.selectedChapterForRead.value =
              widget.selectedChapterForRead.toString();
          state.controller!.selectedVerseForRead.value =
              widget.selectedVerseNumForRead.toString();
          state.controller!.selectedBookNameForRead.value =
              widget.selectedBookNameForRead.toString();
          SharPreferences.getString(SharPreferences.isRewardAdViewTime)
              .then((value) async {
            state.controller!.RewardAdExpireDate.value = value.toString();
            RewardAdExpireDate = value;
            debugPrint("RewardAdExpireDate is $RewardAdExpireDate");
            Future.delayed(
              Duration.zero,
              () {
                state.controller!.loadApi();
              },
            );

            if (value != null) {
              DateTime CurrentDateTime = DateTime.now();
              DateTime SaveTime = DateTime.parse(value.toString());
              var diff = CurrentDateTime.difference(SaveTime).inDays;

              if (!diff.isNegative) {
                state.controller!.initBanner(adUnitId: '');
                state.controller!.initInterstitialAd(adUnitId: '');
                state.controller!.loadRewardedAd(adUnitId: '');
                SharPreferences.setBoolean(SharPreferences.isAdsEnabled, true);
              } else {
                SharPreferences.setBoolean(SharPreferences.isAdsEnabled, false);
                state.controller!.adFree.value = true;
                state.controller!.isGetRewardAd.value = true;
              }
            } else {
              state.controller!.initBanner(adUnitId: '');
              state.controller!.initInterstitialAd(adUnitId: '');
              state.controller!.loadRewardedAd(adUnitId: '');
            }
          });

          state.controller!.selectedIndex.value = -1;
          Future.delayed(
            Duration.zero,
            () async {
              widget.From.toString() == "Read" ||
                      widget.From.toString() == "Daily"
                  ? state.controller!.readHighlight.value = true
                  : state.controller!.readHighlight.value = false;

              widget.From.toString() == "Read" ||
                      widget.From.toString() == "Daily"
                  ? state.controller!.getBookContentForRead()
                  : state.controller!.getSelectedChapterAndBook();

              // widget.From.toString() == "Daily"
              //     ? state.controller!.readHighlight.value = true
              //     : state.controller!.readHighlight.value = false;

              // widget.From.toString() == "Daily"
              //     ? state.controller!.getBookContentForRead()
              //     : state.controller!.getSelectedChapterAndBook();
              state.controller!.getFont();
            },
          );

          Future.delayed(
            const Duration(seconds: 6),
            () {
              state.controller?.readHighlight.value = false;
            },
          );

          Future.delayed(
            Duration.zero,
            () {
              state.controller?.autoScrollController.value =
                  AutoScrollController(
                      viewportBoundaryGetter: () => Rect.fromLTRB(
                          0, 0, 0, MediaQuery.of(context).padding.bottom),
                      axis: state.controller!.scrollDirection);
            },
          );

          Future.delayed(
            const Duration(seconds: 1),
            () {
              if (widget.From.toString() == "Read") {
                state.controller!.scrollToIndex(
                    int.parse(widget.selectedVerseNumForRead.toString()));
              }
              if (widget.From.toString() == "Daily") {
                state.controller?.selectedIndex.value = -1;
                state.controller!.scrollToIndex(
                    int.parse(widget.selectedVerseNumForRead.toString()));
              }
            },
          );
        },
        builder: (controller) {
          // var ctime;
          // if (widget.From.toString() == "Read") {
          //   debugPrint("dailyRead call ");
          //   controller.scrollToIndex(
          //     int.parse(
          //       widget.selectedVerseNumForRead.toString(),
          //     ),
          //   );
          //   // controller.scrollToIndex(
          //   //     int.parse(widget.selectedVerseNumForRead.toString()));
          // }
          return Scaffold(
            key: _scaffoldKey,
            appBar: controller.selectedChapter.value.isNotEmpty
                ? AppBar(
                    toolbarHeight: screenWidth > 450 ? 70 : 55,
                    iconTheme:
                        IconThemeData(color: CommanColor.whiteBlack(context)),
                    flexibleSpace: Container(
                      color: p.Provider.of<ThemeProvider>(context)
                                  .currentCustomTheme ==
                              AppCustomTheme.vintage
                          ? null
                          : Provider.of<ThemeProvider>(context).themeMode ==
                                  ThemeMode.dark
                              ? CommanColor.darkPrimaryColor
                              : p.Provider.of<ThemeProvider>(context)
                                          .currentCustomTheme ==
                                      AppCustomTheme.vintage
                                  ? CommanColor.darkPrimaryColor
                                  : p.Provider.of<ThemeProvider>(context)
                                      .backgroundColor,
                      decoration: p.Provider.of<ThemeProvider>(context)
                                  .currentCustomTheme ==
                              AppCustomTheme.vintage
                          ? BoxDecoration(
                              color: Provider.of<ThemeProvider>(context)
                                          .themeMode ==
                                      ThemeMode.dark
                                  ? CommanColor.black
                                  : p.Provider.of<ThemeProvider>(context)
                                              .currentCustomTheme ==
                                          AppCustomTheme.vintage
                                      ? CommanColor.darkPrimaryColor
                                      : p.Provider.of<ThemeProvider>(context)
                                          .backgroundColor,
                              image: DecorationImage(
                                image: AssetImage(Images.bgImage((context))),
                                fit: BoxFit.cover,
                              ),
                            )
                          : null,
                    ),
                    backgroundColor: p.Provider.of<ThemeProvider>(context)
                                .currentCustomTheme ==
                            AppCustomTheme.vintage
                        ? Colors.transparent
                        : null,
                    leadingWidth: 120,
                    leading: Row(
                      children: [
                        SizedBox(width: 12),
                        GestureDetector(
                            onTap: () {
                              _scaffoldKey.currentState?.openDrawer();
                            },
                            child: Icon(
                              Icons.menu,
                              size: screenWidth > 450 ? 40 : 24,
                            )),
                        SizedBox(width: 12),
                        controller.isAdsCompletlyDisabled.value
                            ? const SizedBox.shrink()
                            : controller.adFree.value
                                ? DateTime.tryParse(controller
                                            .RewardAdExpireDate.value) !=
                                        null
                                    ? GestureDetector(
                                        onTap: () {
                                          showModalBottomSheet<void>(
                                            context: context,
                                            backgroundColor: Colors.white,
                                            shape: const RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.vertical(
                                                top: Radius.circular(25),
                                              ),
                                            ),
                                            clipBehavior:
                                                Clip.antiAliasWithSaveLayer,
                                            builder: (BuildContext context) {
                                              final startTime = DateTime.parse(
                                                  '${controller.RewardAdExpireDate}');

                                              DateTime ExpiryDate = startTime;

                                              final currentTime =
                                                  DateTime.now();
                                              final diffDy =
                                                  ExpiryDate.difference(
                                                          currentTime)
                                                      .inDays;

                                              return Stack(
                                                children: [
                                                  Container(
                                                    decoration: BoxDecoration(
                                                        border: Border.all(
                                                            color: Colors
                                                                .white),
                                                        borderRadius:
                                                            const BorderRadius
                                                                .only(
                                                                topLeft: Radius
                                                                    .circular(
                                                                        20),
                                                                topRight: Radius
                                                                    .circular(
                                                                        20))),
                                                    height:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .height *
                                                            0.30,
                                                    // color: Colors.white,
                                                    child:
                                                        SingleChildScrollView(
                                                      physics:
                                                          const ScrollPhysics(),
                                                      child: Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: <Widget>[
                                                          Row(
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Image.asset(
                                                                  "assets/feedbacklogo.png",
                                                                  height: 120,
                                                                  width: 120,
                                                                  color: CommanColor
                                                                      .lightDarkPrimary(
                                                                          context)),
                                                            ],
                                                          ),
                                                          // SizedBox(height: 5,),
                                                          Text(
                                                            'Subscription Info',
                                                            style: TextStyle(
                                                                letterSpacing:
                                                                    BibleInfo
                                                                        .letterSpacing,
                                                                fontSize: BibleInfo
                                                                        .fontSizeScale *
                                                                    16,
                                                                color: CommanColor
                                                                    .lightDarkPrimary(
                                                                        context),
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500),
                                                          ),
                                                          const SizedBox(
                                                            height: 15,
                                                          ),
                                                          Text(
                                                              diffDy > 365
                                                                  ? 'Your subscription will never expire'
                                                                  : '$diffDy day(s) left for the renewal of the subscription.',
                                                              style: TextStyle(
                                                                  letterSpacing:
                                                                      BibleInfo
                                                                          .letterSpacing,
                                                                  fontSize:
                                                                      BibleInfo
                                                                              .fontSizeScale *
                                                                          15,
                                                                  color: CommanColor
                                                                      .lightDarkPrimary(
                                                                          context),
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400)),
                                                          const SizedBox(
                                                              height: 5),
                                                          Text(
                                                              diffDy > 365
                                                                  ? 'Your subscription period is lifetime'
                                                                  : 'Your subscription expires on ${DateFormat('dd-MM-yyyy').format(ExpiryDate)}',
                                                              style: TextStyle(
                                                                letterSpacing:
                                                                    BibleInfo
                                                                        .letterSpacing,
                                                                fontSize: BibleInfo
                                                                        .fontSizeScale *
                                                                    15,
                                                                color: CommanColor
                                                                    .lightDarkPrimary(
                                                                        context),
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                              ))
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    top: 10,
                                                    right: 15,
                                                    child: InkWell(
                                                      child: Icon(
                                                        Icons.close,
                                                        color: CommanColor
                                                            .lightDarkPrimary(
                                                                context),
                                                        size: 25,
                                                      ),
                                                      onTap: () {
                                                        Navigator.pop(context);
                                                      },
                                                    ),
                                                  )
                                                ],
                                              );
                                            },
                                          );
                                        },
                                        child: Image.asset(
                                          'assets/info.png',
                                          height: screenWidth > 450 ? 40 : 24,
                                        ))
                                    : Visibility(
                                        visible:
                                            controller.isSubscriptionEnabled ??
                                                true,
                                        child: GestureDetector(
                                          onTap: () {
                                            if (controller.connectionStatus
                                                        .first ==
                                                    ConnectivityResult.wifi ||
                                                controller.connectionStatus
                                                        .first ==
                                                    ConnectivityResult.mobile) {
                                              adsIcon = false;
                                              debugPrint(
                                                  "all plans - ${controller.sixMonthPlan} ${controller.oneYearPlan}  ${controller.lifeTimePlan}");
                                              Get.to(
                                                () => RemoveAddScreen(
                                                  sixMonthPlan:
                                                      controller.sixMonthPlan ??
                                                          '',
                                                  oneYearPlan:
                                                      controller.oneYearPlan ??
                                                          '',
                                                  lifeTimePlan:
                                                      controller.lifeTimePlan ??
                                                          '',
                                                  onclick: () {},
                                                ),
                                              );
                                            } else {
                                              Constants.showToast(
                                                  "Check your Internet Connection");
                                            }
                                          },
                                          child: Image.asset(
                                            'assets/no-ad.png',
                                            height: screenWidth > 450 ? 40 : 24,
                                            width: screenWidth > 450 ? 40 : 24,
                                            color:
                                                CommanColor.whiteBlack(context),
                                          ),
                                        ))
                                : Visibility(
                                    visible: controller.isSubscriptionEnabled ??
                                        false,
                                    child: GestureDetector(
                                      onTap: () {
                                        adsIcon = false;
                                        Get.to(() => RemoveAddScreen(
                                              sixMonthPlan:
                                                  controller.sixMonthPlan ?? '',
                                              oneYearPlan:
                                                  controller.oneYearPlan ?? '',
                                              lifeTimePlan:
                                                  controller.lifeTimePlan ?? '',
                                              onclick: () {},
                                            ));
                                      },
                                      child: Image.asset(
                                        'assets/no-ad.png',
                                        height: screenWidth > 450 ? 35 : 24,
                                        width: screenWidth > 450 ? 35 : 24,
                                        color: CommanColor.whiteBlack(context),
                                      ),
                                    )),
                      ],
                    ),
                    actions: [
                      InkWell(
                          onTap: () {
                            if (controller.adFree.value == false) {
                              controller.bannerAd?.dispose();
                              controller.bannerAd?.load();
                            }
                            Get.to(
                                () => SearchScreen(
                                      controller: controller,
                                    ),
                                transition: Transition.cupertinoDialog,
                                duration: const Duration(milliseconds: 300));
                          },
                          child: Image.asset(
                            "assets/search.png",
                            height: screenWidth > 450 ? 30 : 18,
                            width: screenWidth > 450 ? 30 : 18,
                            color: CommanColor.whiteBlack(context),
                          )),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10.0),
                        child: ChangeThemeButtonWidget(),
                      ),
                    ],
                    title: IntrinsicWidth(
                      child: InkWell(
                        onTap: () async {
                          if (controller.adFree.value == false) {
                            controller.bannerAd?.dispose();
                            controller.bannerAd?.load();
                          }
                          Get.to(() => const BookListScreen(),
                              transition: Transition.cupertinoDialog,
                              duration: const Duration(milliseconds: 300));
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Text("${controller.selectedBook}",
                                  style:
                                      CommanStyle.appBarStyle(context).copyWith(
                                    fontSize: screenWidth > 450
                                        ? BibleInfo.fontSizeScale * 26
                                        : BibleInfo.fontSizeScale * 18,
                                  )),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 3.0, left: 4),
                              child: Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color: CommanColor.whiteBlack(context),
                                size: screenWidth > 450 ? 39 : 24,
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    bottom: PreferredSize(
                      preferredSize: const Size.fromHeight(30.0),
                      child: Theme(
                        data: Theme.of(context).copyWith(
                            hintColor: CommanColor.whiteAndDark(context)),
                        child: Container(
                          height: screenWidth > 450 ? 45 : 30.0,
                          color:
                              Provider.of<ThemeProvider>(context).themeMode ==
                                      ThemeMode.dark
                                  ? p.Provider.of<ThemeProvider>(context)
                                              .currentCustomTheme ==
                                          AppCustomTheme.vintage
                                      ? CommanColor.darkPrimaryColor
                                      : CommanColor.darkPrimaryColor200
                                  : p.Provider.of<ThemeProvider>(context)
                                              .currentCustomTheme ==
                                          AppCustomTheme.vintage
                                      ? CommanColor.white
                                      : p.Provider.of<ThemeProvider>(context)
                                          .backgroundColor,
                          alignment: Alignment.center,
                          child: InkWell(
                            onTap: () {
                              if (controller.adFree.value == false) {
                                controller.bannerAd?.dispose();
                                controller.bannerAd?.load();
                              }
                              Get.to(
                                  () => ChapterListScreen(
                                        book_num:
                                            controller.selectedBookNum.value,
                                        chapterCount: controller
                                            .selectedBookChapterCount.value,
                                        selectedChapter:
                                            controller.selectedChapter.value,
                                      ),
                                  transition: Transition.cupertinoDialog,
                                  duration: const Duration(milliseconds: 300));
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                controller.selectedChapter.value == ""
                                    ? const SizedBox()
                                    : Text(
                                        "Chapter - ${int.parse(controller.selectedChapter.value)}",
                                        style: CommanStyle.bw14500(context)
                                            .copyWith(
                                                fontWeight: FontWeight.w400,
                                                fontSize: screenWidth > 450
                                                    ? BibleInfo.fontSizeScale *
                                                        20
                                                    : BibleInfo.fontSizeScale *
                                                        14)),
                                Padding(
                                  padding:
                                      const EdgeInsets.only(top: 2.0, left: 5),
                                  child: Icon(
                                    Icons.keyboard_arrow_down_rounded,
                                    color: CommanColor.whiteBlack(context),
                                    size: screenWidth > 450 ? 39 : 18,
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    centerTitle: true,
                    elevation: 2,
                  )
                : null,
            body: UpgradeAlert(
              upgrader: Upgrader(
                countryCode: 'US',
                languageCode: 'en',
              ),
              child: WillPopScope(
                onWillPop: () async {
                  Future.delayed(Duration.zero, () async {
                    int saveRating = await SharPreferences.getInt(
                            SharPreferences.saveRating) ??
                        0;
                    String lastViewRatingDateTime =
                        await SharPreferences.getString(
                                SharPreferences.lastViewTime) ??
                            "";
                    String lastRatingDateTime = await SharPreferences.getString(
                            SharPreferences.ratingDateTime) ??
                        "";
                    if (lastRatingDateTime != "") {
                      final startTime = DateFormat('dd-MM-yyyy HH:mm')
                          .parse(lastViewRatingDateTime.toString());
                      final currentTime = DateTime.now();
                      int diffDy = currentTime.difference(startTime).inDays;
                      if (saveRating <= 4 && diffDy > 3) {
                        Future.delayed(
                          Duration(minutes: 2),
                          () {
                            // showDialog(
                            //     context: context,
                            //     builder: (BuildContext) {
                            //       return AlertDialog(
                            //           insetPadding: const EdgeInsets.symmetric(
                            //               horizontal: 15),
                            //           shape: RoundedRectangleBorder(
                            //               borderRadius:
                            //                   BorderRadius.circular(15)),
                            //           content: Column(
                            //             mainAxisSize: MainAxisSize.min,
                            //             children: [
                            //               Image.asset(
                            //                 "assets/feedbacklogo.png",
                            //                 height: 140,
                            //                 width: 140,
                            //                 color: Colors.brown,
                            //               ),
                            //               ValueListenableBuilder<int>(
                            //                 valueListenable: _rating,
                            //                 builder: (context, int value,
                            //                     Widget? child) {
                            //                   String feedbackText = '';
                            //                   String feedbackText1 = "";
                            //                   TextStyle style;
                            //                   TextStyle style1;
                            //                   Color? colour;
                            //                   if (value == 0) {
                            //                     feedbackText =
                            //                         'Leave Your Experience,';
                            //                     feedbackText1 =
                            //                         'Let it Shine Bright';
                            //                     style = const TextStyle(
                            //                         letterSpacing:
                            //                             BibleInfo.letterSpacing,
                            //                         fontSize: BibleInfo
                            //                                 .fontSizeScale *
                            //                             13,
                            //                         fontWeight: FontWeight.bold,
                            //                         color: Colors.brown);
                            //                     style1 = const TextStyle(
                            //                         letterSpacing:
                            //                             BibleInfo.letterSpacing,
                            //                         fontSize: BibleInfo
                            //                                 .fontSizeScale *
                            //                             13,
                            //                         fontWeight: FontWeight.bold,
                            //                         color: Colors.brown);
                            //                     colour = Colors.grey[500];
                            //                   } else if (value <= 3) {
                            //                     feedbackText = 'Please help us';
                            //                     feedbackText1 =
                            //                         'with your valuable feedback';
                            //                     style = const TextStyle(
                            //                         letterSpacing:
                            //                             BibleInfo.letterSpacing,
                            //                         fontSize: BibleInfo
                            //                                 .fontSizeScale *
                            //                             13,
                            //                         fontWeight: FontWeight.bold,
                            //                         color: Colors.brown);
                            //                     style1 = const TextStyle(
                            //                         letterSpacing:
                            //                             BibleInfo.letterSpacing,
                            //                         fontSize: BibleInfo
                            //                                 .fontSizeScale *
                            //                             13,
                            //                         fontWeight: FontWeight.bold,
                            //                         color: Colors.brown);
                            //                     colour = Colors.brown[500];
                            //                   } else {
                            //                     feedbackText = 'Great!';
                            //                     feedbackText1 =
                            //                         'Give your rating on store';
                            //                     style = const TextStyle(
                            //                         letterSpacing:
                            //                             BibleInfo.letterSpacing,
                            //                         fontSize: BibleInfo
                            //                                 .fontSizeScale *
                            //                             13,
                            //                         fontWeight: FontWeight.bold,
                            //                         color: Colors.brown);
                            //                     style1 = const TextStyle(
                            //                         letterSpacing:
                            //                             BibleInfo.letterSpacing,
                            //                         fontSize: BibleInfo
                            //                                 .fontSizeScale *
                            //                             20,
                            //                         fontWeight: FontWeight.bold,
                            //                         color: Colors.brown);
                            //                     colour = Colors.brown[500];
                            //                   }
                            //                   return Column(
                            //                     children: [
                            //                       Text(feedbackText,
                            //                           style: style1),
                            //                       const SizedBox(height: 16),
                            //                       Text(
                            //                         feedbackText1,
                            //                         style: style,
                            //                       ),
                            //                       const SizedBox(
                            //                         height: 10,
                            //                       ),
                            //                       Row(
                            //                         mainAxisAlignment:
                            //                             MainAxisAlignment
                            //                                 .center,
                            //                         children: <Widget>[
                            //                           for (int i = 1;
                            //                               i <= 5;
                            //                               i++)
                            //                             GestureDetector(
                            //                               onTap: () {
                            //                                 _setRating(i);
                            //                                 controller.rating
                            //                                     .value = i;
                            //                               },
                            //                               child: Icon(
                            //                                 Icons.star,
                            //                                 size: 40,
                            //                                 color: value >= i
                            //                                     ? Colors.brown
                            //                                     : Colors.grey,
                            //                               ),
                            //                             ),
                            //                         ],
                            //                       ),
                            //                       const SizedBox(height: 16),
                            //                       Row(
                            //                         mainAxisAlignment:
                            //                             MainAxisAlignment
                            //                                 .center,
                            //                         children: [
                            //                           ElevatedButton(
                            //                             style: ElevatedButton
                            //                                 .styleFrom(
                            //                                     backgroundColor:
                            //                                         Colors.grey[
                            //                                             500]),
                            //                             child: const Text(
                            //                                 'Not Now',
                            //                                 style: TextStyle(
                            //                                     color: Colors
                            //                                         .white)),
                            //                             onPressed: () {
                            //                               Navigator.of(context)
                            //                                   .pop();
                            //                               SharPreferences.setString(
                            //                                   SharPreferences
                            //                                       .lastViewTime,
                            //                                   "$currentTime");
                            //                             },
                            //                           ),
                            //                           const SizedBox(width: 50),
                            //                           ValueListenableBuilder<
                            //                               bool>(
                            //                             valueListenable:
                            //                                 _showFeedbackButton,
                            //                             builder: (context,
                            //                                 bool value,
                            //                                 Widget? child) {
                            //                               if (!value) {
                            //                                 return SizedBox(
                            //                                   height: 40,
                            //                                   width: 120,
                            //                                   child:
                            //                                       ElevatedButton(
                            //                                     style: ElevatedButton
                            //                                         .styleFrom(
                            //                                             backgroundColor:
                            //                                                 colour),
                            //                                     child: const Text(
                            //                                         'Feedback',
                            //                                         style: TextStyle(
                            //                                             color: Colors
                            //                                                 .white)),
                            //                                     onPressed:
                            //                                         () async {
                            //                                       Get.back();
                            //                                       SharPreferences.setInt(
                            //                                           SharPreferences
                            //                                               .saveRating,
                            //                                           controller
                            //                                               .rating
                            //                                               .value);
                            //                                       // SharPreferences.setBoolean(SharPreferences.dailyCheack, true);
                            //                                       SharPreferences.setString(
                            //                                           SharPreferences
                            //                                               .ratingDateTime,
                            //                                           "$currentTime");

                            //                                       const url =
                            //                                           'https://bibleoffice.com/m_feedback/API/feedback_form/index.php';
                            //                                       if (await canLaunch(
                            //                                           url)) {
                            //                                         await launch(
                            //                                             url);
                            //                                       } else {
                            //                                         throw 'Could not launch $url';
                            //                                       }
                            //                                     },
                            //                                   ),
                            //                                 );
                            //                               } else {
                            //                                 return SizedBox(
                            //                                   height: 40,
                            //                                   width: 120,
                            //                                   child:
                            //                                       ElevatedButton(
                            //                                     style: ElevatedButton
                            //                                         .styleFrom(
                            //                                             backgroundColor:
                            //                                                 colour),
                            //                                     child: const Text(
                            //                                         'Rate Us',
                            //                                         style: TextStyle(
                            //                                             color: Colors
                            //                                                 .white)),
                            //                                     onPressed:
                            //                                         () async {
                            //                                       Get.back();
                            //                                       SharPreferences.setInt(
                            //                                           SharPreferences
                            //                                               .saveRating,
                            //                                           controller
                            //                                               .rating
                            //                                               .value);
                            //                                       SharPreferences.setString(
                            //                                           SharPreferences
                            //                                               .ratingDateTime,
                            //                                           "$currentTime");
                            //                                       String appId;
                            //                                       appId = BibleInfo
                            //                                           .apple_AppId;
                            //                                       if (Platform
                            //                                           .isAndroid) {
                            //                                         final appPackageName =
                            //                                             (await PackageInfo.fromPlatform())
                            //                                                 .packageName;
                            //                                         try {
                            //                                           launchUrl(
                            //                                               Uri.parse(
                            //                                                   "market://details?id=$appPackageName"));
                            //                                         } on PlatformException {
                            //                                           launchUrl(
                            //                                               Uri.parse(
                            //                                                   "https://play.google.com/store/apps/details?id=$appPackageName"));
                            //                                         }
                            //                                       } else if (Platform
                            //                                           .isIOS) {
                            //                                         launchUrl(Uri
                            //                                             .parse(
                            //                                                 "https://itunes.apple.com/app/id$appId"));
                            //                                       }
                            //                                     },
                            //                                   ),
                            //                                 );
                            //                               }
                            //                             },
                            //                           ),
                            //                         ],
                            //                       ),
                            //                     ],
                            //                   );
                            //                 },
                            //               ),
                            //             ],
                            //           ));
                            //     });
                          },
                        );
                      }
                    }
                  });
                  return Future.value(true);
                },
                child: GestureDetector(
                  onHorizontalDragEnd: (dragDetail) async {
                    // Show ad every 5 swipes
                    if (dragDetail.velocity.pixelsPerSecond.dx < 1) {
                      //! AD interstitialAd

                      swipeCount++;

                      if (swipeCount >= _swipeThreshold) {
                        swipeCount = 0; // Reset counter
                        debugPrint(
                            "now Chapter and count is $swipeCount $_swipeThreshold");
                        await Future.delayed(Duration(seconds: 1));
                        if (adService.interstitialAd != null) {
                          EasyLoading.showInfo('Please wait...');
                          await SharPreferences.setString('OpenAd', '1');
                          adService.showInterstitialAd();
                        }
                      }
                      debugPrint(
                          "Next Chapter and count is $swipeCount $_swipeThreshold");
                      if (controller.selectChapterChange.value + 1 <=
                          int.parse(
                              controller.selectedBookChapterCount.value)) {
                        controller.selectChapterChange.value++;
                        controller.selectedChapter.value =
                            controller.selectChapterChange.value.toString();
                        SharPreferences.setString(
                            SharPreferences.selectedChapter,
                            controller.selectedChapter.value);

                        controller.getSelectedChapterAndBook();
                        controller.getFont();
                      } else {
                        Constants.showToast(
                            "Selected Book is completed. Please change the book.");
                      }
                    } else if (controller.selectChapterChange.value > 1) {
                      swipeCount++;

                      if (swipeCount >= _swipeThreshold) {
                        swipeCount = 0; // Reset counter
                        debugPrint(
                            "now Chapter and count is $swipeCount $_swipeThreshold");
                        await Future.delayed(Duration(seconds: 1));
                        if (adService.interstitialAd != null) {
                          EasyLoading.showInfo('Please wait...');
                          await SharPreferences.setString('OpenAd', '1');
                          adService.showInterstitialAd();
                        }
                      }
                      debugPrint(
                          "Next Chapter and count is $swipeCount $_swipeThreshold");
                      debugPrint("Previous Chapter");
                      controller.selectChapterChange.value--;
                      controller.selectedChapter.value =
                          controller.selectChapterChange.value.toString();
                      SharPreferences.setString(SharPreferences.selectedChapter,
                          controller.selectedChapter.value);
                      controller.getSelectedChapterAndBook();
                      controller.getFont();
                    }
                  },
                  child: Container(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width,
                    decoration: p.Provider.of<ThemeProvider>(context)
                                .currentCustomTheme ==
                            AppCustomTheme.vintage
                        ? BoxDecoration(
                            // color: Color(0x80605749),
                            image: DecorationImage(
                                image: AssetImage(Images.bgImage(context)),
                                fit: BoxFit.fill))
                        : null,
                    child: controller.isFetchContent.value
                        ? const Center(
                            child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Loader(),
                            ],
                          ))
                        : controller.selectedBookContent.isEmpty
                            ? Center(
                                child: Text(
                                  "Content is Empty",
                                  style: CommanStyle.bw16500(context),
                                ),
                              )
                            : ListView.builder(
                                scrollDirection: controller.scrollDirection,
                                controller:
                                    controller.autoScrollController.value,
                                itemCount:
                                    controller.selectedBookContent.length,
                                physics: const ScrollPhysics(),
                                shrinkWrap: true,
                                padding: const EdgeInsets.only(
                                    left: 15, right: 15, bottom: 20),
                                itemBuilder: (context, index) {
                                  var data =
                                      controller.selectedBookContent[index];
                                  return AutoScrollTag(
                                    key: ValueKey(index),
                                    controller:
                                        controller.autoScrollController.value,
                                    index: index,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 10.0),
                                          child: GestureDetector(
                                            onTap: () async {
                                              setState(() {
                                                controller.selectedIndex.value =
                                                    -1;

                                                controller.selectedIndex.value =
                                                    index;

                                                controller.selectedVerseView
                                                    .value = index;
                                                controller.printText.value =
                                                    '${parse(data.content).body?.text ?? data.content}';
                                              });

                                              await homeContentEditBottomSheet(
                                                      context,
                                                      loadInterstitial:
                                                          loadInterstitialAd,
                                                      callback2: () {
                                                //_handledownloadClick();
                                              }, callback: (v) {
                                                setState(() {
                                                  // selectedcolor = v;
                                                  controller.selectedIndex
                                                      .value = index;
                                                });
                                                debugPrint(" step 1 ");
                                              },
                                                      verNum: "${index + 1}",
                                                      verseBookdata: data,
                                                      selectedColor: data
                                                                  .isHighlighted ==
                                                              "no"
                                                          ? 0
                                                          : int.parse(
                                                              selectedcolor ??
                                                                  '0x00000000'),
                                                      controller: controller)
                                                  .then(
                                                (value) {
                                                  setState(() {
                                                    controller.selectedIndex
                                                        .value = -1;
                                                  });
                                                  debugPrint(" step 2 ");
                                                  // controller.selectedIndex.value =
                                                  //     -1;
                                                },
                                              );
                                            },
                                            child: VerseItemWidget(
                                              index: index,
                                              currentindex: controller
                                                  .selectedIndex.value,
                                              controller: controller,
                                              data: data,
                                              selectedVerseForRead: widget
                                                  .selectedVerseForRead
                                                  .toString(),
                                              selectedColor:
                                                  selectedcolor.toString(),
                                            ),
                                          ),
                                        ),
                                        index ==
                                                controller.selectedBookContent
                                                        .length -
                                                    1
                                            ? Obx(() => Column(
                                                  children: [
                                                    Container(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              top: 15),
                                                      width:
                                                          MediaQuery.of(context)
                                                              .size
                                                              .width,
                                                      color: Colors.transparent,
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: [
                                                          GestureDetector(
                                                            onTap: () async {
                                                              await SharPreferences
                                                                  .setString(
                                                                      'OpenAd',
                                                                      '1');
                                                              await DBHelper()
                                                                  .db
                                                                  .then(
                                                                      (value) {
                                                                value!
                                                                    .rawQuery(
                                                                        "SELECT * From book WHERE book_num = ${int.parse(controller.selectedBookNum.value)}")
                                                                    .then(
                                                                        (value) {
                                                                  controller
                                                                      .bookReadPer
                                                                      .value = value[
                                                                              0]
                                                                          [
                                                                          "read_per"]
                                                                      .toString();
                                                                  if (controller
                                                                          .selectedBookContent
                                                                          .value[
                                                                              1]
                                                                          .isRead ==
                                                                      "no") {
                                                                    if (controller
                                                                            .bookReadPer
                                                                            .value ==
                                                                        0) {
                                                                      double readPer = (100 *
                                                                              1) /
                                                                          double.parse(controller
                                                                              .selectedBookChapterCount
                                                                              .value
                                                                              .toString());
                                                                      DBHelper()
                                                                          .updateBookData(
                                                                              int.parse(controller.selectedBookId.value.toString()),
                                                                              "read_per",
                                                                              readPer.toStringAsFixed(1).toString())
                                                                          .then((value) {});
                                                                    } else {
                                                                      double readPer = (100 *
                                                                              1) /
                                                                          double.parse(controller
                                                                              .selectedBookChapterCount
                                                                              .value
                                                                              .toString());
                                                                      double
                                                                          FinalRead =
                                                                          double.parse(controller.bookReadPer.value.toString()) +
                                                                              readPer;
                                                                      DBHelper()
                                                                          .updateBookData(
                                                                              int.parse(controller.selectedBookId.value.toString()),
                                                                              "read_per",
                                                                              FinalRead.toStringAsFixed(1).toString())
                                                                          .then((value) {});
                                                                    }
                                                                    controller
                                                                        .isReadLoad
                                                                        .value = true;
                                                                    for (var i =
                                                                            0;
                                                                        i < controller.selectedBookContent.value.length;
                                                                        i++) {
                                                                      DBHelper()
                                                                          .updateVersesData(
                                                                              int.parse(controller.selectedBookContent.value[i].id.toString()),
                                                                              "is_read",
                                                                              "yes")
                                                                          .then((value) {});
                                                                      var data = VerseBookContentModel(
                                                                          id: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .id,
                                                                          bookNum: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .bookNum,
                                                                          chapterNum: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .chapterNum,
                                                                          verseNum: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .verseNum,
                                                                          content: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .content,
                                                                          isBookmarked: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .isBookmarked,
                                                                          isHighlighted: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .isHighlighted,
                                                                          isNoted: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .isNoted,
                                                                          isUnderlined: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .isUnderlined,
                                                                          isRead:
                                                                              "yes");
                                                                      controller
                                                                              .selectedBookContent[i] =
                                                                          data;
                                                                    }

                                                                    Future
                                                                        .delayed(
                                                                      const Duration(
                                                                          milliseconds:
                                                                              200),
                                                                      () {
                                                                        controller
                                                                            .isReadLoad
                                                                            .value = false;
                                                                        if (controller.isInterstitialAdLoad.value &&
                                                                            controller.adFree.value ==
                                                                                false) {
                                                                          print(
                                                                              'Load Interstitial Ad');
                                                                          loadInterstitialAd(
                                                                              controller);
                                                                          Get.to(() =>
                                                                              MarkAsReadScreen(
                                                                                ReadedChapter: controller.selectedChapter.value,
                                                                                RededBookName: controller.selectedBook.value,
                                                                                SelectedBookChapterCount: controller.selectedBookChapterCount.value,
                                                                              ));
                                                                        } else {
                                                                          print(
                                                                              'Not Load Interstitial Ad');
                                                                          Get.to(() =>
                                                                              MarkAsReadScreen(
                                                                                ReadedChapter: controller.selectedChapter.value,
                                                                                RededBookName: controller.selectedBook.value,
                                                                                SelectedBookChapterCount: controller.selectedBookChapterCount.value,
                                                                              ));
                                                                        }
                                                                      },
                                                                    );
                                                                  } else {
                                                                    controller
                                                                        .isReadLoad
                                                                        .value = true;
                                                                    if (controller
                                                                            .bookReadPer
                                                                            .value ==
                                                                        0) {
                                                                    } else {
                                                                      double readPer = (100 *
                                                                              1) /
                                                                          double.parse(controller
                                                                              .selectedBookChapterCount
                                                                              .value
                                                                              .toString());
                                                                      double
                                                                          FinalRead =
                                                                          double.parse(controller.bookReadPer.value.toString()) -
                                                                              readPer;
                                                                      DBHelper()
                                                                          .updateBookData(
                                                                              int.parse(controller.selectedBookId.value.toString()),
                                                                              "read_per",
                                                                              FinalRead.toStringAsFixed(1).toString())
                                                                          .then((value) {});
                                                                    }
                                                                    for (var i =
                                                                            0;
                                                                        i < controller.selectedBookContent.value.length;
                                                                        i++) {
                                                                      DBHelper()
                                                                          .updateVersesData(
                                                                              int.parse(controller.selectedBookContent.value[i].id.toString()),
                                                                              "is_read",
                                                                              "no")
                                                                          .then((value) {});
                                                                      var data = VerseBookContentModel(
                                                                          id: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .id,
                                                                          bookNum: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .bookNum,
                                                                          chapterNum: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .chapterNum,
                                                                          verseNum: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .verseNum,
                                                                          content: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .content,
                                                                          isBookmarked: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .isBookmarked,
                                                                          isHighlighted: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .isHighlighted,
                                                                          isNoted: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .isNoted,
                                                                          isUnderlined: controller
                                                                              .selectedBookContent[
                                                                                  i]
                                                                              .isUnderlined,
                                                                          isRead:
                                                                              "no");
                                                                      controller
                                                                              .selectedBookContent[i] =
                                                                          data;
                                                                    }
                                                                    Future.delayed(
                                                                        const Duration(
                                                                            milliseconds:
                                                                                200),
                                                                        () {
                                                                      controller
                                                                          .isReadLoad
                                                                          .value = false;
                                                                    });
                                                                  }
                                                                });
                                                              });
                                                            },
                                                            child: Container(
                                                              width: 200,
                                                              height: 40,
                                                              decoration:
                                                                  BoxDecoration(
                                                                color: controller
                                                                            .selectedBookContent
                                                                            .value[
                                                                                1]
                                                                            .isRead ==
                                                                        "no"
                                                                    ? Colors
                                                                        .black38
                                                                    : CommanColor
                                                                        .whiteLightModePrimary(
                                                                            context),
                                                                borderRadius:
                                                                    const BorderRadius
                                                                        .all(
                                                                        Radius.circular(
                                                                            5)),
                                                                boxShadow: [
                                                                  const BoxShadow(
                                                                      color: Colors
                                                                          .black26,
                                                                      blurRadius:
                                                                          2)
                                                                ],
                                                              ),
                                                              child: Center(
                                                                  child: controller
                                                                              .isReadLoad
                                                                              .value ==
                                                                          false
                                                                      ? Text(
                                                                          controller.selectedBookContent.value[1].isRead == "no"
                                                                              ? 'Mark as Read'
                                                                              : "Marked as Read",
                                                                          style: TextStyle(
                                                                              letterSpacing: BibleInfo.letterSpacing,
                                                                              fontSize: screenWidth > 450 ? BibleInfo.fontSizeScale * 20 : BibleInfo.fontSizeScale * 14,
                                                                              fontWeight: FontWeight.w500,
                                                                              color: controller.selectedBookContent.value[1].isRead == "no" ? Colors.white : CommanColor.darkModePrimaryWhite(context)),
                                                                        )
                                                                      : const SizedBox(
                                                                          height:
                                                                              22,
                                                                          width:
                                                                              22,
                                                                          child:
                                                                              CircularProgressIndicator(
                                                                            color:
                                                                                Colors.white,
                                                                            strokeWidth:
                                                                                2.2,
                                                                          ))),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const SizedBox(height: 16),
                                                    const Divider(thickness: 2),

                                                    ///NEW AD BANNER
                                                    if (controller
                                                                .popupBannerAdHome !=
                                                            null &&
                                                        controller
                                                            .isPopupBannerAdHomeLoaded
                                                            .value &&
                                                        controller
                                                                .adFree.value ==
                                                            false)
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(
                                                                top: 20,
                                                                bottom: 40),
                                                        child: SizedBox(
                                                          height: controller
                                                              .popupBannerAdHome
                                                              ?.size
                                                              .height
                                                              .toDouble(),
                                                          width: controller
                                                              .popupBannerAdHome
                                                              ?.size
                                                              .width
                                                              .toDouble(),
                                                          child: AdWidget(
                                                              ad: controller
                                                                  .popupBannerAdHome!),
                                                        ),
                                                      ),
                                                  ],
                                                ))
                                            : const SizedBox(),
                                        p.Provider.of<ThemeProvider>(context)
                                                    .currentCustomTheme ==
                                                AppCustomTheme.lightbrown
                                            ? controller.selectedBookContent
                                                        .length !=
                                                    index + 1
                                                ? Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 12),
                                                    child: Row(
                                                      children: List.generate(
                                                          150 ~/ 3,
                                                          (index) => Expanded(
                                                                child:
                                                                    Container(
                                                                  color: index %
                                                                              2 ==
                                                                          0
                                                                      ? Colors
                                                                          .transparent
                                                                      : Colors
                                                                          .grey,
                                                                  height: 2,
                                                                ),
                                                              )),
                                                    ),
                                                  )
                                                : SizedBox()
                                            : SizedBox(),
                                      ],
                                    ),
                                  );
                                },
                              ),
                  ),
                ),
              ),
            ),
            floatingActionButton: controller.isFetchContent.value
                ? const SizedBox()
                : Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                          onTap: () {
                            _scaffoldKey.currentState?.openDrawer();
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 32),
                            child: Container(
                                height: screenWidth > 450 ? 50 : 35,
                                width: screenWidth > 450 ? 50 : 35,
                                decoration: BoxDecoration(
                                  color: CommanColor.whiteLightModePrimary(
                                      context),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(Icons.menu,
                                    size: screenWidth > 450 ? 44 : 24,
                                    color: CommanColor.darkModePrimaryWhite(
                                        context))),
                          )),
                      floatingButtun(
                        chapterNum: controller.selectedChapter.value,
                        bookName: controller.selectedBook.value,
                        contentList: controller.selectedVersesContent,
                        chapterCount: controller.selectedBookChapterCount.value,
                        audioData: controller.audioData.value,
                        bookNum: controller.selectedBookNum.value,
                        internetConnection: controller.connectionStatus,
                        textToSpeechLoad: controller.loadTextToSpeech.value,
                        audioPlayer: audioPlayer,
                      ),
                    ],
                  ),
            drawer: controller.isFetchContent.value
                ? const SizedBox()
                : Drawer(
                    backgroundColor: p.Provider.of<ThemeProvider>(context)
                                .currentCustomTheme ==
                            AppCustomTheme.vintage
                        ? CommanColor.white
                        : p.Provider.of<ThemeProvider>(context).backgroundColor,
                    width: MediaQuery.of(context).size.width * 0.6,
                    child: ListView(
                      // Important: Remove any padding from the ListView.
                      padding: EdgeInsets.zero,
                      children: [
                        SizedBox(
                          height: 120,
                          child: DrawerHeader(
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(
                              color: CommanColor.lightDarkPrimary(context),
                            ),
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    bibleName,
                                    style: CommanStyle.white16600,
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                        ListTile(
                          dense: true,
                          onTap: () {
                            Get.back();
                            if (controller.adFree.value == false) {
                              controller.bannerAd?.dispose();
                              controller.bannerAd?.load();
                            }
                            Get.to(
                                () => isLoggedIn
                                    ? const ProfileScreen()
                                    : LoginScreen(hasSkip: false),
                                transition: Transition.cupertinoDialog,
                                duration: const Duration(milliseconds: 300));
                          },
                          visualDensity:
                              const VisualDensity(horizontal: 0, vertical: 0),
                          leading: const Icon(
                            Icons.person,
                            color: Color(0XFF805531),
                          ),
                          title: Text(
                            'My Account',
                            style: CommanStyle.bothPrimary16600(context),
                          ),
                        ),
                        // ListTile(
                        //   dense: true,
                        //   onTap: () {
                        //     Get.back();
                        //   },
                        //   visualDensity:
                        //       const VisualDensity(horizontal: 0, vertical: 0),
                        //   leading: Image.asset(
                        //     Images.home(context),
                        //     height: 24,
                        //     width: 24,
                        //   ),
                        //   title: Text(
                        //     'Home',
                        //     style: CommanStyle.bothPrimary16600(context),
                        //   ),
                        // ),
                        ListTile(
                          onTap: () {
                            Get.back();
                            if (controller.adFree.value == false) {
                              controller.bannerAd?.dispose();
                              controller.bannerAd?.load();
                            }
                            Get.to(() => const DailyVerse(),
                                transition: Transition.cupertinoDialog,
                                duration: const Duration(milliseconds: 300));
                          },
                          dense: true,
                          visualDensity:
                              const VisualDensity(horizontal: 0, vertical: 0),
                          leading: Image.asset(
                            Images.daily(context),
                            height: 24,
                            width: 24,
                          ),
                          title: Text(
                            'Daily Verses',
                            style: CommanStyle.bothPrimary16600(context),
                          ),
                        ),
                        ListTile(
                          dense: true,
                          onTap: () {
                            Get.back();
                            if (controller.adFree.value == false) {
                              controller.bannerAd?.dispose();
                              controller.bannerAd?.load();
                            }
                            Get.to(
                                () => SearchScreen(
                                      controller: controller,
                                    ),
                                transition: Transition.cupertinoDialog,
                                duration: const Duration(milliseconds: 300));
                          },
                          visualDensity:
                              const VisualDensity(horizontal: 0, vertical: 0),
                          leading: Image.asset(
                            Images.search(context),
                            height: 24,
                            width: 24,
                          ),
                          title: Text(
                            'Search',
                            style: CommanStyle.bothPrimary16600(context),
                          ),
                        ),
                        ListTile(
                          dense: true,
                          onTap: () {
                            Get.back();
                            if (controller.adFree.value == false) {
                              controller.bannerAd?.dispose();
                              controller.bannerAd?.load();
                            }
                            Get.to(() => const LibraryScreen(),
                                    transition: Transition.cupertinoDialog,
                                    duration:
                                        const Duration(milliseconds: 300))!
                                .then((value) {
                              controller.getSelectedChapterAndBook();
                            });
                          },
                          visualDensity:
                              const VisualDensity(horizontal: 0, vertical: 0),
                          leading: Image.asset(
                            Images.myLibrary(context),
                            height: 24,
                            width: 24,
                          ),
                          title: Text(
                            'My Library',
                            style: CommanStyle.bothPrimary16600(context),
                          ),
                        ),
                        ListTile(
                          dense: true,
                          onTap: () {
                            Get.back();
                            if (controller.adFree.value == false) {
                              controller.bannerAd?.dispose();
                              controller.bannerAd?.load();
                            }
                            Get.to(() => const WallpaperScreen(),
                                transition: Transition.cupertinoDialog,
                                duration: const Duration(milliseconds: 300));
                          },
                          visualDensity:
                              const VisualDensity(horizontal: 0, vertical: 0),
                          leading: Image.asset(
                            Images.wallpaper,
                            height: 24,
                            width: 24,
                          ),
                          title: Text(
                            'Wallpapers',
                            style: CommanStyle.bothPrimary16600(context),
                          ),
                        ),
                        ListTile(
                          dense: true,
                          onTap: () {
                            Get.back();
                            if (controller.adFree.value == false) {
                              controller.bannerAd?.dispose();
                              controller.bannerAd?.load();
                            }
                            Get.to(() => const QuoteScreen(),
                                transition: Transition.cupertinoDialog,
                                duration: const Duration(milliseconds: 300));
                          },
                          visualDensity:
                              const VisualDensity(horizontal: 0, vertical: 0),
                          leading: Image.asset(
                            Images.quote,
                            height: 24,
                            width: 24,
                          ),
                          title: Text(
                            'Quotes',
                            style: CommanStyle.bothPrimary16600(context),
                          ),
                        ),
                        ListTile(
                          dense: true,
                          onTap: () {
                            Get.back();
                            if (controller.adFree.value == false) {
                              controller.bannerAd?.dispose();
                              controller.bannerAd?.load();
                            }
                            Get.to(() => const CalendarScreen(),
                                transition: Transition.cupertinoDialog,
                                duration: const Duration(milliseconds: 300));
                          },
                          visualDensity:
                              const VisualDensity(horizontal: 0, vertical: 0),
                          leading: const Icon(
                            Icons.calendar_month,
                            color: Color(0XFF805531),
                          ),
                          title: Text(
                            'Calendar',
                            style: CommanStyle.bothPrimary16600(context),
                          ),
                        ),
                        // ListTile(
                        //   dense: true,
                        //   onTap: () {
                        //     Get.back();
                        //     if (controller.adFree.value == false) {
                        //       controller.bannerAd?.dispose();
                        //       controller.bannerAd?.load();
                        //     }
                        //     if (isLoggedIn) {
                        //       showImportExportInfo(context, () async {
                        //         final permission =
                        //             await ExportDb.requestStoragePermission();
                        //         if (permission) {
                        //           updateLoading(true,
                        //               mess: 'Exporting the data. Please wait');
                        //           await ExportDb.getAllDataToExport(context);
                        //           updateLoading(false);
                        //         } else {
                        //           Constants.showToast(
                        //               "Permission is required to export the data.");
                        //         }
                        //       });
                        //     } else {
                        //       backupNotification(
                        //           context: context,
                        //           message:
                        //               " Account is required to access this feature ");
                        //     }
                        //   },
                        //   visualDensity:
                        //       const VisualDensity(horizontal: 0, vertical: 0),
                        //   leading: const Icon(
                        //     Icons.file_upload_outlined,
                        //     color: Color(0XFF805531),
                        //   ),
                        //   title: Text(
                        //     'Export',
                        //     style: CommanStyle.bothPrimary16600(context),
                        //   ),
                        // ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: PopupMenuButton(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: screenWidth > 450 ? 15 : 17),
                                  child: Icon(
                                    size: screenWidth > 450 ? 27 : 24,
                                    Icons.cloud_download,
                                    color: Color(0XFF805531),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(
                                      right: screenWidth > 450 ? 1 : 20.0),
                                  child: Text(
                                    "Back up",
                                    style:
                                        CommanStyle.bothPrimary16600(context),
                                  ),
                                ),
                              ],
                            ),
                            onSelected: (val) async {
                              await SharPreferences.setString('OpenAd', '1');
                              if (isLoggedIn) {
                                if (val == 'export') {
                                  // Constants.showToast(
                                  //     "Save your Verse markings in My Library");
                                  showImportExportInfo(context, () async {
                                    final permission = await ExportDb
                                        .requestStoragePermission();
                                    if (permission) {
                                      updateLoading(true,
                                          mess:
                                              'Exporting the data. Please wait');
                                      await SharPreferences.setString(
                                          'OpenAd', '1');
                                      if (context.mounted) {
                                        await ExportDb.getAllDataToExport(
                                            context);
                                      }
                                      await SharPreferences.setString(
                                          'OpenAd', '1');
                                      updateLoading(false);
                                    } else {
                                      await SharPreferences.setString(
                                          'OpenAd', '1');
                                      Constants.showToast(
                                          "Permission is required to export the data.");
                                    }
                                  });
                                } else {
                                  showImportInfo(context, () async {
                                    await SharPreferences.setString(
                                        'OpenAd', '1');
                                    updateLoading(true,
                                        mess:
                                            'Importing the data. Please wait');
                                    await ExportDb.importData();
                                    await SharPreferences.setString(
                                        'OpenAd', '1');
                                    updateLoading(false);
                                    Get.offAll(() => HomeScreen(
                                        From: "splash",
                                        selectedVerseNumForRead: "",
                                        selectedBookForRead: "",
                                        selectedChapterForRead: "",
                                        selectedBookNameForRead: "",
                                        selectedVerseForRead: ""));
                                  });
                                }
                              } else {
                                updateLoading(false);
                                await SharPreferences.setString('OpenAd', '1');
                                backupNotification(
                                    context: context,
                                    message:
                                        " Account is required to access this feature ");
                                // Constants.showToast('You have to login first');
                                // Get.to(() => LoginScreen(hasSkip: false),
                                //     transition: Transition.cupertinoDialog,
                                //     duration:
                                //         const Duration(milliseconds: 300));
                              }
                            },
                            itemBuilder: (BuildContext bc) {
                              return [
                                PopupMenuItem(
                                    value: 'export',
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.file_upload_outlined,
                                          color:
                                              CommanColor.whiteBlack(context),
                                        ),
                                        const Text('Export')
                                      ],
                                    )),
                                PopupMenuItem(
                                    value: 'Import',
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.file_download_outlined,
                                          color:
                                              CommanColor.whiteBlack(context),
                                        ),
                                        const Text('Import')
                                      ],
                                    ))
                              ];
                            },
                          ),
                        ),
                        // ListTile(
                        //   dense: true,
                        //   onTap: () async {
                        //     // Get.back();
                        //     // if (controller.adFree.value == false) {
                        //     //   controller.bannerAd?.dispose();
                        //     //   controller.bannerAd?.load();
                        //     // }
                        //     // if (isLoggedIn) {
                        //     //   showImportInfo(context, () async {
                        //     //     updateLoading(true,
                        //     //         mess: 'Importing the data. Please wait');
                        //     //     await ExportDb.importData();

                        //     //     updateLoading(false);
                        //     //     Get.offAll(() => HomeScreen(
                        //     //         From: "splash",
                        //     //         selectedVerseNumForRead: "",
                        //     //         selectedBookForRead: "",
                        //     //         selectedChapterForRead: "",
                        //     //         selectedBookNameForRead: "",
                        //     //         selectedVerseForRead: ""));
                        //     //   });
                        //     // } else {
                        //     //   updateLoading(false);
                        //     //   backupNotification(
                        //     //       context: context,
                        //     //       message:
                        //     //           " Account is required to access this feature ");
                        //     // }
                        //   },
                        //   visualDensity:
                        //       const VisualDensity(horizontal: 0, vertical: 0),
                        //   leading: const Icon(
                        //     Icons.file_download_outlined,
                        //     color: Color(0XFF805531),
                        //   ),
                        //   title: Text(
                        //     'Back up',
                        //     style: CommanStyle.bothPrimary16600(context),
                        //   ),
                        // ),

                        //Books

                        if (controller.bookAdsStatus.value == 1)
                          ListTile(
                            dense: true,
                            onTap: () async {
                              Get.back();
                              await SharPreferences.setString('OpenAd', '1');
                              if (controller.adFree.value == false) {
                                controller.bannerAd?.dispose();
                                controller.bannerAd?.load();
                              }
                              Get.to(
                                  () => BooksScreen(
                                      bookAdId: controller.bookAdsAppId.value),
                                  transition: Transition.cupertinoDialog,
                                  duration: const Duration(milliseconds: 300));
                            },
                            visualDensity:
                                const VisualDensity(horizontal: 0, vertical: 0),
                            leading: const Icon(
                              Icons.menu_book,
                              color: Color(0XFF805531),
                            ),
                            title: Text(
                              'Books',
                              style: CommanStyle.bothPrimary16600(context),
                            ),
                          ),

                        // More apps
                        ListTile(
                          dense: true,
                          onTap: () async {
                            Get.back();
                            await SharPreferences.setString('OpenAd', '1');
                            if (controller.adFree.value == false) {
                              controller.bannerAd?.dispose();
                              controller.bannerAd?.load();
                            }
                            Get.to(() => const MoreAppsScreen(),
                                transition: Transition.cupertinoDialog,
                                duration: const Duration(milliseconds: 300));
                          },
                          visualDensity:
                              const VisualDensity(horizontal: 0, vertical: 0),
                          leading: const Icon(
                            Icons.app_settings_alt_sharp,
                            color: Color(0XFF805531),
                          ),
                          title: Text(
                            'More Apps',
                            style: CommanStyle.bothPrimary16600(context),
                          ),
                        ),
                        // Survey
                        // ListTile(
                        //   dense: true,
                        //   onTap: () async {
                        //     Get.back();
                        //     if (controller.adFree.value == false) {
                        //       controller.bannerAd?.dispose();
                        //       controller.bannerAd?.load();
                        //     }
                        //     Get.to(() => const FeedbackWebView(),
                        //         transition: Transition.cupertinoDialog,
                        //         duration: const Duration(milliseconds: 300));
                        //   },
                        //   visualDensity:
                        //       const VisualDensity(horizontal: 0, vertical: 0),
                        //   leading: const Icon(
                        //     Icons.edit_calendar,
                        //     color: Color(0XFF805531),
                        //   ),
                        //   title: Text(
                        //     'Survey',
                        //     style: CommanStyle.bothPrimary16600(context),
                        //   ),
                        // ),
                        ListTile(
                          dense: true,
                          onTap: () {
                            Get.back();
                            SharPreferences.getBoolean(
                                    SharPreferences.isNotificationOn)
                                .then((value) {
                              bool natificationValue;
                              value != null
                                  ? natificationValue = value
                                  : natificationValue = true;
                              Get.offAll(() => SettingScreen(
                                        notificationValue: natificationValue,
                                      ))!
                                  .then((value) async {
                                SharPreferences.getString(
                                        SharPreferences.selectedFontSize)
                                    .then((value) {
                                  value == null
                                      ? controller.fontSize.value = 19.0
                                      : controller.fontSize.value =
                                          double.parse(value.toString());
                                });
                                SharPreferences.getString(
                                        SharPreferences.selectedFontFamily)
                                    .then((value) {
                                  value == null
                                      ? controller.selectedFontFamily.value =
                                          "Arial"
                                      : controller.selectedFontFamily.value =
                                          value;
                                });
                              });
                            });
                          },
                          visualDensity:
                              const VisualDensity(horizontal: 0, vertical: 0),
                          leading: Image.asset(
                            Images.setting(context),
                            height: 24,
                            width: 24,
                          ),
                          title: Text(
                            "Settings",
                            style: CommanStyle.bothPrimary16600(context),
                          ),
                        ),
                        ListTile(
                          dense: true,
                          onTap: () async {
                            final appPackageName =
                                (await PackageInfo.fromPlatform()).packageName;
                            String message =
                                ''; // Declare the message variable outside the if-else block
                            String appid;
                            appid = BibleInfo.apple_AppId;
                            if (Platform.isAndroid) {
                              message =
                                  "Hey, I've been using this Bible app that has transformed my daily Bible study experience. Try it now at : https://play.google.com/store/apps/details?id=$appPackageName";
                            } else if (Platform.isIOS) {
                              message =
                                  "Hey, I've been using this Bible app that has transformed my daily Bible study experience. Try it now at : https://itunes.apple.com/app/id$appid"; // Example iTunes URL
                            }

                            if (message.isNotEmpty) {
                              Share.share(message,
                                  sharePositionOrigin: Rect.fromPoints(
                                      const Offset(2, 2), const Offset(3, 3)));
                            } else {
                              print('Message is empty or undefined');
                            }
                          },
                          visualDensity:
                              const VisualDensity(horizontal: 0, vertical: 0),
                          leading: Image.asset(
                            Images.share(context),
                            height: 24,
                            width: 24,
                          ),
                          title: Text(
                            'Share',
                            style: CommanStyle.bothPrimary16600(context),
                          ),
                        ),
                        ListTile(
                          dense: true,
                          onTap: (() async {
                            Get.back();
                            await SharPreferences.setString('OpenAd', '1');
                            // debugPrint(
                            //     "notify ${controller.connectionStatus.first}");
                            return await requestReview(
                                controller.connectionStatus);
                          }),
                          visualDensity:
                              const VisualDensity(horizontal: 0, vertical: 0),
                          leading: Image.asset(
                            Images.rateUs(context),
                            height: 24,
                            width: 24,
                          ),
                          title: Text(
                            'Rate Us',
                            style: CommanStyle.bothPrimary16600(context),
                          ),
                        ),
                        // ListTile(
                        //   dense: true,
                        //   onTap: () {
                        //     Get.back();
                        //     Get.to(() => const AboutUs(),
                        //         transition: Transition.cupertinoDialog,
                        //         duration: const Duration(milliseconds: 300));
                        //   },
                        //   visualDensity:
                        //       const VisualDensity(horizontal: 0, vertical: 0),
                        //   leading: Image.asset(
                        //     Images.aboutUs(context),
                        //     height: 24,
                        //     width: 24,
                        //   ),
                        //   title: Text(
                        //     'About Us',
                        //     style: CommanStyle.bothPrimary16600(context),
                        //   ),
                        // ),
                        const SizedBox(
                          height: 2,
                        ),
                        controller.isAdsCompletlyDisabled.value
                            ? const SizedBox.shrink()
                            : controller.adFree.value
                                ? DateTime.tryParse(
                                            '${controller.RewardAdExpireDate}') !=
                                        null
                                    ? Container(
                                        margin: const EdgeInsets.symmetric(
                                            vertical: 3),
                                        color: CommanColor.lightDarkPrimary(
                                            context),
                                        child: ListTile(
                                          dense: true,
                                          onTap: () {
                                            Navigator.pop(context);
                                            showModalBottomSheet<void>(
                                              context: context,
                                              backgroundColor: Colors.white,
                                              shape:
                                                  const RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.vertical(
                                                  top: Radius.circular(25),
                                                ),
                                              ),
                                              clipBehavior:
                                                  Clip.antiAliasWithSaveLayer,
                                              builder: (BuildContext context) {
                                                final startTime = DateTime.parse(
                                                    '${controller.RewardAdExpireDate}');

                                                DateTime ExpiryDate = startTime;

                                                final currentTime =
                                                    DateTime.now();
                                                final diffDy =
                                                    ExpiryDate.difference(
                                                            currentTime)
                                                        .inDays;

                                                return Stack(
                                                  children: [
                                                    Container(
                                                      decoration: BoxDecoration(
                                                          border: Border.all(
                                                              color:
                                                                  Colors.white),
                                                          borderRadius:
                                                              const BorderRadius
                                                                  .only(
                                                                  topLeft: Radius
                                                                      .circular(
                                                                          20),
                                                                  topRight: Radius
                                                                      .circular(
                                                                          20))),
                                                      height:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .height *
                                                              0.30,
                                                      // color: Colors.white,
                                                      child:
                                                          SingleChildScrollView(
                                                        physics:
                                                            const ScrollPhysics(),
                                                        child: Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          children: <Widget>[
                                                            Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .center,
                                                              children: [
                                                                Image.asset(
                                                                    "assets/feedbacklogo.png",
                                                                    height: 120,
                                                                    width: 120,
                                                                    color: CommanColor
                                                                        .lightDarkPrimary(
                                                                            context)),
                                                              ],
                                                            ),
                                                            // SizedBox(height: 5,),
                                                            Text(
                                                              'Subscription Info',
                                                              style: TextStyle(
                                                                  letterSpacing:
                                                                      BibleInfo
                                                                          .letterSpacing,
                                                                  fontSize:
                                                                      BibleInfo
                                                                              .fontSizeScale *
                                                                          16,
                                                                  color: CommanColor
                                                                      .lightDarkPrimary(
                                                                          context),
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                            ),
                                                            const SizedBox(
                                                              height: 15,
                                                            ),
                                                            Text(
                                                                diffDy > 365
                                                                    ? 'Your subscription will never expire'
                                                                    : '$diffDy day(s) left for the renewal of the subscription.',
                                                                style: TextStyle(
                                                                    letterSpacing:
                                                                        BibleInfo
                                                                            .letterSpacing,
                                                                    fontSize:
                                                                        BibleInfo.fontSizeScale *
                                                                            15,
                                                                    color: CommanColor
                                                                        .lightDarkPrimary(
                                                                            context),
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w400)),
                                                            const SizedBox(
                                                                height: 5),
                                                            Text(
                                                                diffDy > 365
                                                                    ? 'Your subscription period is lifetime'
                                                                    : 'Your subscription expires on ${DateFormat('dd-MM-yyyy').format(ExpiryDate)}',
                                                                style:
                                                                    TextStyle(
                                                                  letterSpacing:
                                                                      BibleInfo
                                                                          .letterSpacing,
                                                                  fontSize:
                                                                      BibleInfo
                                                                              .fontSizeScale *
                                                                          15,
                                                                  color: CommanColor
                                                                      .lightDarkPrimary(
                                                                          context),
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                ))
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      top: 10,
                                                      right: 15,
                                                      child: InkWell(
                                                        child: Icon(
                                                          Icons.close,
                                                          color: CommanColor
                                                              .lightDarkPrimary(
                                                                  context),
                                                          size: 25,
                                                        ),
                                                        onTap: () {
                                                          Navigator.pop(
                                                              context);
                                                        },
                                                      ),
                                                    )
                                                  ],
                                                );
                                              },
                                            );
                                          },
                                          visualDensity: const VisualDensity(
                                              horizontal: 0, vertical: 0),
                                          leading: const Icon(
                                            Icons.info_outline_rounded,
                                            size: 28,
                                            color: Colors.white,
                                          ),
                                          title: const Text("Subscription Info",
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  letterSpacing:
                                                      BibleInfo.letterSpacing,
                                                  fontSize:
                                                      BibleInfo.fontSizeScale *
                                                          16,
                                                  fontWeight: FontWeight.w600)),
                                        ),
                                      )
                                    : Visibility(
                                        visible:
                                            controller.isSubscriptionEnabled ??
                                                false,
                                        child: Container(
                                          color: CommanColor.lightDarkPrimary(
                                              context),
                                          child: ListTile(
                                            dense: true,
                                            onTap: () async {
                                              adsIcon = false;
                                              Get.back();
                                              await SharPreferences.setString(
                                                  'OpenAd', '1');
                                              Get.to(() => RemoveAddScreen(
                                                    sixMonthPlan: controller
                                                            .sixMonthPlan ??
                                                        '',
                                                    oneYearPlan: controller
                                                            .oneYearPlan ??
                                                        '',
                                                    lifeTimePlan: controller
                                                            .lifeTimePlan ??
                                                        '',
                                                    onclick: () {},
                                                  ));
                                            },
                                            visualDensity: const VisualDensity(
                                                horizontal: 0, vertical: 0),
                                            leading: Image.asset(
                                              Images.adFree(context),
                                              height: 24,
                                              width: 24,
                                            ),
                                            title: const Text("Remove Ads",
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    letterSpacing:
                                                        BibleInfo.letterSpacing,
                                                    fontSize: BibleInfo
                                                            .fontSizeScale *
                                                        16,
                                                    fontWeight:
                                                        FontWeight.w600)),
                                          ),
                                        ),
                                      )
                                : Visibility(
                                    visible: controller.isSubscriptionEnabled ??
                                        false,
                                    child: Container(
                                      color:
                                          CommanColor.lightDarkPrimary(context),
                                      child: ListTile(
                                        dense: true,
                                        onTap: () {
                                          adsIcon = false;
                                          Get.back();
                                          Get.to(() => RemoveAddScreen(
                                                sixMonthPlan:
                                                    controller.sixMonthPlan ??
                                                        '',
                                                oneYearPlan:
                                                    controller.oneYearPlan ??
                                                        '',
                                                lifeTimePlan:
                                                    controller.lifeTimePlan ??
                                                        '',
                                                onclick: () {},
                                              ));
                                        },
                                        visualDensity: const VisualDensity(
                                            horizontal: 0, vertical: 0),
                                        leading: Image.asset(
                                          Images.adFree(context),
                                          height: 24,
                                          width: 24,
                                        ),
                                        title: const Text("Remove Ads",
                                            style: TextStyle(
                                                color: Colors.white,
                                                letterSpacing:
                                                    BibleInfo.letterSpacing,
                                                fontSize:
                                                    BibleInfo.fontSizeScale *
                                                        16,
                                                fontWeight: FontWeight.w600)),
                                      ),
                                    ),
                                  ),
                      ],
                    ),
                  ),
            bottomNavigationBar:
                //controller.isBannerAdLoaded.value &&
                !controller.adFree.value && controller.bannerAd != null
                    ?
                    // _adService.bannerAd != null
                    //     ? Padding(
                    //         padding: const EdgeInsets.only(top: 15),
                    //         child: SizedBox(
                    //           height: _adService.bannerAd!.size.height.toDouble(),
                    //           width: _adService.bannerAd!.size.width.toDouble(),
                    //           child: AdWidget(ad: _adService.bannerAd!),
                    //         ),
                    //       )
                    MyAdBanner()
                    // SizedBox(
                    //     height: controller.bannerAd!.size.height.toDouble(),
                    //     width: controller.bannerAd!.size.width.toDouble(),
                    //     child: AdWidget(ad: controller.bannerAd!),
                    //   )
                    : const SizedBox(
                        height: 1,
                      ),
          );
        },
      ),
    );
  }

  Future<void> checkingappcount(List<ConnectivityResult> result) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    appLaunchCount = prefs.getInt('launchCount') ?? 0;
    // appLaunchCount++;
    // debugPrint(" lanuchCount is - $appLaunchCount ");
    // if (appLaunchCount == 2) {
    //   // setState(() {
    //   //   appLaunchCount = 3;
    //   // });
    //   debugPrint(" lanuchCount 2 is - $appLaunchCount ");
    //   Future.delayed(
    //     Duration(minutes: 1),
    //     () async {
    //       await prefs.setInt('launchCount', 3);
    //       appLaunchCount = prefs.getInt('launchCount') ?? 0;
    //       debugPrint("lanuchCount 3 is - $appLaunchCount");
    //       await requestReview(result);
    //     },
    //   );
    // }

    // final currentDate = DateTime.now();
    final getLastOfferShown =
        await SharPreferences.getString(SharPreferences.offerenabled);
    if (getLastOfferShown == '1') {
      // appLaunchCountoffer = prefs.getInt('launchCountoffer') ?? 0;
      // appLaunchCountoffer++;
      debugPrint(" lanuchCount offer is - $appLaunchCountoffer ");
      // if (getLastOfferShown != null) {
      //   final lastOfferShownDate = DateTime.parse(getLastOfferShown);
      //   final diff = currentDate.difference(lastOfferShownDate);
      //   if (diff.inDays >
      //       (int.tryParse(controller.offerDays ?? '') ?? 1)) {
      //     await SharPreferences.setString(
      //         SharPreferences.lastOfferShown, currentDate.toString());
      //     showOfferDialog(controller);
      //   }
      // } else {
      //   await SharPreferences.setString(
      //       SharPreferences.lastOfferShown, currentDate.toString());
      // }
      if (appLaunchCountoffer == 3) {
        setState(() {
          appLaunchCountoffer = 4;
        });
        // Future.delayed(Duration(seconds: 10), () async {
        //   showOfferDialog(controller);
        //   await prefs.setInt('launchCountoffer', appLaunchCountoffer);
        // });
      } else {
        await prefs.setInt('launchCountoffer', appLaunchCountoffer);
      }
    }
  }

  void backupNotification({
    required BuildContext context,
    required String message,
  }) async {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            elevation: 16,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    message,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                      Get.to(() => LoginScreen(hasSkip: false),
                          transition: Transition.cupertinoDialog,
                          duration: const Duration(milliseconds: 300));
                    },
                    child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 32),
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          color: CommanColor.whiteLightModePrimary(context),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(5)),
                          boxShadow: const [
                            BoxShadow(color: Colors.black26, blurRadius: 2)
                          ],
                        ),
                        child: Text(
                          'Sign in',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              letterSpacing: BibleInfo.letterSpacing,
                              fontSize: BibleInfo.fontSizeScale * 14,
                              fontWeight: FontWeight.w500,
                              color: CommanColor.darkModePrimaryWhite(context)),
                        )),
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () async {
                      Navigator.pop(context);
                    },
                    child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 32),
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          color: CommanColor.whiteLightModePrimary(context),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(5)),
                          boxShadow: const [
                            BoxShadow(color: Colors.black26, blurRadius: 2)
                          ],
                        ),
                        child: Text(
                          'Cancel',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              letterSpacing: BibleInfo.letterSpacing,
                              fontSize: BibleInfo.fontSizeScale * 14,
                              fontWeight: FontWeight.w500,
                              color: CommanColor.darkModePrimaryWhite(context)),
                        )),
                  )
                ],
              ),
            ));
      },
    );
  }
}

/// Checks if personalized ads are allowed
Future<bool> isTrackingAllowed() async {
  try {
    // 1. Platform-specific tracking (iOS ATT)
    bool platformTrackingAllowed = true;
    if (Platform.isIOS) {
      var status = await AppTrackingTransparency.trackingAuthorizationStatus;
      if (status == TrackingStatus.notDetermined) {
        status = await AppTrackingTransparency.requestTrackingAuthorization();
      }
      platformTrackingAllowed = status == TrackingStatus.authorized;
    }

    // 2. UMP consent status (for both platforms)
    final umpConsent = await ConsentInformation.instance.canRequestAds();

    // 3. Combined consent status
    return platformTrackingAllowed && umpConsent;
  } catch (e) {
    // DebugConsole.log("Consent check error: $e");
    return false; // Fail-safe to non-personalized
  }
}

class MyAdBanner extends StatefulWidget {
  const MyAdBanner({super.key});

  @override
  State<MyAdBanner> createState() => _MyAdBannerState();
}

class _MyAdBannerState extends State<MyAdBanner> {
  late BannerAd _bannerAd;
  bool _isLoaded = false;

  String? bannerid = '';

  @override
  void initState() {
    super.initState();
    fetchbanner();
  }

  fetchbanner() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final trackingAllowed = await isTrackingAllowed();
    if (mounted) {
      setState(() {
        bannerid = prefs.getString('bannerAdUnitId');
      });
    }
    debugPrint('ad banner id - $bannerid  ${!trackingAllowed}');
    _bannerAd = BannerAd(
      adUnitId: bannerid.toString(),
      size: AdSize.banner,
      request: await AdConsentManager.getAdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          if (mounted) {
            setState(() {
              _isLoaded = true;
            });
          }
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          // DebugConsole.log(
          //     'BannerAd home show Ad error1: ${error.message} - $ad -$bannerid');
        },
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd.dispose(); // Very important
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _isLoaded
        ? SizedBox(
            width: _bannerAd.size.width.toDouble(),
            height: _bannerAd.size.height.toDouble(),
            child: AdWidget(ad: _bannerAd),
          )
        : SizedBox.shrink();
  }
}

class FramedVerseContainer extends StatelessWidget {
  final String backgroundImagePath;
  final Widget child;
  final bool showFrame;

  const FramedVerseContainer({
    super.key,
    required this.backgroundImagePath,
    required this.child,
    this.showFrame = true,
  });

  @override
  Widget build(BuildContext context) {
    final random = Random();
    final bgImages = [
      "assets/im1.jpg",
      "assets/im2.jpg",
      "assets/im3.jpg",
      "assets/im4.jpg",
      "assets/im5.jpg",
    ];
    String randomBgImage = bgImages[random.nextInt(bgImages.length)];

    double screenWidth = MediaQuery.of(context).size.width;
    return SizedBox(
      height: screenWidth < 380
          ? MediaQuery.of(context).size.height * 0.72
          : screenWidth > 450
              ? MediaQuery.of(context).size.height * 0.67
              : MediaQuery.of(context).size.height * 0.62,
      width: MediaQuery.of(context).size.width,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Background image with dark blend
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(randomBgImage),
                fit: BoxFit.cover,
                // colorFilter: ColorFilter.mode(

                //   BlendMode.darken,
                // ),
              ),
              borderRadius: BorderRadius.circular(3),
            ),
          ),

          // Optional frame overlay
          if (showFrame)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Opacity(
                opacity: 0.5,
                child: Image.asset(
                  'assets/icons/Frame_1.png',
                  fit: BoxFit.fill,
                ),
              ),
            ),

          // Main content
          Padding(
            padding: EdgeInsets.all(screenWidth < 380
                ? 19
                : screenWidth > 450
                    ? 34
                    : 12),
            child: child,
          ),
        ],
      ),
    );
  }
}
