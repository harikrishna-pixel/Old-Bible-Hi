import 'package:biblebookapp/controller/dpProvider.dart';
import 'package:biblebookapp/view/constants/constant.dart';
import 'package:biblebookapp/view/screens/dashboard/constants.dart';
import 'package:biblebookapp/view/screens/dashboard/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:biblebookapp/view/constants/colors.dart';
import 'package:biblebookapp/view/constants/images.dart';
import 'package:biblebookapp/view/constants/theme_provider.dart';

class PreferenceSelectionScreen extends StatefulWidget {
  final bool isSetting;
  const PreferenceSelectionScreen({
    super.key,
    required this.isSetting,
  });

  @override
  PreferenceSelectionScreenState createState() =>
      PreferenceSelectionScreenState();
}

class PreferenceSelectionScreenState extends State<PreferenceSelectionScreen> {
  bool isLoading = false;
  final Map<String, String> _iconNames = {
    // "Anxiety": "headache",
    "Hope": "protest",
    //"Depression": "sad",
    "God's Promises": "encouragement",
    "faith-in-hard-times": "pray1",
    "Courage": "family",
    "Forgiveness": "love",
    "Friendship": "people",
    "Healing": "healing",
    "Motivational": "dancing",
    // "Loneliness": "alone",
    "Love": "engagement-ring",
    "Comforting": "compassion",
    "Peace": "dove",
    "Protection": "shield",
    "Prayers": "pray",
    "Salvation": "salvation",
    "Thankful": "thank-you",
    "Trust": "trust",
    // "Women of Strength": "feminism",
  };
  int saveDay = 9;
  Set<String> _selectedCategories = {};
  late SharedPreferences _prefs;

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    _prefs = await SharedPreferences.getInstance();
    final saved = _prefs.getStringList('selected_categories') ?? [];
    setState(() {
      _selectedCategories = saved.toSet();
    });
  }

  // Future<void> _savePreferences() async {
  //   await _prefs.setStringList(
  //       'selected_categories', _selectedCategories.toList());

  //   DBHelper().db.then((dailyVersesMainList) {
  //     dailyVersesMainList!
  //         .rawQuery("SELECT * From dailyVersesMainList")
  //         .then((dailyVersesMainData) async {
  //       for (var i = 0; i < dailyVersesMainData.length; i++) {
  //         var selectedVersesMainData = DailyVersesMainListModel(
  //           verse: dailyVersesMainData[i]["Verse"].toString().length == 2
  //               ? "${int.parse(dailyVersesMainData[i]["Verse"].toString()) - 1}"
  //               : "${int.parse(dailyVersesMainData[i]["Verse"].toString().split("-").first) - 1}",
  //           book: "${dailyVersesMainData[i]["Book"]}",
  //           bookId: int.parse(dailyVersesMainData[i]["Book_Id"].toString()) - 1,
  //           categoryId:
  //               int.parse(dailyVersesMainData[i]["Category_Id"].toString()),
  //           categoryName: "${dailyVersesMainData[i]["Category_Name"]}",
  //           chapter:
  //               int.parse(dailyVersesMainData[i]["Chapter"].toString()) - 1,
  //         );
  //         await dailyVersesMainList.execute('DELETE FROM dailyVersesnew');
  //         await dailyVersesMainList
  //             .rawQuery(
  //                 "SELECT * From verse WHERE book_num ='${int.parse(selectedVersesMainData.bookId.toString())}' AND chapter_num ='${int.parse(selectedVersesMainData.chapter.toString())}' AND verse_num ='${int.parse(selectedVersesMainData.verse.toString())}'")
  //             .then((selectedDailyVersesResponse) async {
  //           //    late SharedPreferences _prefs;
  //           // print("selectedDailyVersesResponse");
  //           // print(selectedDailyVersesResponse);
  //           SharedPreferences prefs = await SharedPreferences.getInstance();
  //           List<String> selectedCategories =
  //               prefs.getStringList('selected_categories') ?? [];

  //           for (int i = 0; i < dailyVersesMainData.length; i++) {
  //             dynamic categoryName = dailyVersesMainData[i]["Category_Name"];

  //             if (selectedCategories.contains(categoryName)) {
  //               final bookId =
  //                   int.parse(dailyVersesMainData[i]["Book_Id"].toString());
  //               final chapter =
  //                   int.parse(dailyVersesMainData[i]["Chapter"].toString());
  //               final verse = int.parse(
  //                 dailyVersesMainData[i]["Verse"].toString().contains("-")
  //                     ? dailyVersesMainData[i]["Verse"]
  //                         .toString()
  //                         .split("-")
  //                         .first
  //                     : dailyVersesMainData[i]["Verse"].toString(),
  //               );

  //               List<Map<String, dynamic>> selectedDailyVersesResponse =
  //                   await dailyVersesMainList.rawQuery(
  //                 "SELECT * FROM verse WHERE book_num = '$bookId' AND chapter_num = '$chapter' AND verse_num = '$verse'",
  //               );

  //               if (selectedDailyVersesResponse.isNotEmpty) {
  //                 await dailyVersesMainList.transaction((txn) async {
  //                   var batch = txn.batch();
  //                   var date = DateTime.now().subtract(Duration(days: saveDay));

  //                   var insertData = {
  //                     "Category_Name": categoryName,
  //                     "Category_Id": dailyVersesMainData[i]["Category_Id"],
  //                     "Book": dailyVersesMainData[i]["Book"],
  //                     "Book_Id": bookId,
  //                     "Chapter": chapter,
  //                     "Verse": selectedDailyVersesResponse[0]["content"],
  //                     "Date": "$date",
  //                     "Verse_Num": verse,
  //                   };

  //                   saveDay = saveDay - 1;

  //                   batch.insert('dailyVersesnew', insertData);
  //                   await batch.commit();
  //                 });
  //               }
  //             }
  //           }
  //         });
  //       }
  //     });
  //   });
// }
  // Future<void> _savePreferences() async {
  //   await _prefs.setStringList(
  //       'selected_categories', _selectedCategories.toList());

  //   final dbClient = await DBHelper().db;
  //   if (dbClient == null) return;

  //   final dailyVersesMainData =
  //       await dbClient.rawQuery("SELECT * FROM dailyVersesMainList");

  //   // Clear the table before inserting new values
  //   await dbClient.execute("DELETE FROM dailyVersesnew");

  //   SharedPreferences prefs = await SharedPreferences.getInstance();
  //   List<String> selectedCategories =
  //       prefs.getStringList('selected_categories') ?? [];

  //   int totalEntries = dailyVersesMainData.length;

  //   for (int i = 0; i < totalEntries; i++) {
  //     final data = dailyVersesMainData[i];
  //     final categoryName = data["Category_Name"];

  //     if (selectedCategories.contains(categoryName)) {
  //       final bookId = int.parse(data["Book_Id"].toString());
  //       final chapter = int.parse(data["Chapter"].toString());
  //       final verse = int.parse(
  //         data["Verse"].toString().contains("-")
  //             ? data["Verse"].toString().split("-").first
  //             : data["Verse"].toString(),
  //       );

  //       final selectedVerseResponse = await dbClient.rawQuery(
  //         "SELECT * FROM verse WHERE book_num = '$bookId' AND chapter_num = '$chapter' AND verse_num = '$verse'",
  //       );

  //       if (selectedVerseResponse.isNotEmpty) {
  //         final date = DateTime.now().add(Duration(days: i)); // forward
  //         // Use subtract(Duration(days: totalEntries - i - 1)) if you want to go backward

  //         final insertData = {
  //           "Category_Name": categoryName,
  //           "Category_Id": data["Category_Id"],
  //           "Book": data["Book"],
  //           "Book_Id": bookId,
  //           "Chapter": chapter,
  //           "Verse": selectedVerseResponse[0]["content"],
  //           "Date": "$date",
  //           "Verse_Num": verse,
  //         };

  //         await dbClient.transaction((txn) async {
  //           final batch = txn.batch();
  //           batch.insert('dailyVersesnew', insertData);
  //           await batch.commit(noResult: true);
  //         });
  //       }
  //     }
  //   }
  // }

  Future<void> _savePreferences() async {
    setState(() {
      isLoading = true;
    });
    await _prefs.setStringList(
      'selected_categories',
      _selectedCategories.toList(),
    );

    final dbClient = await DBHelper().db;
    if (dbClient == null) return;

    final dailyVersesMainData =
        await dbClient.rawQuery("SELECT * FROM dailyVersesMainList");

    // Clear the table before inserting new values
    await dbClient.execute("DELETE FROM dailyVersesnew");

    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> selectedCategories =
        prefs.getStringList('selected_categories') ?? [];

    // Filter only matching verses
    List<Map<String, dynamic>> filteredData = dailyVersesMainData
        .where((data) => selectedCategories.contains(data["Category_Name"]))
        .toList();

    // Start from today's date
    DateTime currentDate = DateTime.now();

    for (final data in filteredData) {
      final bookId = int.parse(data["Book_Id"].toString());
      final chapter = int.parse(data["Chapter"].toString());
      final verse = int.parse(
        data["Verse"].toString().contains("-")
            ? data["Verse"].toString().split("-").first
            : data["Verse"].toString(),
      );

      // final selectedVerseResponse = await dbClient.rawQuery(
      //   "SELECT * FROM verse WHERE book_num = '$bookId' AND chapter_num = '$chapter' AND verse_num = '$verse'",
      // );
      final selectedVerseResponse = await dbClient.rawQuery(
        "SELECT * FROM verse WHERE book_num = ? AND chapter_num = ? AND verse_num = ?",
        [bookId, chapter, verse],
      );

      if (selectedVerseResponse.isNotEmpty) {
        final insertData = {
          "Category_Name": data["Category_Name"],
          "Category_Id": data["Category_Id"],
          "Book": data["Book"],
          "Book_Id": bookId,
          "Chapter": chapter,
          "Verse": selectedVerseResponse[0]["content"],
          "Date": "$currentDate",
          "Verse_Num": verse,
        };

        await dbClient.transaction((txn) async {
          final batch = txn.batch();
          batch.insert('dailyVersesnew', insertData);
          await batch.commit(noResult: true);
        });

        // Increase date by 1 day after each successful insert
        currentDate = currentDate.add(const Duration(days: 1));
      }
    }

    setState(() {
      isLoading = false;
    });

    if (widget.isSetting == true) {
      Constants.showToast("Saved successfully");
      Get.back();
    } else {
      // Constants.showToast(
      //     "Hi ${user.displayName}, Welcome to Amplified Bible");
      Constants.showToast("Saved successfully");
      Get.offAll(() => HomeScreen(
          From: "splash",
          selectedVerseNumForRead: "",
          selectedBookForRead: "",
          selectedChapterForRead: "",
          selectedBookNameForRead: "",
          selectedVerseForRead: ""));
      // Get.offAll(() => SignupScreen());
    }
  }

  void _toggleSelection(String category) {
    setState(() {
      if (_selectedCategories.contains(category)) {
        _selectedCategories.remove(category);
      } else {
        _selectedCategories.add(category);
      }
    });
  }

  bool _isSelected(String category) => _selectedCategories.contains(category);

  String _getIconPath(String name, bool selected) {
    final baseName = _iconNames[name] ?? 'default';
    return 'assets/icons/$baseName${!selected ? "_b" : ""}.png';
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: Provider.of<ThemeProvider>(context).currentCustomTheme ==
                AppCustomTheme.vintage
            ? BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(Images.bgImage(context)),
                    fit: BoxFit.fill))
            : null,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(
                height: 10,
              ),
              widget.isSetting == true
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {
                            // checknotification();
                            Navigator.of(context).pop();
                          },
                          child: Icon(
                            Icons.arrow_back_ios,
                            size: screenWidth > 600 ? 29 : 20,
                            color: CommanColor.whiteBlack(context),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(right: 15.0),
                          child: Text("Change Preferences",
                              style: CommanStyle.appBarStyle(context).copyWith(
                                  fontSize: screenWidth > 600
                                      ? BibleInfo.fontSizeScale * 21
                                      : BibleInfo.fontSizeScale * 18)),
                        ),
                        const SizedBox()
                      ],
                    )
                  : SizedBox.shrink(),
              const SizedBox(
                height: 20,
              ),
              Text(
                "Jesus Will Guide You",
                style: TextStyle(
                    color: CommanColor.whiteBlack(context),
                    fontSize: screenWidth > 600 ? 25 : 22,
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                "Choose the area to receive Bible verses based on your needs!",
                style: TextStyle(
                    color: CommanColor.whiteBlack(context),
                    fontSize: screenWidth > 600 ? 22 : 16),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: SingleChildScrollView(
                  child: Wrap(
                    spacing: screenWidth > 600 ? 20 : 10,
                    runSpacing: screenWidth > 600 ? 16 : 12,
                    children: _iconNames.entries.map((category) {
                      final selected = _isSelected(category.key);

                      return InkWell(
                        onTap: () => _toggleSelection(category.key),
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: selected
                                ? Provider.of<ThemeProvider>(context,
                                                listen: false)
                                            .themeMode ==
                                        ThemeMode.dark
                                    ? CommanColor.white
                                    : const Color(0xFF8B5E3C)
                                : Colors.transparent,
                            border: Border.all(
                                color: Provider.of<ThemeProvider>(context,
                                                listen: false)
                                            .themeMode ==
                                        ThemeMode.dark
                                    ? CommanColor.white
                                    : const Color(0xFF8B5E3C)),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Image.asset(
                                _getIconPath(
                                    category.key,
                                    Provider.of<ThemeProvider>(context,
                                                    listen: false)
                                                .themeMode ==
                                            ThemeMode.dark
                                        ? !selected
                                        : selected),
                                width: screenWidth > 600 ? 40 : 20,
                                height: screenWidth > 600 ? 40 : 20,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                category.key,
                                style: TextStyle(
                                  fontSize: screenWidth > 600 ? 19 : null,
                                  color: selected
                                      ? Provider.of<ThemeProvider>(context,
                                                      listen: false)
                                                  .themeMode ==
                                              ThemeMode.dark
                                          ? const Color(0xFF8B5E3C)
                                          : Colors.white
                                      : Provider.of<ThemeProvider>(context,
                                                      listen: false)
                                                  .themeMode ==
                                              ThemeMode.dark
                                          ? CommanColor.white
                                          : const Color(0xFF8B5E3C),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              GestureDetector(
                onTap: isLoading
                    ? null
                    : _selectedCategories.isNotEmpty
                        ? () {
                            _savePreferences();
                            // ScaffoldMessenger.of(context).showSnackBar(
                            //   const SnackBar(
                            //     backgroundColor: CommanColor.darkPrimaryColor,
                            //     content: Text(
                            //       'Preferences saved!',
                            //       style: TextStyle(color: CommanColor.white),
                            //     ),
                            //   ),
                            // );
                          }
                        : null,
                child: Center(
                  child: Container(
                    width: screenWidth > 600 ? 130 : 100,
                    height: screenWidth > 600 ? 65 : 40,
                    decoration: BoxDecoration(
                        color: _selectedCategories.isNotEmpty
                            ? Provider.of<ThemeProvider>(context, listen: false)
                                        .themeMode ==
                                    ThemeMode.dark
                                ? CommanColor.backgrondcolor
                                : const Color(0xFF8B5E3C)
                            : Colors.grey,
                        borderRadius: BorderRadius.circular(9) // Brown color
                        ),
                    // onPressed: _selectedCategories.length == 4
                    //     ? () {
                    //         _savePreferences();
                    //         ScaffoldMessenger.of(context).showSnackBar(
                    //           const SnackBar(
                    //             content: Text('Preferences saved!'),
                    //           ),
                    //         );
                    //       }
                    //     : null,
                    // style: ElevatedButton.styleFrom(
                    //   backgroundColor: const Color(0xFF8B5E3C),
                    //   padding: const EdgeInsets.symmetric(
                    //       horizontal: 40, vertical: 12),
                    // ),
                    child: Center(
                      child: Text(
                          isLoading
                              ? "Loading..."
                              : widget.isSetting == true
                                  ? "Save"
                                  : "Continue",
                          style: TextStyle(
                              fontSize: screenWidth > 600 ? 20 : 17,
                              color: _selectedCategories.isNotEmpty
                                  ? Provider.of<ThemeProvider>(context,
                                                  listen: false)
                                              .themeMode ==
                                          ThemeMode.dark
                                      ? CommanColor.darkPrimaryColor
                                      : CommanColor.white
                                  : null)),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              widget.isSetting != true
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "You can change these anytime in Settings.",
                          style: TextStyle(
                              color: CommanColor.whiteBlack(context),
                              fontSize: screenWidth > 600 ? 21 : 16,
                              fontStyle: FontStyle.italic,
                              fontWeight: FontWeight.w400),
                        ),
                      ],
                    )
                  : SizedBox(),
              const SizedBox(height: 16),
            ]),
          ),
        ),
      ),
    );
  }
}
