import 'dart:async';
import 'dart:developer';
import 'dart:io';
import 'package:biblebookapp/Model/product_details_model.dart' as m;
import 'package:biblebookapp/core/notifiers/download.notifier.dart';
import 'package:biblebookapp/view/constants/share_preferences.dart';
import 'package:biblebookapp/view/constants/theme_provider.dart';
import 'package:biblebookapp/view/screens/dashboard/constants.dart';
import 'package:biblebookapp/view/screens/dashboard/home_screen.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:http/http.dart' as http;
import 'package:biblebookapp/controller/api_service.dart';
import 'package:biblebookapp/view/constants/colors.dart';
import 'package:biblebookapp/view/constants/constant.dart';
import 'package:biblebookapp/view/constants/images.dart';
import 'package:carousel_slider_plus/carousel_slider_plus.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_storekit/in_app_purchase_storekit.dart';
import 'package:in_app_purchase_storekit/store_kit_wrappers.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher_string.dart';
import '../../../controller/dashboard_controller.dart';

DateTime addSixMonths({DateTime? customDate}) {
  final date = customDate ?? DateTime.now();
  int year = date.year;
  int month = date.month + 6;

  if (month > 12) {
    year += 1;
    month -= 12;
  }

  int day = date.day;

  // Adjust the day if it exceeds the number of days in the target month
  int daysInNewMonth = DateTime(year, month + 1, 0).day;
  if (day > daysInNewMonth) {
    day = daysInNewMonth;
  }

  return DateTime(year, month, day);
}

rewardEarned(BuildContext context, Function() onTap) {
  showDialog(
    context: context,
    builder: (context) {
      return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 16,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "Rewards claimed! Enjoy ad-free reward for 3 days from now!",
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: onTap,
                  child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 32),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: CommanColor.whiteLightModePrimary(context),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(5)),
                        boxShadow: const [
                          BoxShadow(color: Colors.black26, blurRadius: 2)
                        ],
                      ),
                      child: Text(
                        'Okay',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            letterSpacing: BibleInfo.letterSpacing,
                            fontSize: BibleInfo.fontSizeScale * 14,
                            fontWeight: FontWeight.w500,
                            color: CommanColor.darkModePrimaryWhite(context)),
                      )),
                ),
              ],
            ),
          ));
    },
  );
}

final List<PurchaseDetails> _purchases = [];

class RemoveAddScreen extends StatefulWidget {
  final String sixMonthPlan;
  final String oneYearPlan;
  final String lifeTimePlan;
  Function? onclick;
  RemoveAddScreen(
      {super.key,
      required this.sixMonthPlan,
      required this.oneYearPlan,
      required this.lifeTimePlan,
      this.onclick});

  @override
  State<RemoveAddScreen> createState() => _RemoveAddScreenState();
}

class _RemoveAddScreenState extends State<RemoveAddScreen> {
  bool isPurchaseLoading = false;
  bool isRestoreLoading = false;
  bool userTap = false;
  List<ProductDetails> _products = [];
//// In App Purchase
  final InAppPurchase _inAppPurchase = InAppPurchase.instance;
// subscription that listens to a stream of updates to purchase details
  StreamSubscription<List<PurchaseDetails>>? _subscription;
// checks if the API is available on this device
  bool _isAvailable = false;
// keeps a list of products queried from Playstore or app store

// List of users past purchases

  // checks if a user has purchased a certain product
  PurchaseDetails? _hasUserPurchased(String productID) {
    return null;
  }

  Future<void> _buyProduct(ProductDetails prod) async {
    if (!userTap) {
      log("Buy Product");
      try {
        setState(() {
          userTap = true;
        });
        EasyLoading.show();
        await SharPreferences.setString('OpenAd', '1');
        final PurchaseParam purchaseParam = PurchaseParam(productDetails: prod);
        _inAppPurchase.buyNonConsumable(purchaseParam: purchaseParam);
        await SharPreferences.setString('OpenAd', '1');
      } catch (e) {
        await SharPreferences.setString('OpenAd', '1');
        log('Error: $e');
      }
    }
  }

  void _verifyPurchases() {
    PurchaseDetails? purchase = _hasUserPurchased('');
    if (purchase != null && purchase.status == PurchaseStatus.purchased) {}
  }

  restorePurchaseHandle(
      String productId, String date, DashBoardController controller) {
    final dateTime = DateTime.tryParse(date) ?? DateTime.now();
    if (productId == widget.lifeTimePlan) {
      controller.disableAd(const Duration(days: 36500));
    }
    if (productId == widget.oneYearPlan) {
      final dur = DateTime(dateTime.year + 1, dateTime.month, dateTime.day);
      final diff = dur.difference(DateTime.now());
      controller.disableAd(diff);
    }
    if (productId == widget.sixMonthPlan) {
      final dur = addSixMonths(customDate: dateTime);
      final diff = dur.difference(DateTime.now());
      controller.disableAd(diff);
    }
    Get.back();
  }

  void _listenToPurchaseUpdated(List<PurchaseDetails> purchaseDetailsList,
      DashBoardController controller) {
    // ignore: avoid_function_literals_in_foreach_calls
    purchaseDetailsList.forEach((PurchaseDetails purchaseDetails) async {
      log("Purchase State: ${purchaseDetails.status}");
      if (purchaseDetails.status == PurchaseStatus.pending) {
      } else {
        EasyLoading.dismiss();
        setState(() {
          userTap = false;
        });
        if (purchaseDetails.status == PurchaseStatus.error) {
          log('Error: ${purchaseDetails.error}');
        } else if (purchaseDetails.status == PurchaseStatus.purchased ||
            purchaseDetails.status == PurchaseStatus.restored) {
          if (purchaseDetails.status == PurchaseStatus.purchased) {
            if (Platform.isIOS) {
              http.post(
                Uri.parse(kDebugMode
                    ? 'https://sandbox.itunes.apple.com/verifyReceipt'
                    : 'https://buy.itunes.apple.com/verifyReceipt'),
                headers: {
                  'Accept': 'application/json',
                  'Content-Type': 'application/json',
                },
                body: {
                  'receipt-data':
                      purchaseDetails.verificationData.localVerificationData,
                  'exclude-old-transactions': true,
                  'password': controller.sharedSecret
                },
              );
            }
            purchaseSubmit(
                receiptData:
                    '${purchaseDetails.purchaseID}-productId:${purchaseDetails.productID}-date:${DateTime.now()}');
            final todayDate = DateTime.now();
            await SharPreferences.setBoolean("downloadreward", true);

            if (purchaseDetails.productID == widget.sixMonthPlan) {
              final expiryDate = addSixMonths();
              final diff = expiryDate.difference(todayDate);
              controller.disableAd(diff);
            }
            if (purchaseDetails.productID == widget.oneYearPlan) {
              controller.disableAd(const Duration(days: 366));
            }
            if (purchaseDetails.productID == widget.lifeTimePlan) {
              controller.disableAd(const Duration(days: 36500));
            }
            Get.back();
          }
          if (purchaseDetails.status == PurchaseStatus.restored) {
            restorePurchaseHandle(purchaseDetails.productID,
                purchaseDetails.transactionDate ?? '', controller);
          }
        }
        if (purchaseDetails.pendingCompletePurchase) {
          await InAppPurchase.instance.completePurchase(purchaseDetails);
        }
      }
    });
  }

  Future<void> _initialize() async {
    if (mounted) {
      setState(() {
        isPurchaseLoading = true;
      });
    }
    // Check availability of InApp Purchases
    _isAvailable = await _inAppPurchase.isAvailable();
    debugPrint('Is Available: $_isAvailable');
    // perform our async calls only when in-app purchase is available
    if (_isAvailable) {
      await _getUserProducts();
      // _verifyPurchases();

      // listen to new purchases and rebuild the widget whenever
      // there is a new purchase after adding the new purchase to our
      // purchase list
      if (mounted) {
        setState(() {
          isPurchaseLoading = false;
        });
      }
    } else {
      if (mounted) {
        setState(() {
          isPurchaseLoading = false;
        });
      }
    }
  }

  Future<void> _getUserProducts() async {
    // setState(() {});

    final productprovider =
        Provider.of<DownloadProvider>(context, listen: false);

    if (Platform.isIOS) {
      final InAppPurchaseStoreKitPlatformAddition iosPlatformAddition =
          _inAppPurchase
              .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
      await iosPlatformAddition.setDelegate(ExamplePaymentQueueDelegate());

      Set<String> ids = {
        widget.sixMonthPlan,
        widget.oneYearPlan,
        widget.lifeTimePlan
      };

      debugPrint(
          "all plans - $ids  ${_products.isEmpty}  ${await _inAppPurchase.queryProductDetails(ids)}");
      final datafn = await productprovider.loadProductList();

      final datacheck = datafn.map((data) {
        return ProductDetails(
          id: data.id,
          title: data.title,
          description: data.description,
          price: data.price,
          rawPrice: data.rawPrice,
          currencyCode: data.currencyCode,
          currencySymbol: data.currencySymbol,
        );
      }).toList();

      if (_products.isEmpty && datacheck.isEmpty) {
        ProductDetailsResponse response =
            await _inAppPurchase.queryProductDetails(ids);
        debugPrint(
            "all plans product 1 - ${response.error} ${response.notFoundIDs} ${response.productDetails}  ");
        await Future.delayed(Duration(seconds: 10));

        await productprovider
            .saveProductList(response.productDetails.map((iapProduct) {
          return m.ProductDetails(
            id: iapProduct.id,
            title: iapProduct.title,
            description: iapProduct.description,
            price: iapProduct.price,
            rawPrice: iapProduct.rawPrice,
            currencyCode: iapProduct.currencyCode,
            currencySymbol: iapProduct.currencySymbol,
          );
        }).toList());
        setState(() {
          _products = response.productDetails;
          _products.sort((a, b) => a.price.compareTo(b.price));
        });
      } else {
        // ProductDetailsResponse response =
        //     await _inAppPurchase.queryProductDetails(ids);
        //  await Future.delayed(Duration(seconds: 1));
        final data = await productprovider.loadProductList();

        setState(() {
          _products = data.map((data) {
            return ProductDetails(
              id: data.id,
              title: data.title,
              description: data.description,
              price: data.price,
              rawPrice: data.rawPrice,
              currencyCode: data.currencyCode,
              currencySymbol: data.currencySymbol,
            );
          }).toList();
          _products.sort((a, b) => a.price.compareTo(b.price));
        });
      }

      // if (_products.isEmpty) {
      //   _initialize();
      // }

      // debugPrint("all plans product - $_products");
    }
  }

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  @override
  void dispose() {
    super.dispose();
    if (Platform.isIOS) {
      final InAppPurchaseStoreKitPlatformAddition iosPlatformAddition =
          _inAppPurchase
              .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
      iosPlatformAddition.setDelegate(null);
      _subscription?.cancel();
    }
  }

  double calculateOriginalPrice(
      double discountPercent, double discountedPrice) {
    // Convert the discount percentage to a fraction
    double discountFraction = discountPercent / 100;

    // Calculate the original price using the formula: original price = discounted price / (1 - discount fraction)
    double originalPrice = discountedPrice / (1 - discountFraction);

    return originalPrice;
  }

  @override
  Widget build(BuildContext context) {
    return GetX<DashBoardController>(
        init: DashBoardController(),
        builder: (controller) {
          WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
            if (!controller.isRewardedAdLoaded!) {
              controller.loadRewardedAd(
                  adUnitId: controller.rewardedAdUnitId.value);
            }
            _subscription = _inAppPurchase.purchaseStream.listen((data) {
              _listenToPurchaseUpdated(data, controller);
              setState(() {
                _purchases.addAll(data);
                _verifyPurchases();
              });
            });
          });
          double? fakeOffer(ProductDetails product) {
            if (product.id == widget.sixMonthPlan) {
              return double.tryParse(controller.sixMonthPlanValue ?? '');
            }
            if (product.id == widget.oneYearPlan) {
              return double.tryParse(controller.oneYearPlanValue ?? '');
            }
            if (product.id == widget.lifeTimePlan) {
              return double.tryParse(controller.lifeTimePlanValue ?? '');
            }

            return null;
          }

          String getDiscountedPrice(ProductDetails product) {
            final fakeOfferPercentage = fakeOffer(product);
            if (fakeOfferPercentage != null) {
              final fakePrice =
                  calculateOriginalPrice(fakeOfferPercentage, product.rawPrice);
              return '${product.currencySymbol}${fakePrice.toStringAsFixed(2)}';
            }
            return '';
          }

          return Scaffold(
            body: Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              decoration:
                  Provider.of<ThemeProvider>(context).currentCustomTheme ==
                          AppCustomTheme.vintage
                      ? BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage(Images.bgImage(context)),
                              fit: BoxFit.fill))
                      : null,
              child: Column(
                children: [
                  const SizedBox(
                    height: 45,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      InkWell(
                        onTap: () {
                          Get.back();
                          widget.onclick!();
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(left: 15.0),
                          child: Icon(
                            Icons.arrow_back_ios,
                            size: 20,
                            color: CommanColor.whiteBlack(context),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 40.0),
                        child: Text("Remove Ads",
                            style: CommanStyle.appBarStyle(context)),
                      ),
                      const SizedBox()
                    ],
                  ),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.only(bottom: 30, top: 30),
                      children: [
                        ///
                        /////Slider
                        ///
                        CarouselSlider.builder(
                          itemCount: controller.caroausalList.length,
                          itemBuilder: (context, index, realIndex) {
                            var data = controller.caroausalList[index];
                            var card = controller.card[index];
                            var cardtext = controller.cardText[index];
                            return Container(
                              height: MediaQuery.of(context).size.height * 0.22,
                              width: MediaQuery.of(context).size.width * 0.9,
                              decoration: BoxDecoration(
                                  color: controller.colors.value[index],
                                  border: Border.all(
                                      width: 2,
                                      color: controller.colors.value[index]),
                                  // image: DecorationImage(
                                  //     image: AssetImage(data),
                                  //     fit: BoxFit.fill),
                                  borderRadius: BorderRadius.circular(20)),
                              child: Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Image.asset(card),
                                  ),
                                  Expanded(
                                    // Use Expanded widget to allow the Text widget to take available space
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 30),
                                          child: Text(
                                            cardtext,
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              letterSpacing:
                                                  BibleInfo.letterSpacing,
                                              fontSize:
                                                  BibleInfo.fontSizeScale * 18,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            );
                          },
                          options: CarouselOptions(
                              autoPlay: true,
                              height: MediaQuery.of(context).size.height * 0.10,
                              enlargeCenterPage: true,
                              animateToClosest: false,
                              viewportFraction: 1,
                              aspectRatio: 2.0,
                              initialPage: controller.caroausalList.length,
                              // scrollDirection: Axis.horizontal,
                              onPageChanged: (index, reason) {
                                controller.currentCarosal.value = index;
                              }),
                        ),
                        ////
                        ///Slider Indicator
                        ///
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 12),
                            child: DotsIndicator(
                                dotsCount: controller.caroausalList.length,
                                position:
                                    controller.currentCarosal.value.toDouble(),
                                axis: Axis.horizontal,
                                reversed: false,
                                mainAxisAlignment: MainAxisAlignment.center,
                                decorator: DotsDecorator(
                                  activeColor:
                                      CommanColor.whiteLightModePrimary(
                                          context),
                                  color:
                                      CommanColor.lightDarkPrimary200(context),
                                  size: const Size(10, 10),
                                  activeSize: const Size(10, 10),
                                )),
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        _products.isEmpty
                            ? Center(
                                child: Text('',
                                    style: CommanStyle.appBarStyle(context)))
                            : Center(
                                child: Text('Get Premium',
                                    style: CommanStyle.appBarStyle(context))),
                        const SizedBox(
                          height: 10,
                        ),
                        _products.isEmpty
                            ? Center(
                                child: Text('',
                                    style: CommanStyle.appBarStyle(context)))
                            : const Padding(
                                padding: EdgeInsets.symmetric(horizontal: 25),
                                child: Text(
                                  'Get this Ad free Bible to Enjoy the Unlimited Features without Any interruption',
                                  style: TextStyle(
                                    letterSpacing: BibleInfo.letterSpacing,
                                    fontSize: BibleInfo.fontSizeScale * 15.0,
                                    height:
                                        2, //You can set your custom height here
                                  ),
                                  textAlign: TextAlign.center,
                                )),
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 200),
                          child: isPurchaseLoading
                              ? SizedBox(
                                  height: 100,
                                  width: 200,
                                  child: Center(
                                      child: Column(
                                    children: [
                                      const CircularProgressIndicator
                                          .adaptive(),
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text('Please wait...',
                                            style:
                                                CommanStyle.appBarStyle(context)
                                                    .copyWith(fontSize: 12)),
                                      )
                                    ],
                                  )))
                              : _products.isEmpty
                                  ? Center(
                                      child: Text(
                                        "We're unable to load subscription options right now.\n Please try again later",
                                        style: CommanStyle.appBarStyle(context)
                                            .copyWith(fontSize: 12),
                                        textAlign: TextAlign.center,
                                      ),
                                    )
                                  : MediaQuery.removePadding(
                                      context: context,
                                      removeTop: true,
                                      child: ListView.builder(
                                        shrinkWrap: true,
                                        padding: EdgeInsets.zero,
                                        physics:
                                            const NeverScrollableScrollPhysics(),
                                        itemCount: _products.length,
                                        itemBuilder: (context, index) {
                                          return InkWell(
                                            onTap: () async {
                                              await SharPreferences.setString(
                                                  'OpenAd', '1');
                                              _buyProduct(_products[index]);
                                            },
                                            child: Stack(
                                              alignment: Alignment.topRight,
                                              children: [
                                                Container(
                                                  margin: const EdgeInsets
                                                      .symmetric(
                                                      horizontal: 16,
                                                      vertical: 8),
                                                  padding: const EdgeInsets
                                                      .symmetric(
                                                      horizontal: 16,
                                                      vertical: 12),
                                                  decoration: BoxDecoration(
                                                    border: Border.all(
                                                        color: Colors.white
                                                            .withOpacity(0.5),
                                                        width: 2),
                                                    borderRadius:
                                                        BorderRadiusDirectional
                                                            .circular(10),
                                                  ),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Expanded(
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .stretch,
                                                          children: [
                                                            Text(
                                                                _products[index]
                                                                    .description,
                                                                style: CommanStyle
                                                                    .bw14500(
                                                                        context)),
                                                            Visibility(
                                                              visible: getDiscountedPrice(
                                                                      _products[
                                                                          index])
                                                                  .isNotEmpty,
                                                              child: Text(
                                                                getDiscountedPrice(
                                                                    _products[
                                                                        index]),
                                                                style: CommanStyle
                                                                        .bw14400(
                                                                            context)
                                                                    .copyWith(
                                                                        decoration:
                                                                            TextDecoration.lineThrough),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                      Text(
                                                          '${_products[index].price}  ',
                                                          style: CommanStyle
                                                              .bw17500(
                                                                  context)),
                                                      const SizedBox(width: 24),
                                                    ],
                                                  ),
                                                ),
                                                Positioned(
                                                  right: 8,
                                                  top: -2,
                                                  child: Visibility(
                                                    visible: fakeOffer(
                                                            _products[index]) !=
                                                        null,
                                                    child: Image.asset(
                                                      'assets/offer.png',
                                                      height: 70,
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  right: 13,
                                                  top: 14,
                                                  child: Visibility(
                                                    visible: fakeOffer(
                                                            _products[index]) !=
                                                        null,
                                                    child: RotationTransition(
                                                      turns:
                                                          const AlwaysStoppedAnimation(
                                                              45 / 360),
                                                      child: Text(
                                                        '${fakeOffer(_products[index])?.toStringAsFixed(0)}% off',
                                                        style: const TextStyle(
                                                          letterSpacing:
                                                              BibleInfo
                                                                  .letterSpacing,
                                                          fontSize: BibleInfo
                                                                  .fontSizeScale *
                                                              10,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              ],
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                        ),

                        const SizedBox(
                          height: 5,
                        ),
                        !controller.isRewardedAdLoaded!
                            ? SizedBox()
                            : Center(
                                child: Text(
                                  "or",
                                  style: CommanStyle.bw14500(context),
                                ),
                              ),
                        const SizedBox(
                          height: 15,
                        ),
                        !controller.isRewardedAdLoaded!
                            ? SizedBox()
                            : const Padding(
                                padding: EdgeInsets.symmetric(horizontal: 35),
                                child: Text(
                                  'You can watch a short rewarded video to remove all Ads for 3 days',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      letterSpacing: BibleInfo.letterSpacing,
                                      fontSize: BibleInfo.fontSizeScale * 14,
                                      height: 2),
                                ),
                              ),
                        !controller.isRewardedAdLoaded!
                            ? SizedBox()
                            : const SizedBox(
                                height: 15,
                              ),
                        !controller.isRewardedAdLoaded!
                            ? SizedBox()
                            : Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  InkWell(
                                    onTap: () async {
                                      await SharPreferences.setString(
                                          'OpenAd', '1');
                                      if (controller.isRewardedAdLoaded ??
                                          false) {
                                        controller.rewardedAd?.show(
                                          onUserEarnedReward: (AdWithoutView ad,
                                              RewardItem rewardItem) async {
                                            await controller.disableAd(
                                                const Duration(days: 3));
                                            if (context.mounted) {
                                              await rewardEarned(context,
                                                  () async {
                                                // Navigator.pop(context);
                                                // Get.back();
                                                await SharPreferences.setString(
                                                    'OpenAd', '1');
                                                await controller.disableAd(
                                                    const Duration(days: 3));
                                                Get.offAll(() => HomeScreen(
                                                    From: "splash",
                                                    selectedVerseNumForRead: "",
                                                    selectedBookForRead: "",
                                                    selectedChapterForRead: "",
                                                    selectedBookNameForRead: "",
                                                    selectedVerseForRead: ""));
                                              });
                                            }
                                          },
                                        );
                                      } else {
                                        await SharPreferences.setString(
                                            'OpenAd', '1');
                                        controller.loadRewardedAd(
                                            adUnitId: controller
                                                .rewardedAdUnitId.value);
                                        Constants.showToast('Ad not available');
                                      }
                                    },
                                    child: Container(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              0.07,
                                      width: MediaQuery.of(context).size.width *
                                          0.9,
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 20, vertical: 12),
                                      decoration: BoxDecoration(
                                        color: const Color(0XFF1C46B2),
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                      child: const Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.video_call_outlined,
                                            size: 20,
                                            color: Colors.white,
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Text(
                                            "Watch Video Ad",
                                            style:
                                                TextStyle(color: Colors.white),
                                          )
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                        const SizedBox(
                          height: 15,
                        ),
                        isRestoreLoading
                            ? const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  CircularProgressIndicator.adaptive(),
                                ],
                              )
                            : GestureDetector(
                                onTap: () async {
                                  await SharPreferences.setString(
                                      'OpenAd', '1');
                                  setState(() {
                                    isRestoreLoading = true;
                                  });
                                  try {
                                    final res = await restorePurchase();
                                    if (res['status'] == 'success') {
                                      final rawData = res['data']
                                          .toString()
                                          .split('-productId:');
                                      if (rawData.length == 2) {
                                        final data = rawData[1].split('-date:');
                                        final productId = data[0].toString();
                                        final date = data[1].toString();
                                        Constants.showToast(
                                            'Restore Successfull');
                                        restorePurchaseHandle(
                                            productId, date, controller);
                                      }
                                    } else {
                                      Constants.showToast('Failed to Restore');
                                    }
                                  } catch (e) {
                                    Constants.showToast('Failed to Restore');
                                  }
                                  setState(() {
                                    isRestoreLoading = false;
                                  });
                                },
                                child: Text(
                                  'Restore Purchases',
                                  textAlign: TextAlign.center,
                                  style: CommanStyle.bw15500(context),
                                ),
                              ),
                        const SizedBox(
                          height: 15,
                        ),
                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 40),
                          child: Text(
                            '''If you have reinstalled the application on your device or restored a backup onto a new device you can recover ads free version you have already purchased.''',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                letterSpacing: BibleInfo.letterSpacing,
                                fontSize: BibleInfo.fontSizeScale * 12,
                                height: 2),
                          ),
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              GestureDetector(
                                onTap: () async {
                                  await SharPreferences.setString(
                                      'OpenAd', '1');
                                  launchUrlString(
                                      'https://bibleoffice.com/privacy_policy.html');
                                },
                                child: const Text("Privacy Policy",
                                    style: TextStyle(
                                        letterSpacing: BibleInfo.letterSpacing,
                                        fontSize: BibleInfo.fontSizeScale * 12,
                                        decoration: TextDecoration.underline)),
                              ),
                              GestureDetector(
                                onTap: () async {
                                  await SharPreferences.setString(
                                      'OpenAd', '1');
                                  launchUrlString(
                                      'https://bibleoffice.com/terms_conditions.html');
                                },
                                child: const Text("Terms and Conditions",
                                    style: TextStyle(
                                        letterSpacing: BibleInfo.letterSpacing,
                                        fontSize: BibleInfo.fontSizeScale * 12,
                                        decoration: TextDecoration.underline)),
                              )
                            ],
                          ),
                        ),
                        // _buildProductList(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }
}

/// Example implementation of the
/// [`SKPaymentQueueDelegate`](https://developer.apple.com/documentation/storekit/skpaymentqueuedelegate?language=objc).
///
/// The payment queue delegate can be implementated to provide information
/// needed to complete transactions.
class ExamplePaymentQueueDelegate implements SKPaymentQueueDelegateWrapper {
  @override
  bool shouldContinueTransaction(
      SKPaymentTransactionWrapper transaction, SKStorefrontWrapper storefront) {
    return true;
  }

  @override
  bool shouldShowPriceConsent() {
    return false;
  }
}
