// ignore_for_file: use_full_hex_values_for_flutter_colors
import 'package:biblebookapp/core/export_db.dart';
import 'package:biblebookapp/core/notifiers/cache.notifier.dart';
import 'package:biblebookapp/view/constants/constant.dart';
import 'package:biblebookapp/view/constants/images.dart';
import 'package:biblebookapp/view/constants/share_preferences.dart';
import 'package:biblebookapp/view/constants/theme_provider.dart';
import 'package:biblebookapp/view/screens/authenitcation/view/login_screen.dart';
import 'package:biblebookapp/view/screens/dashboard/constants.dart';
import 'package:biblebookapp/view/screens/dashboard/home_screen.dart';
import 'package:biblebookapp/view/screens/dashboard/quotes_library_widget.dart';
import 'package:biblebookapp/view/screens/dashboard/underLine_screen.dart';
import 'package:biblebookapp/view/screens/dashboard/wallpaper_library_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import '../../constants/colors.dart';
import 'bookMarkScreen.dart';
import 'highlight_screen.dart';
import 'image_screen.dart';
import 'notes_screen.dart';

void showImportExportInfo(BuildContext context, Function() onTap) {
  showDialog(
    context: context,
    builder: (context) {
      return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 16,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  BibleInfo.exportText,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    onTap();
                  },
                  child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: CommanColor.whiteLightModePrimary(context),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(5)),
                        boxShadow: const [
                          BoxShadow(color: Colors.black26, blurRadius: 2)
                        ],
                      ),
                      child: Text(
                        'Okay, Export',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            letterSpacing: BibleInfo.letterSpacing,
                            fontSize: BibleInfo.fontSizeScale * 14,
                            fontWeight: FontWeight.w500,
                            color: CommanColor.darkModePrimaryWhite(context)),
                      )),
                )
              ],
            ),
          ));
    },
  );
}

void showImportInfo(BuildContext context, Function() onTap) {
  showDialog(
    context: context,
    builder: (context) {
      return Dialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 16,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  BibleInfo.importText,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    onTap();
                  },
                  child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: CommanColor.whiteLightModePrimary(context),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(5)),
                        boxShadow: const [
                          BoxShadow(color: Colors.black26, blurRadius: 2)
                        ],
                      ),
                      child: Text(
                        'Okay, Import',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            letterSpacing: BibleInfo.letterSpacing,
                            fontSize: BibleInfo.fontSizeScale * 14,
                            fontWeight: FontWeight.w500,
                            color: CommanColor.darkModePrimaryWhite(context)),
                      )),
                )
              ],
            ),
          ));
    },
  );
}

class LibraryScreen extends StatefulWidget {
  final int initialIndex;
  const LibraryScreen({super.key, this.initialIndex = 0});
  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen>
    with SingleTickerProviderStateMixin {
// TabController? _tabcontroller;
  late TabController tabController;
  int selectedTap = 0;
  bool isLoading = false;
  String? message;
  String? user;
  // late User? user;
  @override
  void initState() {
    super.initState();
    checkuserloggedin();
    // user = FirebaseAuth.instance.currentUser;
    tabController = TabController(
        vsync: this, length: 7, initialIndex: widget.initialIndex);
  }

  checkuserloggedin() async {
    final cacheprovider = Provider.of<CacheNotifier>(context, listen: false);

    final data = await cacheprovider.readCache(key: 'user');
    // final dataname = await cacheprovider.readCache(key: 'name');
    if (data != null) {
      setState(() {
        user = data;
      });
    }
    // else {
    //   setState(() {
    //     isLoggedIn = false;
    //   });
    // }
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  updateLoading(bool val, {String? mess}) {
    setState(() {
      isLoading = val;
      message = mess;
    });
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    // debugPrint("sz current width - $screenWidth ");
    return Scaffold(
      body: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: Provider.of<ThemeProvider>(context).currentCustomTheme ==
                  AppCustomTheme.vintage
              ? BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(Images.bgImage(context)),
                      fit: BoxFit.fill))
              : null,
          child: isLoading
              ? Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const CircularProgressIndicator.adaptive(),
                    const SizedBox(height: 20),
                    Text(message ?? '')
                  ],
                )
              : SafeArea(
                  child: Column(
                    children: [
                      // const SizedBox(
                      //   height: 5,
                      // ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkWell(
                            onTap: () {
                              Get.back();
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(left: 15.0),
                              child: Icon(
                                Icons.arrow_back_ios,
                                size: screenWidth > 450 ? 30 : 20,
                                color: CommanColor.whiteBlack(context),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 20.0),
                            child: Text(
                              "My Library",
                              style: CommanStyle.appBarStyle(context).copyWith(
                                  fontSize: screenWidth > 450
                                      ? BibleInfo.fontSizeScale * 30
                                      : BibleInfo.fontSizeScale * 18,
                                  fontWeight: FontWeight.w400),
                            ),
                          ),
                          PopupMenuButton(
                            child: Icon(
                              size: screenWidth > 450 ? 35 : 20,
                              Icons.menu_rounded,
                              color: CommanColor.inDarkWhiteAndInLightPrimary(
                                  context),
                            ),
                            onSelected: (val) async {
                              if (user != null) {
                                if (val == 'export') {
                                  await SharPreferences.setString(
                                      'OpenAd', '1');
                                  Constants.showToast(
                                      "Save your Verse markings in My Library");
                                  showImportExportInfo(context, () async {
                                    await SharPreferences.setString(
                                        'OpenAd', '1');
                                    final permission = await ExportDb
                                        .requestStoragePermission();
                                    if (permission) {
                                      updateLoading(true,
                                          mess:
                                              'Exporting the data. Please wait');
                                      if (context.mounted) {
                                        await ExportDb.getAllDataToExport(
                                            context);
                                      }
                                      await SharPreferences.setString(
                                          'OpenAd', '1');
                                      updateLoading(false);
                                    } else {
                                      await SharPreferences.setString(
                                          'OpenAd', '1');
                                      Constants.showToast(
                                          "Permission is required to export the data.");
                                    }
                                  });
                                } else {
                                  showImportInfo(context, () async {
                                    await SharPreferences.setString(
                                        'OpenAd', '1');
                                    updateLoading(true,
                                        mess:
                                            'Importing the data. Please wait');
                                    await ExportDb.importData();

                                    await SharPreferences.setString(
                                        'OpenAd', '1');
                                    updateLoading(false);
                                    Get.offAll(() => HomeScreen(
                                        From: "splash",
                                        selectedVerseNumForRead: "",
                                        selectedBookForRead: "",
                                        selectedChapterForRead: "",
                                        selectedBookNameForRead: "",
                                        selectedVerseForRead: ""));
                                  });
                                }
                              } else {
                                await SharPreferences.setString('OpenAd', '1');
                                updateLoading(false);
                                backupNotification(
                                    context: context,
                                    message:
                                        " Account is required to access this feature ");
                                // Constants.showToast('You have to login first');
                                // Get.to(() => LoginScreen(hasSkip: false),
                                //     transition: Transition.cupertinoDialog,
                                //     duration:
                                //         const Duration(milliseconds: 300));
                              }
                            },
                            itemBuilder: (BuildContext bc) {
                              return [
                                PopupMenuItem(
                                    value: 'export',
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.file_upload_outlined,
                                          color:
                                              CommanColor.whiteBlack(context),
                                        ),
                                        const Text('Export')
                                      ],
                                    )),
                                PopupMenuItem(
                                    value: 'Import',
                                    child: Row(
                                      children: [
                                        Icon(
                                          Icons.file_download_outlined,
                                          color:
                                              CommanColor.whiteBlack(context),
                                        ),
                                        const Text('Import')
                                      ],
                                    ))
                              ];
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 15),
                      Expanded(
                        child: DefaultTabController(
                            length: 5,
                            initialIndex: 0,
                            animationDuration:
                                const Duration(milliseconds: 300),
                            child: Builder(builder: (context) {
                              Future.delayed(
                                Duration.zero,
                                () {
                                  setState(() {
                                    selectedTap = tabController.index;
                                  });
                                },
                              );
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  SizedBox(
                                    height: screenWidth > 450 ? 55 : 45,
                                    child: TabBar(
                                      controller: tabController,
                                      isScrollable: true,
                                      tabAlignment: TabAlignment.start,
                                      indicatorWeight: 0,
                                      padding: EdgeInsets.zero,
                                      indicatorPadding: const EdgeInsets.only(
                                          right: 2, bottom: 10, left: 0),
                                      labelPadding: const EdgeInsets.only(
                                          right: 8, bottom: 10, left: 5),
                                      indicatorSize: TabBarIndicatorSize.label,
                                      indicator: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(3),
                                          shape: BoxShape.rectangle,
                                          color: CommanColor.lightDarkPrimary(
                                              context)),
                                      onTap: (value) {
                                        setState(() {
                                          selectedTap = value;
                                        });
                                      },
                                      tabs: [
                                        Tab(
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            height: screenWidth > 450 ? 50 : 35,
                                            width:
                                                screenWidth > 450 ? 135 : 110,
                                            decoration: BoxDecoration(
                                                shape: BoxShape.rectangle,
                                                borderRadius:
                                                    BorderRadius.circular(3),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Colors.black38,
                                                    blurRadius: 0.5,
                                                    spreadRadius: 1,
                                                    offset: Offset(0, 1),
                                                  ),
                                                ],
                                                color: selectedTap == 0
                                                    ? CommanColor
                                                        .lightDarkPrimary(
                                                            context)
                                                    : CommanColor.whiteBlack45(
                                                        context)),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                // Image.asset("assets/bookmark_1.png",color: CommanColor.whiteAndDark(context),width: 20,height: 15,),
                                                Icon(
                                                  Icons.bookmark,
                                                  color: selectedTap == 0
                                                      ? Colors.white
                                                      : CommanColor
                                                          .whiteAndDark(
                                                              context),
                                                  size: screenWidth > 450
                                                      ? 22
                                                      : 18,
                                                ),
                                                // SizedBox(width: 2,),
                                                Text(
                                                  "BookMark",
                                                  style: selectedTap ==
                                                          0
                                                      ? CommanStyle.white12400.copyWith(
                                                          fontSize: screenWidth > 450
                                                              ? BibleInfo
                                                                      .fontSizeScale *
                                                                  17
                                                              : BibleInfo
                                                                      .fontSizeScale *
                                                                  12)
                                                      : CommanStyle
                                                              .inDarkPrimaryInLightWhite12400(
                                                                  context)
                                                          .copyWith(
                                                              fontSize: screenWidth >
                                                                      450
                                                                  ? BibleInfo
                                                                          .fontSizeScale *
                                                                      17
                                                                  : BibleInfo
                                                                          .fontSizeScale *
                                                                      12),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Tab(
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            // height: screenWidth > 450 ? 55 : 35,
                                            height: screenWidth > 450 ? 50 : 35,
                                            width:
                                                screenWidth > 450 ? 135 : 110,
                                            decoration: BoxDecoration(
                                                shape: BoxShape.rectangle,
                                                borderRadius:
                                                    BorderRadius.circular(3),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Colors.black38,
                                                    blurRadius: 0.5,
                                                    spreadRadius: 1,
                                                    offset: Offset(0, 1),
                                                  ),
                                                ],
                                                color: selectedTap == 1
                                                    ? CommanColor
                                                        .lightDarkPrimary(
                                                            context)
                                                    : CommanColor.whiteBlack45(
                                                        context)),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                // Image.asset("assets/bookmark_1.png",color: CommanColor.whiteAndDark(context),width: 20,height: 15,),
                                                Icon(
                                                  Icons.brush_sharp,
                                                  color: selectedTap == 1
                                                      ? Colors.white
                                                      : CommanColor
                                                          .whiteAndDark(
                                                              context),
                                                  size: screenWidth > 450
                                                      ? 22
                                                      : 18,
                                                ),
                                                Text(
                                                  "Highlights",
                                                  style: selectedTap ==
                                                          1
                                                      ? CommanStyle.white12400.copyWith(
                                                          fontSize: screenWidth > 450
                                                              ? BibleInfo
                                                                      .fontSizeScale *
                                                                  17
                                                              : BibleInfo
                                                                      .fontSizeScale *
                                                                  12)
                                                      : CommanStyle
                                                              .inDarkPrimaryInLightWhite12400(
                                                                  context)
                                                          .copyWith(
                                                              fontSize: screenWidth >
                                                                      450
                                                                  ? BibleInfo
                                                                          .fontSizeScale *
                                                                      17
                                                                  : BibleInfo
                                                                          .fontSizeScale *
                                                                      12),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Tab(
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            //  height: 35,
                                            height: screenWidth > 450 ? 50 : 35,
                                            width:
                                                screenWidth > 450 ? 135 : 110,
                                            decoration: BoxDecoration(
                                                shape: BoxShape.rectangle,
                                                borderRadius:
                                                    BorderRadius.circular(3),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Colors.black38,
                                                    blurRadius: 0.5,
                                                    spreadRadius: 1,
                                                    offset: Offset(0, 1),
                                                  ),
                                                ],
                                                color: selectedTap == 2
                                                    ? CommanColor
                                                        .lightDarkPrimary(
                                                            context)
                                                    : CommanColor.whiteBlack45(
                                                        context)),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                // Image.asset("assets/bookmark_1.png",color: CommanColor.whiteAndDark(context),width: 20,height: 15,),
                                                Icon(
                                                  Icons.format_underline_sharp,
                                                  color: selectedTap == 2
                                                      ? Colors.white
                                                      : CommanColor
                                                          .whiteAndDark(
                                                              context),
                                                  size: screenWidth > 450
                                                      ? 22
                                                      : 18,
                                                ),
                                                Text(
                                                  "Underline",
                                                  style: selectedTap ==
                                                          2
                                                      ? CommanStyle.white12400.copyWith(
                                                          fontSize: screenWidth > 450
                                                              ? BibleInfo
                                                                      .fontSizeScale *
                                                                  17
                                                              : BibleInfo
                                                                      .fontSizeScale *
                                                                  12)
                                                      : CommanStyle
                                                              .inDarkPrimaryInLightWhite12400(
                                                                  context)
                                                          .copyWith(
                                                              fontSize: screenWidth >
                                                                      450
                                                                  ? BibleInfo
                                                                          .fontSizeScale *
                                                                      17
                                                                  : BibleInfo
                                                                          .fontSizeScale *
                                                                      12),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Tab(
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            // height: 35,
                                            height: screenWidth > 450 ? 50 : 35,
                                            width:
                                                screenWidth > 450 ? 135 : 110,
                                            decoration: BoxDecoration(
                                                shape: BoxShape.rectangle,
                                                borderRadius:
                                                    BorderRadius.circular(3),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Colors.black38,
                                                    blurRadius: 0.5,
                                                    spreadRadius: 1,
                                                    offset: Offset(0, 1),
                                                  ),
                                                ],
                                                color: selectedTap == 3
                                                    ? CommanColor
                                                        .lightDarkPrimary(
                                                            context)
                                                    : CommanColor.whiteBlack45(
                                                        context)),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                // Image.asset("assets/bookmark_1.png",color: CommanColor.whiteAndDark(context),width: 20,height: 15,),
                                                Icon(
                                                  Icons.sticky_note_2_sharp,
                                                  color: selectedTap == 3
                                                      ? Colors.white
                                                      : CommanColor
                                                          .whiteAndDark(
                                                              context),
                                                  size: screenWidth > 450
                                                      ? 22
                                                      : 18,
                                                ),

                                                Text(
                                                  "Notes",
                                                  style: selectedTap ==
                                                          3
                                                      ? CommanStyle.white12400.copyWith(
                                                          fontSize: screenWidth > 450
                                                              ? BibleInfo
                                                                      .fontSizeScale *
                                                                  17
                                                              : BibleInfo
                                                                      .fontSizeScale *
                                                                  12)
                                                      : CommanStyle
                                                              .inDarkPrimaryInLightWhite12400(
                                                                  context)
                                                          .copyWith(
                                                              fontSize: screenWidth >
                                                                      450
                                                                  ? BibleInfo
                                                                          .fontSizeScale *
                                                                      17
                                                                  : BibleInfo
                                                                          .fontSizeScale *
                                                                      12),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Tab(
                                          child: Container(
                                            // height: 35,
                                            height: screenWidth > 450 ? 50 : 35,
                                            width:
                                                screenWidth > 450 ? 135 : 110,
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            decoration: BoxDecoration(
                                                shape: BoxShape.rectangle,
                                                borderRadius:
                                                    BorderRadius.circular(3),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Colors.black38,
                                                    blurRadius: 0.5,
                                                    spreadRadius: 1,
                                                    offset: Offset(0, 1),
                                                  ),
                                                ],
                                                color: selectedTap == 4
                                                    ? CommanColor
                                                        .lightDarkPrimary(
                                                            context)
                                                    : CommanColor.whiteBlack45(
                                                        context)),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                // Image.asset("assets/bookmark_1.png",color: CommanColor.whiteAndDark(context),width: 20,height: 15,),
                                                Icon(
                                                  Icons.image_rounded,
                                                  color: selectedTap == 4
                                                      ? Colors.white
                                                      : CommanColor
                                                          .whiteAndDark(
                                                              context),
                                                  size: screenWidth > 450
                                                      ? 22
                                                      : 18,
                                                ),

                                                Text(
                                                  "Images",
                                                  style: selectedTap ==
                                                          4
                                                      ? CommanStyle.white12400.copyWith(
                                                          fontSize: screenWidth > 450
                                                              ? BibleInfo
                                                                      .fontSizeScale *
                                                                  17
                                                              : BibleInfo
                                                                      .fontSizeScale *
                                                                  12)
                                                      : CommanStyle
                                                              .inDarkPrimaryInLightWhite12400(
                                                                  context)
                                                          .copyWith(
                                                              fontSize: screenWidth >
                                                                      450
                                                                  ? BibleInfo
                                                                          .fontSizeScale *
                                                                      17
                                                                  : BibleInfo
                                                                          .fontSizeScale *
                                                                      12),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Tab(
                                          child: Container(
                                            //  height: 35,
                                            height: screenWidth > 450 ? 50 : 35,
                                            width:
                                                screenWidth > 450 ? 135 : 110,
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            decoration: BoxDecoration(
                                                shape: BoxShape.rectangle,
                                                borderRadius:
                                                    BorderRadius.circular(3),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Colors.black38,
                                                    blurRadius: 0.5,
                                                    spreadRadius: 1,
                                                    offset: Offset(0, 1),
                                                  ),
                                                ],
                                                color: selectedTap == 5
                                                    ? CommanColor
                                                        .lightDarkPrimary(
                                                            context)
                                                    : CommanColor.whiteBlack45(
                                                        context)),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                Image.asset(
                                                  Images.wallpaper,
                                                  height: screenWidth > 450
                                                      ? 22
                                                      : 18,
                                                  width: screenWidth > 450
                                                      ? 22
                                                      : 18,
                                                  color: selectedTap == 5
                                                      ? Colors.white
                                                      : CommanColor
                                                          .whiteAndDark(
                                                              context),
                                                  colorBlendMode:
                                                      BlendMode.srcATop,
                                                ),
                                                Text(
                                                  "Wallpapers",
                                                  style: selectedTap ==
                                                          5
                                                      ? CommanStyle.white12400.copyWith(
                                                          fontSize: screenWidth > 450
                                                              ? BibleInfo
                                                                      .fontSizeScale *
                                                                  17
                                                              : BibleInfo
                                                                      .fontSizeScale *
                                                                  12)
                                                      : CommanStyle
                                                              .inDarkPrimaryInLightWhite12400(
                                                                  context)
                                                          .copyWith(
                                                              fontSize: screenWidth >
                                                                      450
                                                                  ? BibleInfo
                                                                          .fontSizeScale *
                                                                      17
                                                                  : BibleInfo
                                                                          .fontSizeScale *
                                                                      12),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                        Tab(
                                          child: Container(
                                            //  height: 35,
                                            height: screenWidth > 450 ? 50 : 35,
                                            width:
                                                screenWidth > 450 ? 135 : 110,
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10),
                                            decoration: BoxDecoration(
                                                shape: BoxShape.rectangle,
                                                borderRadius:
                                                    BorderRadius.circular(3),
                                                boxShadow: const [
                                                  BoxShadow(
                                                    color: Colors.black38,
                                                    blurRadius: 0.5,
                                                    spreadRadius: 1,
                                                    offset: Offset(0, 1),
                                                  ),
                                                ],
                                                color: selectedTap == 6
                                                    ? CommanColor
                                                        .lightDarkPrimary(
                                                            context)
                                                    : CommanColor.whiteBlack45(
                                                        context)),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceEvenly,
                                              children: [
                                                Image.asset(
                                                  Images.quote,
                                                  height: screenWidth > 450
                                                      ? 22
                                                      : 18,
                                                  width: screenWidth > 450
                                                      ? 22
                                                      : 18,
                                                  color: selectedTap == 6
                                                      ? Colors.white
                                                      : CommanColor
                                                          .whiteAndDark(
                                                              context),
                                                  colorBlendMode:
                                                      BlendMode.srcATop,
                                                ),
                                                Text(
                                                  "Quotes",
                                                  style: selectedTap ==
                                                          6
                                                      ? CommanStyle.white12400.copyWith(
                                                          fontSize: screenWidth > 450
                                                              ? BibleInfo
                                                                      .fontSizeScale *
                                                                  17
                                                              : BibleInfo
                                                                      .fontSizeScale *
                                                                  12)
                                                      : CommanStyle
                                                              .inDarkPrimaryInLightWhite12400(
                                                                  context)
                                                          .copyWith(
                                                              fontSize: screenWidth >
                                                                      450
                                                                  ? BibleInfo
                                                                          .fontSizeScale *
                                                                      17
                                                                  : BibleInfo
                                                                          .fontSizeScale *
                                                                      12),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Flexible(
                                    flex: 1,
                                    child: TabBarView(
                                        physics:
                                            const AlwaysScrollableScrollPhysics(),
                                        controller: tabController,
                                        children: const [
                                          BookMarkScreen(),
                                          HighLightScreen(),
                                          UnderLineScreen(),
                                          NotesScreen(),
                                          ImageScreen(),
                                          WallpaperLibraryWidget(),
                                          QuotesLibraryWidget(),
                                        ]),
                                  ),
                                ],
                              );
                            })),
                      ),
                    ],
                  ),
                )),
    );
  }

  void backupNotification({
    required BuildContext context,
    required String message,
  }) async {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            elevation: 16,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    message,
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                      Get.to(() => LoginScreen(hasSkip: false),
                          transition: Transition.cupertinoDialog,
                          duration: const Duration(milliseconds: 300));
                    },
                    child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 32),
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          color: CommanColor.whiteLightModePrimary(context),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(5)),
                          boxShadow: const [
                            BoxShadow(color: Colors.black26, blurRadius: 2)
                          ],
                        ),
                        child: Text(
                          'Sign in',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              letterSpacing: BibleInfo.letterSpacing,
                              fontSize: BibleInfo.fontSizeScale * 14,
                              fontWeight: FontWeight.w500,
                              color: CommanColor.darkModePrimaryWhite(context)),
                        )),
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () async {
                      Navigator.pop(context);
                    },
                    child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 32),
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          color: CommanColor.whiteLightModePrimary(context),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(5)),
                          boxShadow: const [
                            BoxShadow(color: Colors.black26, blurRadius: 2)
                          ],
                        ),
                        child: Text(
                          'Cancel',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              letterSpacing: BibleInfo.letterSpacing,
                              fontSize: BibleInfo.fontSizeScale * 14,
                              fontWeight: FontWeight.w500,
                              color: CommanColor.darkModePrimaryWhite(context)),
                        )),
                  )
                ],
              ),
            ));
      },
    );
  }
}
