// ignore_for_file: use_full_hex_values_for_flutter_colors

import 'dart:io';

import 'package:biblebookapp/view/constants/colors.dart';
import 'package:biblebookapp/view/constants/share_preferences.dart';
import 'package:biblebookapp/view/constants/theme_provider.dart';
import 'package:biblebookapp/view/screens/dashboard/constants.dart';
import 'package:biblebookapp/view/screens/dashboard/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_widget_from_html_core/flutter_widget_from_html_core.dart';
import 'package:get/get.dart';
import 'package:html/parser.dart';
import 'package:intl/intl.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../Model/dailyVerseList.dart';
import '../../../controller/dpProvider.dart';
import '../../constants/constant.dart';
import '../../constants/images.dart';

class DailyVerse extends StatefulWidget {
  const DailyVerse({super.key});

  @override
  State<DailyVerse> createState() => _DailyVerseState();
}

class _DailyVerseState extends State<DailyVerse> {
  List<DailyVerseList> dailyVerseList = [];

  dailyVerseData() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> selectedCategories =
        prefs.getStringList('selected_categories') ??
            [
              'faith-in-hard-times',
              //"Motivational",
            ];

    final dbClient = await DBHelper().db;
    if (dbClient == null) return;

    final data = selectedCategories.isEmpty ? "dailyVerses" : "dailyVersesnew";

    debugPrint("list of $selectedCategories. $data");

    List<Map<String, dynamic>> dailyVerses =
        await dbClient.rawQuery("SELECT * FROM $data");

    List<DailyVerseList> filteredList = [];
    final today = DateTime.now();
    final todayString = DateFormat('yyyy-MM-dd').format(today);

    debugPrint("All dates from DB:");
    for (var i in dailyVerses) {
      debugPrint(i["Date"]);
    }

    for (var i in dailyVerses) {
      String verseDateString = i["Date"];
      DateTime verseDate;

      try {
        verseDate = DateTime.parse(verseDateString);
      } catch (e) {
        debugPrint("Invalid date format: ${i["Date"]}");
        continue;
      }

      // // Skip future dates
      // if (verseDate.isAfter(today)) continue;

      // Compare just the date (ignore time)
      final verseDateOnly = DateFormat('yyyy-MM-dd').format(verseDate);
      final todayOnly = DateFormat('yyyy-MM-dd').format(today);

      if (verseDateOnly.compareTo(todayOnly) > 0) {
        continue;
      }

      List<Map<String, dynamic>> bookData = await dbClient.rawQuery(
        "SELECT DISTINCT title FROM book WHERE book_num = ? LIMIT 1",
        [i["Book_Id"]],
      );

      String bookName =
          bookData.isNotEmpty ? bookData.first["title"] as String : "Unknown";

      filteredList.add(DailyVerseList(
        categoryName: "${i["Category_Name"]}",
        categoryId: int.parse("${i["Category_Id"]}"),
        book: bookName,
        bookId: int.parse("${i["Book_Id"]}"),
        chapter: int.parse("${i["Chapter"]}"),
        verse: "${i["Verse"]}",
        date: "${i["Date"]}",
        verseNum: int.parse("${i["Verse_Num"]}"),
      ));
    }
    debugPrint("Filtered List Dates:");
    for (var i in filteredList) {
      debugPrint(i.date);
    }

    // Sort: today's verse first, then others in descending date order
    filteredList.sort((a, b) {
      DateTime dateA = DateTime.parse(a.date.toString());
      DateTime dateB = DateTime.parse(b.date.toString());

      bool isTodayA = DateFormat('yyyy-MM-dd').format(dateA) == todayString;
      bool isTodayB = DateFormat('yyyy-MM-dd').format(dateB) == todayString;

      if (isTodayA && !isTodayB) return -1;
      if (!isTodayA && isTodayB) return 1;

      return dateB.compareTo(dateA); // Newest to oldest
    });

    setState(() {
      dailyVerseList = filteredList;
    });

    debugPrint("dailyVerseList length - ${dailyVerseList.length}");
  }

//   dailyVerseData() async {
//     final prefs = await SharedPreferences.getInstance();
//     List<String> selectedCategories =
//         prefs.getStringList('selected_categories') ??
//             [
//               'faith-in-hard-times',
//               //"Motivational",
//             ];

//     final dbClient = await DBHelper().db;
//     if (dbClient == null) return;

//     final data = selectedCategories.isEmpty ? "dailyVerses" : "dailyVersesnew";

//     debugPrint("list of $selectedCategories. $data");

//     List<Map<String, dynamic>> dailyVerses =
//         await dbClient.rawQuery("SELECT * FROM $data");

//     List<DailyVerseList> filteredList = [];
//     final today = DateTime.now();
//     final todayString = DateFormat('yyyy-MM-dd').format(today);

//     for (var i in dailyVerses) {
//       // Parse date from DB
//       String verseDateString = i["Date"];
//       DateTime verseDate;

//       try {
//         verseDate = DateTime.parse(verseDateString);
//       } catch (e) {
//         debugPrint("Invalid date format: ${i["Date"]}");
//         continue;
//       }

//       // Exclude future verses (after today)
//       if (verseDate.isAfter(today)) {
//         continue;
//       }

//       // Get book title using bookId
//       List<Map<String, dynamic>> bookData = await dbClient.rawQuery(
//         "SELECT DISTINCT title FROM book WHERE book_num = ? LIMIT 1",
//         [i["Book_Id"]],
//       );

//       String bookName =
//           bookData.isNotEmpty ? bookData.first["title"] as String : "Unknown";

//       filteredList.add(DailyVerseList(
//         categoryName: "${i["Category_Name"]}",
//         categoryId: int.parse("${i["Category_Id"]}"),
//         book: bookName,
//         bookId: int.parse("${i["Book_Id"]}"),
//         chapter: int.parse("${i["Chapter"]}"),
//         verse: "${i["Verse"]}",
//         date: "${i["Date"]}",
//         verseNum: int.parse("${i["Verse_Num"]}"),
//       ));
//     }

// //     // Get today's date in "yyyy-MM-dd" format
// //     final String todayString1 =
// //         DateTime.now().toIso8601String().substring(0, 10);

// // // Sort the list: today’s verse first, then newer to older
// //     filteredList.sort((a, b) {
// //       DateTime dateA = DateTime.parse(a.date.toString());
// //       DateTime dateB = DateTime.parse(b.date.toString());

// //       // Check if a or b is today
// //       bool isTodayA = dateA.toString().substring(0, 10) == todayString1;
// //       bool isTodayB = dateB.toString().substring(0, 10) == todayString1;

// //       if (isTodayA && !isTodayB) {
// //         return -1; // a is today, b is not → a comes first
// //       }
// //       if (!isTodayA && isTodayB) {
// //         return 1; // b is today, a is not → b comes first
// //       }

// //       // Neither or both are today → sort by date descending
// //       return dateB.compareTo(dateA);
// //     });

//     // // Sort the list with today's verse first, then older verses in descending order
//     // filteredList.sort((a, b) {
//     //   DateTime dateA = DateTime.parse(a.date.toString());
//     //   DateTime dateB = DateTime.parse(b.date.toString());
//     //   if (dateA.isAtSameMomentAs(dateB)) return 0;
//     //   // Today's verse comes first
//     //   if (dateA.toString().substring(0, 10) == todayString) return -1;
//     //   if (dateB.toString().substring(0, 10) == todayString) return 1;
//     //   // Then sort older verses by date (newest to oldest)
//     //   return dateB.compareTo(dateA);
//     // });

//     setState(() {
//       dailyVerseList = filteredList;
//     });
//     debugPrint("dailyVerseList lenght - ${dailyVerseList.length}");
//   }

  @override
  void initState() {
    super.initState();
    dailyVerseData();
  }

  @override
  Widget build(BuildContext context) {
    void showModalBottomSheetDaily(DailyVerseList data) {
      showModalBottomSheet(
        enableDrag: true,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20), topRight: Radius.circular(20))),
        context: context,
        builder: (BuildContext context) {
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20))),
            // height: MediaQuery.of(context).size.height*0.3,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    height: 3,
                    width: 45,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(3),
                        color: CommanColor.lightDarkPrimary(context)),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  HtmlWidget(
                    '''${data.verse}''',
                    textStyle: CommanStyle.black15400,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                          "${data.book} ${data.chapter! + 1}: ${data.verseNum! + 1}",
                          textAlign: TextAlign.right,
                          style: CommanStyle.black15400),
                    ],
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      InkWell(
                        onTap: () async {
                          await Clipboard.setData(ClipboardData(
                              text:
                                  "${parse(data.verse).body?.text} \n${data.book} ${data.chapter! + 1}:${data.verseNum! + 1}"));
                          Constants.showToast("Copied");
                        },
                        child: Column(
                          children: [
                            Image.asset("assets/copy.png",
                                height: 40,
                                color: CommanColor.lightDarkPrimary(context)),
                            const SizedBox(
                              height: 15,
                            ),
                            Text(
                              "Copy",
                              style: CommanStyle.bothPrimary14500(context),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        width: 30,
                      ),
                      InkWell(
                        onTap: () async {
                          // debugPrint(
                          //   "bookid - ${int.parse(data.bookId.toString())} chapter - ${1 + int.parse(data.chapter.toString())} verseno - ${1 + int.parse(data.verseNum.toString())} book - ${data.book.toString()}  vcontent - ${parse(data.verse).body?.text.toString()} ",
                          // );

                          await SharPreferences.setString(
                              SharPreferences.selectedBook,
                              data.book.toString());

                          await SharPreferences.setString(
                              SharPreferences.selectedChapter,
                              "${1 + int.parse(data.chapter.toString())}");
                          await SharPreferences.setString(
                              SharPreferences.selectedBookNum,
                              "${int.parse(data.bookId.toString())}");
                          Get.offAll(
                              () => HomeScreen(
                                  From: "Daily",
                                  selectedBookForRead:
                                      int.parse(data.bookId.toString()),
                                  selectedChapterForRead:
                                      1 + int.parse(data.chapter.toString()),
                                  selectedVerseNumForRead:
                                      1 + int.parse(data.verseNum.toString()),
                                  selectedBookNameForRead: data.book.toString(),
                                  selectedVerseForRead:
                                      parse(data.verse).body?.text.toString()),
                              transition: Transition.cupertinoDialog,
                              duration: const Duration(milliseconds: 300));
                          // await SharPreferences.setString(
                          //     SharPreferences.selectedBookNum,
                          //     ((data.bookId ?? 1) - 1).toString());
                          // await SharPreferences.setString(
                          //     SharPreferences.selectedChapter,
                          //     data.chapter?.toString() ?? '');
                          // await SharPreferences.setString(
                          //     SharPreferences.selectedBook,
                          //     data.book.toString());
                          // Get.offAll(
                          //     () => HomeScreen(
                          //         From: "Read",
                          //         selectedBookForRead:
                          //             int.parse(data.bookId.toString()),
                          //         selectedChapterForRead:
                          //             int.parse(data.chapter.toString()),
                          //         selectedVerseNumForRead:
                          //             int.parse(data.verseNum.toString()),
                          //         selectedBookNameForRead: data.book.toString(),
                          //         selectedVerseForRead:
                          //             parse(data.verse).body?.text.toString()),
                          //     transition: Transition.cupertinoDialog,
                          //     duration: const Duration(milliseconds: 300));
                        },
                        child: Column(
                          children: [
                            Container(
                                padding: const EdgeInsets.all(8),
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: CommanColor.lightDarkPrimary(
                                            context),
                                        width: 1.2),
                                    borderRadius: BorderRadius.circular(3)),
                                child: Image.asset(
                                  "assets/reading_book.png",
                                  height: 25,
                                  width: 15,
                                  color: CommanColor.lightDarkPrimary(context),
                                )),
                            const SizedBox(
                              height: 15,
                            ),
                            Text("Read",
                                style: CommanStyle.bothPrimary14500(context)),
                          ],
                        ),
                      ),
                      const SizedBox(
                        width: 30,
                      ),
                      InkWell(
                        onTap: () async {
                          final appPackageName =
                              (await PackageInfo.fromPlatform()).packageName;
                          String message =
                              ''; // Declare the message variable outside the if-else block
                          String appid;
                          appid = BibleInfo.apple_AppId;
                          if (Platform.isAndroid) {
                            message =
                                "${parse(data.verse).body?.text} \n${data.book} ${data.chapter}:${data.verseNum} \nYou can read more at App \nhttps://play.google.com/store/apps/details?id=$appPackageName";
                          } else if (Platform.isIOS) {
                            message =
                                "${parse(data.verse).body?.text} \n${data.book} ${data.chapter}:${data.verseNum} \nYou can read more at App \nhttps://itunes.apple.com/app/id$appid"; // Example iTunes URL
                          }

                          if (message.isNotEmpty) {
                            Share.share(message,
                                sharePositionOrigin: Rect.fromPoints(
                                    const Offset(2, 2), const Offset(3, 3)));
                          } else {
                            print('Message is empty or undefined');
                          }
                        },
                        child: Column(
                          children: [
                            Image.asset("assets/share.png",
                                height: 40,
                                color: CommanColor.lightDarkPrimary(context)),
                            const SizedBox(
                              height: 15,
                            ),
                            Text("Share",
                                style: CommanStyle.bothPrimary14500(context)),
                          ],
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          );
        },
      );
    }

    double screenWidth = MediaQuery.of(context).size.width;
    debugPrint("sz current width - $screenWidth ");

    return Scaffold(
      body: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: Provider.of<ThemeProvider>(context).currentCustomTheme ==
                  AppCustomTheme.vintage
              ? BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(Images.bgImage(context)),
                      fit: BoxFit.fill))
              : null,
          child: SafeArea(
            child: Column(
              children: [
                SizedBox(
                  height: 5,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(left: 15.0),
                        child: Icon(
                          Icons.arrow_back_ios,
                          size: screenWidth > 450 ? 30 : 20,
                          color: CommanColor.whiteBlack(context),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 20.0),
                      child: Text(
                        "Daily Verse",
                        style: CommanStyle.appBarStyle(context).copyWith(
                            fontSize: screenWidth > 450
                                ? BibleInfo.fontSizeScale * 30
                                : BibleInfo.fontSizeScale * 18,
                            fontWeight: FontWeight.w400),
                      ),
                    ),
                    SizedBox()
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Expanded(
                  child: ListView.builder(
                    physics: const ScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: dailyVerseList.length,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 15, vertical: 10),
                    itemBuilder: (context, index) {
                      List<DailyVerseList> reversedDailyVerseList =
                          dailyVerseList.toList();
                      //  dailyVerseList.reversed.toList();
                      var data = reversedDailyVerseList[index];
                      DateTime date = DateTime.parse(data.date.toString());
                      String currentDate =
                          DateFormat("dd-MM-yyyy").format(DateTime.now());
                      String yesterdayDate = DateFormat("dd-MM-yyyy")
                          .format(DateTime.now().subtract(Duration(days: 1)));
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: Container(
                          padding: const EdgeInsets.all(10.0),
                          margin: const EdgeInsets.only(bottom: 10.0),
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color:
                                      CommanColor.inDarkWhiteAndInLightPrimary(
                                          context),
                                  width: 1.3),
                              borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    DateFormat("dd-MM-yyyy").format(date) ==
                                            yesterdayDate
                                        ? "Yesterday"
                                        : DateFormat("dd-MM-yyyy")
                                                    .format(date) ==
                                                currentDate
                                            ? "Today"
                                            : DateFormat("dd-MM-yyyy")
                                                .format(date),
                                    style:
                                        CommanStyle.bw16500(context).copyWith(
                                      fontSize: screenWidth > 450
                                          ? BibleInfo.fontSizeScale * 20
                                          : BibleInfo.fontSizeScale * 16,
                                    ),
                                  ),
                                  InkWell(
                                      onTap: () {
                                        showModalBottomSheetDaily(data);
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.all(0.0),
                                        child: Icon(
                                          Icons.more_vert,
                                          color:
                                              CommanColor.whiteBlack(context),
                                          size: 24,
                                        ),
                                      )),
                                ],
                              ),
                              const SizedBox(
                                height: 2,
                              ),
                              GestureDetector(
                                  onTap: () {
                                    showModalBottomSheetDaily(data);
                                  },
                                  child: HtmlWidget(
                                    data.verse ?? '',
                                    textStyle:
                                        CommanStyle.bw14400(context).copyWith(
                                      fontSize: screenWidth > 450
                                          ? BibleInfo.fontSizeScale * 19
                                          : BibleInfo.fontSizeScale * 14,
                                    ),
                                  )),
                              const SizedBox(
                                height: 5,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Text(
                                    "${data.book} ${data.chapter! + 1}:${data.verseNum! + 1}",
                                    style:
                                        CommanStyle.bw14400(context).copyWith(
                                      fontSize: screenWidth > 450
                                          ? BibleInfo.fontSizeScale * 19
                                          : BibleInfo.fontSizeScale * 14,
                                    ),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                )
              ],
            ),
          )),
    );
  }
}
