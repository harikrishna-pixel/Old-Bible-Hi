import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:app_tracking_transparency/app_tracking_transparency.dart';
import 'package:biblebookapp/Model/mainBookListModel.dart';
import 'package:biblebookapp/controller/dashboard_controller.dart';
import 'package:biblebookapp/core/extract_zip_json.dart';
import 'package:biblebookapp/core/notifiers/download.notifier.dart';
import 'package:biblebookapp/initialization_helper.dart';
import 'package:biblebookapp/view/constants/assets_constants.dart';
import 'package:biblebookapp/view/constants/colors.dart';
import 'package:biblebookapp/view/constants/theme_provider.dart';
import 'package:biblebookapp/view/screens/dashboard/constants.dart';
import 'package:biblebookapp/view/screens/onboarding_screen.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../Model/dailyVersesMainListModel.dart';
import '../../../Model/verseBookContentModel.dart';
import '../../../controller/dpProvider.dart';
import '../../constants/images.dart';
import '../../constants/share_preferences.dart';
import '../dashboard/home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();
  final _initializationHelper = InitializationHelper();
  late String selecteDailyVerses;

  int appLaunchCount = 0;
  int appLaunchCountoffer = 0;
  // Platform messages are asynchronous, so we initialize in an async method.

  void showSnack(String text) {
    if (_scaffoldKey.currentContext != null) {
      ScaffoldMessenger.of(_scaffoldKey.currentContext!)
          .showSnackBar(SnackBar(content: Text(text)));
    }
  }

  /// Internet Connectivity checker
  // ConnectivityResult connectionStatus = ConnectivityResult.none;
  // final Connectivity _connectivity = Connectivity();
  // late StreamSubscription<ConnectivityResult> _connectivitySubscription;
  final Connectivity _connectivity = Connectivity();
  late StreamSubscription<List<ConnectivityResult>> _connectivitySubscription;
  var connectionStatus = <ConnectivityResult>[].obs; // Updated to List

  get developer => null;
  Future<void> initConnectivity() async {
    late List<ConnectivityResult> result;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      result = await _connectivity.checkConnectivity();
    } on PlatformException catch (e) {
      developer.log('Couldn\'t check connectivity status', error: e);
      return;
    }

    return _updateConnectionStatus(result);
  }

  Future<void> _updateConnectionStatus(List<ConnectivityResult> result) async {
    connectionStatus.value = result;
  }

  loadOpenAd() async {
    final trackingAllowed = await isTrackingAllowed();
    debugPrint('ad pop loadOpenAd -  ${!trackingAllowed}');
    bool? isAdEnabledFromApi =
        await SharPreferences.getBoolean(SharPreferences.isAdsEnabledApi);
    if (isAdEnabledFromApi ?? true) {
      String? openAdUnitId =
          await SharPreferences.getString(SharPreferences.openAppId);
      AppOpenAd.load(
        adUnitId: openAdUnitId ?? '',
        request: await AdConsentManager.getAdRequest(),
        //orientation: 1,
        adLoadCallback: AppOpenAdLoadCallback(
          onAdLoaded: (ad) {
            ad.show();
          },
          onAdFailedToLoad: (error) {},
        ),
      );
    }
  }

  Future<void> initAppOpen() async {
    await SharPreferences.getString('test').then((value) async {
      if (value != null) {
        await SharPreferences.getString(SharPreferences.isRewardAdViewTime)
            .then((re) {
          if (re != null) {
            DateTime CurrentDateTime = DateTime.now();
            DateTime SaveTime = DateTime.parse(re.toString());
            var diff = CurrentDateTime.difference(SaveTime).inDays;
            log('Diff: $diff');
            if (!diff.isNegative) {
              SharPreferences.setBoolean(SharPreferences.isAdsEnabled, true);
              loadOpenAd();
            } else {
              SharPreferences.setBoolean(SharPreferences.isAdsEnabled, false);
            }
          } else {
            loadOpenAd();
          }
        });
      } else {
        await SharPreferences.setString('test', 'test');
      }
    });
  }

  int saveDay = 9;

  Future<void> _initialize() async {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (Platform.isIOS &&
          await AppTrackingTransparency.trackingAuthorizationStatus ==
              TrackingStatus.notDetermined) {
        await Future.delayed(Duration(seconds: 4));
        if (mounted) {
          await showDialog(
            context: context,
            barrierDismissible: false,
            builder: (context) => const SupportDialogContent(),
          );
        }
      }
      await DashBoardController().loadApi();
      await checkappcount();
      await _initializationHelper.initialize();
      initAppOpen();
      // setTheme();
      initConnectivity();
      _connectivitySubscription =
          _connectivity.onConnectivityChanged.listen(_updateConnectionStatus);

      // loadAd();
      await loadDailyVerseData();
      await loadBookList();
      await loadBookContent();

      await DBHelper().db.then((value) {
        value!
            .rawQuery("SELECT * From book WHERE book_num = ${int.parse("0")}")
            .then((value) async {
          final datafn =
              await SharPreferences.getString(SharPreferences.selectedBook);
          if (datafn == null) {
            final data = value[0]["title"].toString();
            // debugPrint("book name : ${value[0]["title"].toString()} - $data");
            await SharPreferences.setString(SharPreferences.selectedBook, data);
          }
        });
      });
    });
  }

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  checkappcount() async {
    await Provider.of<DownloadProvider>(context, listen: false)
        .requestConsentInfo();
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      appLaunchCount = prefs.getInt('launchCount') ?? 0;
      appLaunchCountoffer = prefs.getInt('launchCountoffer') ?? 0;

      appLaunchCount++;
      appLaunchCountoffer++;

      await prefs.setInt('launchCount', appLaunchCount);
      await prefs.setInt('launchCountoffer', appLaunchCountoffer);
    } catch (e) {
      debugPrint("launchCount error - $e");
    }
  }

  handleNavigation() async {
    final isOnboardingCompleted =
        await SharPreferences.getBoolean(SharPreferences.onboarding);
    if (isOnboardingCompleted == null || !isOnboardingCompleted) {
      await SharPreferences.setBoolean(SharPreferences.onboarding, true);

      Get.offAll(() => const OnboardingScreen());
    } else {
      Future.delayed(
        const Duration(seconds: 3),
        () {
          SharPreferences.setBoolean(SharPreferences.isLoadBookContent, true);
          Get.offAll(() => HomeScreen(
              From: "splash",
              selectedVerseNumForRead: "",
              selectedBookForRead: "",
              selectedChapterForRead: "",
              selectedBookNameForRead: "",
              selectedVerseForRead: ""));
        },
      );
    }
  }

  loadBookContent() async {
    await SharPreferences.getBoolean(SharPreferences.isLoadBookContent)
        .then((value) async {
      if (value == null || !value) {
        // final response =
        //     await rootBundle.loadString('assets/jsonFile/verse_json.json');
        final response = await ExtractZipJson.extractFile(
            AssetsConstants.verseJSONPath, AssetsConstants.versePasswordKey);
        final data = await json.decode(response);
        setState(() {
          versesContent = List.from(data)
              .map<VerseBookContentModel>(
                  (item) => VerseBookContentModel.fromJson(item))
              .toList();
          DBHelper().db.then((value) {
            value!.transaction((txn) async {
              var batch = txn.batch();
              for (int i = 0; i < versesContent.length; i++) {
                var insertData = {
                  "book_num": versesContent[i].bookNum,
                  "chapter_num": versesContent[i].chapterNum,
                  "verse_num": versesContent[i].verseNum,
                  "content": versesContent[i].content,
                  "is_bookmarked": versesContent[i].isBookmarked,
                  "is_highlighted": versesContent[i].isHighlighted,
                  "is_noted": versesContent[i].isNoted,
                  "is_read": versesContent[i].isRead,
                  "is_underlined": versesContent[i].isUnderlined,
                };
                batch.insert('verse', insertData);
              }
              List<Object?> isUpload = await batch.commit();
              if (isUpload.isEmpty) {
              } else {
                print("e");
              }
            });
          }).whenComplete(() async {
            await deleteFiles();
            handleNavigation();
          });
        });
      } else {
        handleNavigation();
      }
    });
  }

  Future<void> deleteFiles() async {
    try {
      // Get the application documents directory
      final directory = await getApplicationDocumentsDirectory();

      // Define file paths
      final file1 = File('${directory.path}/book.json');
      final file2 = File('${directory.path}/verse_json.json');

      // Check and delete file1
      if (await file1.exists()) {
        await file1.delete();
        debugPrint('file1.txt deleted successfully');
      } else {
        debugPrint('file1.txt does not exist');
      }

      // Check and delete file2
      if (await file2.exists()) {
        await file2.delete();
        debugPrint('file2.txt deleted successfully');
      } else {
        debugPrint('file2.txt does not exist');
      }
    } catch (e) {
      debugPrint('Error deleting files: $e');
    }
  }

  loadBookList() async {
    await SharPreferences.getBoolean(SharPreferences.isLoadBookList)
        .then((value) async {
      print("isLoadBookList");
      print(value);
      if (value == null || value == false) {
        // final String response =
        //     await rootBundle.loadString('assets/jsonFile/book.json');
        final String response = await ExtractZipJson.extractFile(
            AssetsConstants.booksJSONPath, AssetsConstants.bookPasswordKey);
        final data = await json.decode(response);
        setState(() {
          bookList = List.from(data)
              .map<MainBookListModel>(
                  (item) => MainBookListModel.fromJson(item))
              .toList();
          DBHelper().db.then((value) {
            value!.transaction((txn) async {
              var batch = txn.batch();
              for (int i = 0; i < bookList.length; i++) {
                var insertData = {
                  "book_num": bookList[i].bookNum,
                  "chapter_count": bookList[i].chapterCount,
                  "title": bookList[i].title,
                  "short_title": bookList[i].shortTitle,
                  "read_per": bookList[i].readPer,
                };
                print(insertData);
                batch.insert('book', insertData);
              }
              List<Object?> isUpload = await batch.commit();
              if (isUpload.isEmpty) {
              } else {
                print("e");
              }
            });
          }).whenComplete(() {
            Future.delayed(
              Duration(milliseconds: 500),
              () {
                SharPreferences.setBoolean(
                    SharPreferences.isLoadBookList, true);
              },
            );
          });
        });
      }
    });
  }

  loadDailyVerseData() async {
    await SharPreferences.getBoolean(SharPreferences.isLoadBookList)
        .then((value) async {
      if (value == null || value == false) {
        final String dailyVerseResponse =
            await rootBundle.loadString('assets/jsonFile/dailyVerse.json');
        final dailyVerseData = await json.decode(dailyVerseResponse);
        setState(() {
          dailyVerseDataList = List.from(dailyVerseData)
              .map<DailyVersesMainListModel>(
                  (item) => DailyVersesMainListModel.fromJson(item))
              .toList();
          DBHelper().db.then((value) {
            value!.transaction((txn) async {
              var batch = txn.batch();
              for (int i = 0; i < dailyVerseDataList.length; i++) {
                var insertData = {
                  "Category_Name": dailyVerseDataList[i].categoryName,
                  "Category_Id": dailyVerseDataList[i].categoryId,
                  "Book": dailyVerseDataList[i].book,
                  "Book_Id": dailyVerseDataList[i].bookId,
                  "Chapter": dailyVerseDataList[i].chapter,
                  "Verse": dailyVerseDataList[i].verse,
                };
                batch.insert('dailyVersesMainList', insertData);
              }
              List<Object?> isUpload = await batch.commit();
              if (isUpload.isEmpty) {
              } else {
                print("e");
              }
            });
          }).whenComplete(() {
            Future.delayed(
              Duration(milliseconds: 500),
              () {
                DBHelper().db.then((dailyVersesMainList) {
                  dailyVersesMainList!
                      .rawQuery("SELECT * From dailyVersesMainList")
                      .then((dailyVersesMainData) async {
                    for (var i = 0; i < 10; i++) {
                      var selectedVersesMainData = DailyVersesMainListModel(
                        verse: dailyVersesMainData[i]["Verse"]
                                    .toString()
                                    .length ==
                                2
                            ? "${int.parse(dailyVersesMainData[i]["Verse"].toString()) - 1}"
                            : "${int.parse(dailyVersesMainData[i]["Verse"].toString().split("-").first) - 1}",
                        book: "${dailyVersesMainData[i]["Book"]}",
                        bookId: int.parse(
                                dailyVersesMainData[i]["Book_Id"].toString()) -
                            1,
                        categoryId: int.parse(
                            dailyVersesMainData[i]["Category_Id"].toString()),
                        categoryName:
                            "${dailyVersesMainData[i]["Category_Name"]}",
                        chapter: int.parse(
                                dailyVersesMainData[i]["Chapter"].toString()) -
                            1,
                      );

                      dailyVersesMainList
                          .rawQuery(
                              "SELECT * From verse WHERE book_num ='${int.parse(selectedVersesMainData.bookId.toString())}' AND chapter_num ='${int.parse(selectedVersesMainData.chapter.toString())}' AND verse_num ='${int.parse(selectedVersesMainData.verse.toString())}'")
                          .then((selectedDailyVersesResponse) async {
                        //    late SharedPreferences _prefs;
                        // print("selectedDailyVersesResponse");
                        // print(selectedDailyVersesResponse);
                        // SharedPreferences prefs =
                        //     await SharedPreferences.getInstance();
                        // List<String> selectedCategories =
                        //     prefs.getStringList('selected_categories') ?? [];

                        // for (int i = 0; i < dailyVersesMainData.length; i++) {
                        //   dynamic categoryName =
                        //       dailyVersesMainData[i]["Category_Name"];

                        //   if (selectedCategories.contains(categoryName)) {
                        //     final bookId = int.parse(
                        //         dailyVersesMainData[i]["Book_Id"].toString());
                        //     final chapter = int.parse(
                        //         dailyVersesMainData[i]["Chapter"].toString());
                        //     final verse = int.parse(
                        //       dailyVersesMainData[i]["Verse"]
                        //               .toString()
                        //               .contains("-")
                        //           ? dailyVersesMainData[i]["Verse"]
                        //               .toString()
                        //               .split("-")
                        //               .first
                        //           : dailyVersesMainData[i]["Verse"].toString(),
                        //     );

                        //     List<Map<String, dynamic>>
                        //         selectedDailyVersesResponse =
                        //         await dailyVersesMainList.rawQuery(
                        //       "SELECT * FROM verse WHERE book_num = '$bookId' AND chapter_num = '$chapter' AND verse_num = '$verse'",
                        //     );

                        //     if (selectedDailyVersesResponse.isNotEmpty) {
                        //       await dailyVersesMainList
                        //           .transaction((txn) async {
                        //         var batch = txn.batch();
                        //         var date = DateTime.now()
                        //             .subtract(Duration(days: saveDay));

                        //         var insertData = {
                        //           "Category_Name": categoryName,
                        //           "Category_Id": dailyVersesMainData[i]
                        //               ["Category_Id"],
                        //           "Book": dailyVersesMainData[i]["Book"],
                        //           "Book_Id": bookId,
                        //           "Chapter": chapter,
                        //           "Verse": selectedDailyVersesResponse[0]
                        //               ["content"],
                        //           "Date": "$date",
                        //           "Verse_Num": verse,
                        //         };

                        //         saveDay = saveDay - 1;

                        //         batch.insert('dailyVersesnew', insertData);
                        //         await batch.commit();
                        //       });
                        //     }
                        //   }
                        // }

                        if (selectedDailyVersesResponse.isNotEmpty) {
                          dailyVersesMainList.transaction((txn) async {
                            var batch = txn.batch();
                            var Date = DateTime.now()
                                .subtract(Duration(days: saveDay));
                            var insertData = {
                              "Category_Name": dailyVersesMainData[i]
                                  ["Category_Name"],
                              "Category_Id": dailyVersesMainData[i]
                                  ["Category_Id"],
                              "Book": dailyVersesMainData[i]["Book"],
                              "Book_Id": dailyVersesMainData[i]["Book_Id"],
                              "Chapter": dailyVersesMainData[i]["Chapter"],
                              "Verse": selectedDailyVersesResponse[0]
                                  ["content"],
                              "Date": "$Date",
                              "Verse_Num": dailyVersesMainData[i]["Verse"]
                                          .toString()
                                          .length ==
                                      2
                                  ? int.parse(dailyVersesMainData[i]["Verse"]
                                      .toString())
                                  : int.parse(dailyVersesMainData[i]["Verse"]
                                      .toString()
                                      .split("-")
                                      .first),
                            };
                            saveDay = saveDay - 1;
                            batch.insert('dailyVerses', insertData);
                            List<Object?> isUpload = await batch.commit();
                            if (isUpload.isEmpty) {
                            } else {
                              print("e");
                            }
                          });
                        }
                      });
                    }
                  });
                }).then((value) {
                  SharPreferences.setString(
                      SharPreferences.selectedDailyVerse, "11");
                  var currentDate = DateTime.now();
                  SharPreferences.setString(
                      SharPreferences.dailyVerseUpdateTime,
                      currentDate.toString());
                });
              },
            );
          });
        });
      } else {
        await SharPreferences.getString(SharPreferences.dailyVerseUpdateTime)
            .then((saveTime) async {
          final saveDateTime = DateTime.parse(saveTime.toString());
          final currentDateTime = DateTime.now();
          final difference = daysBetween(saveDateTime, currentDateTime);
          if (difference >= 1) {
            await SharPreferences.getBoolean(SharPreferences.isLoadBookContent)
                .then((value) async {
              if (value != null || value != false) {
                DBHelper().db.then((dailyVersesMainList) {
                  dailyVersesMainList!
                      .rawQuery("SELECT * From dailyVersesMainList")
                      .then((dailyVersesMainData) async {
                    selecteDailyVerses = await SharPreferences.getString(
                            SharPreferences.selectedDailyVerse) ??
                        "11";
                    var selectedVersesMainData = DailyVersesMainListModel(
                      verse: dailyVersesMainData[int.parse(
                                      selecteDailyVerses.toString())]["Verse"]
                                  .toString()
                                  .length ==
                              2
                          ? "${int.parse(dailyVersesMainData[int.parse(selecteDailyVerses.toString())]["Verse"].toString()) - 1}"
                          : "${int.parse(dailyVersesMainData[int.parse(selecteDailyVerses.toString())]["Verse"].toString().split("-").first) - 1}",
                      book:
                          "${dailyVersesMainData[int.parse(selecteDailyVerses.toString())]["Book"]}",
                      bookId: int.parse(dailyVersesMainData[
                                      int.parse(selecteDailyVerses.toString())]
                                  ["Book_Id"]
                              .toString()) -
                          1,
                      categoryId: int.parse(dailyVersesMainData[
                                  int.parse(selecteDailyVerses.toString())]
                              ["Category_Id"]
                          .toString()),
                      categoryName:
                          "${dailyVersesMainData[int.parse(selecteDailyVerses.toString())]["Category_Name"]}",
                      chapter: int.parse(dailyVersesMainData[
                                      int.parse(selecteDailyVerses.toString())]
                                  ["Chapter"]
                              .toString()) -
                          1,
                    );
                    dailyVersesMainList
                        .rawQuery(
                            "SELECT * From verse WHERE book_num ='${int.parse(selectedVersesMainData.bookId.toString())}' AND chapter_num ='${int.parse(selectedVersesMainData.chapter.toString())}' AND verse_num ='${int.parse(selectedVersesMainData.verse.toString())}'")
                        .then((selectedDailyVersesResponse) {
                      // print("selectedDailyVersesResponse");
                      // print(selectedDailyVersesResponse);
                      if (selectedDailyVersesResponse.isNotEmpty) {
                        dailyVersesMainList.transaction((txn) async {
                          var batch = txn.batch();
                          var Date = DateTime.now();
                          var insertData = {
                            "Category_Name": dailyVersesMainData[
                                    int.parse(selecteDailyVerses.toString())]
                                ["Category_Name"],
                            "Category_Id": dailyVersesMainData[
                                    int.parse(selecteDailyVerses.toString())]
                                ["Category_Id"],
                            "Book": dailyVersesMainData[
                                    int.parse(selecteDailyVerses.toString())]
                                ["Book"],
                            "Book_Id": dailyVersesMainData[
                                    int.parse(selecteDailyVerses.toString())]
                                ["Book_Id"],
                            "Chapter": dailyVersesMainData[
                                    int.parse(selecteDailyVerses.toString())]
                                ["Chapter"],
                            "Verse": selectedDailyVersesResponse[0]["content"],
                            "Date": "$Date",
                            "Verse_Num": dailyVersesMainData[
                                                int.parse(selecteDailyVerses.toString())]
                                            ["Verse"]
                                        .toString()
                                        .length ==
                                    2
                                ? int.parse(dailyVersesMainData[
                                            int.parse(selecteDailyVerses.toString())]
                                        ["Verse"]
                                    .toString())
                                : int.parse(dailyVersesMainData[
                                            int.parse(selecteDailyVerses.toString())]
                                        ["Verse"]
                                    .toString()
                                    .split("-")
                                    .first),
                          };
                          batch.insert('dailyVerses', insertData);
                          List<Object?> isUpload = await batch.commit();
                          if (isUpload.isEmpty) {
                          } else {
                            print("e");
                          }
                        });
                      }
                    });
                  });
                }).then((value) {
                  Future.delayed(
                    Duration(seconds: 1),
                    () {
                      if (kDebugMode) {
                        print(selecteDailyVerses.toString());
                      }
                      SharPreferences.setString(
                          SharPreferences.selectedDailyVerse,
                          "${int.parse(selecteDailyVerses.toString()) + 1}");
                      SharPreferences.setString(
                          SharPreferences.dailyVerseUpdateTime,
                          currentDateTime.toString());
                    },
                  );
                });
              }
            });
          }
        });
      }
    });
  }

  int daysBetween(DateTime from, DateTime to) {
    from = DateTime(from.year, from.month, from.day);
    to = DateTime(to.year, to.month, to.day);
    return (to.difference(from).inHours / 24).round();
  }

  List<MainBookListModel> bookList = [];
  List<DailyVersesMainListModel> dailyVerseDataList = [];
  List<VerseBookContentModel> versesContent = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: Provider.of<ThemeProvider>(context).currentCustomTheme ==
                  AppCustomTheme.vintage
              ? BoxDecoration(
                  // color: Color(0x80605749),
                  image: DecorationImage(
                      image: AssetImage(Images.bgImage(context)),
                      fit: BoxFit.fill))
              : null,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Center(
                child: Image.asset(
                  "assets/Icon-1024.png",
                  height: 220,
                  width: 220,
                ),
              ),
              Positioned(
                  bottom: 50, child: CircularProgressIndicator.adaptive())
            ],
          )),
    );
  }
}

// class SupportDialogContent extends StatelessWidget {
//   const SupportDialogContent({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Dialog(
//       backgroundColor:
//           Colors.transparent, // transparent to simulate grey background
//       child: Container(
//         padding: const EdgeInsets.all(17),
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(20),
//         ),
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Text(
//               BibleInfo.thankyoutitle,
//               style: TextStyle(
//                 fontSize: 22,
//                 color: CommanColor.black,
//                 fontWeight: FontWeight.bold,
//               ),
//               textAlign: TextAlign.center,
//             ),
//             const SizedBox(height: 20),
//             Text(
//               " 📲 To keep this Bible app free, we show a few ads. \n\n ✅ Allowing tracking helps us show ads that match your faith and interests, like Christian books & family tools. \n\n ❌ If you don’t allow, ads will still appear but may be less relevant. \n\n  🔐 We respect your privacy and never share personal data. \n",
//               style: TextStyle(fontSize: 16, color: CommanColor.black),
//               textAlign: TextAlign.left,
//             ),
//             Text(
//               " “Let your light shine before others...” \n          – Matthew 5:16 ",
//               style: TextStyle(
//                 fontSize: 16,
//                 color: CommanColor.black,
//                 fontStyle: FontStyle.italic,
//               ),
//               textAlign: TextAlign.center,
//             ),
//             const SizedBox(height: 24),
//             ElevatedButton(
//               onPressed: () async {
//                 Navigator.of(context).pop();
//                 await AdConsentManager.initAppFlow();
//               },
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: CommanColor.darkPrimaryColor,
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(30),
//                 ),
//                 padding:
//                     const EdgeInsets.symmetric(horizontal: 50, vertical: 12),
//               ),
//               child: const Text(
//                 'Allow Personalized Ads',
//                 style: TextStyle(fontSize: 18, color: CommanColor.white),
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }

class SupportDialogContent extends StatelessWidget {
  const SupportDialogContent({super.key});

  double getResponsiveFontSize(BuildContext context, double baseSize) {
    final width = MediaQuery.of(context).size.width;

    if (width < 380) {
      // Small phones
      return 14.2;
    } else if (width < 480) {
      // Medium phones
      return baseSize;
    } else {
      // Large phones and tablets
      return baseSize * 1.15;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(17),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              BibleInfo.thankyoutitle,
              style: TextStyle(
                fontSize: getResponsiveFontSize(context, 22),
                color: CommanColor.black,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            Text(
              " 📲 To keep this Bible app free, we show a few ads. \n\n ✅ Allowing tracking helps us show ads that match your faith and interests, like Christian books & family tools. \n\n ❌ If you don’t allow, ads will still appear but may be less relevant. \n\n  🔐 We respect your privacy and never share personal data. \n",
              style: TextStyle(
                fontSize: getResponsiveFontSize(context, 16),
                color: CommanColor.black,
              ),
              textAlign: TextAlign.left,
            ),
            Text(
              " “Let your light shine before others...” \n          – Matthew 5:16 ",
              style: TextStyle(
                fontSize: getResponsiveFontSize(context, 16),
                color: CommanColor.black,
                fontStyle: FontStyle.italic,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 15),
            ElevatedButton(
              onPressed: () async {
                Navigator.of(context).pop();
                await AdConsentManager.initAppFlow();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: CommanColor.darkPrimaryColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 50, vertical: 9),
              ),
              child: Text(
                'Continue',
                style: TextStyle(
                  fontSize: getResponsiveFontSize(context, 15),
                  color: CommanColor.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AdConsentManager {
  static bool _canRequestAds = false;
  static bool _privacyOptionsRequired = false;

  /// Main initialization flow (call this first)
  static Future<bool> initAppFlow() async {
    try {
      await _handleConsentFlow();
      await _initializeAdNetworks();
      return _canRequestAds;
    } catch (e) {
      debugPrint('Ad init failed: $e');
      return false;
    }
  }

  /// Handles both UMP consent and ATT (iOS)
  static Future<void> _handleConsentFlow() async {
    // 1. First check TC String and Purpose 1 consent
    final consentStatus = await ConsentInformation.instance.getConsentStatus();
    if (consentStatus != ConsentStatus.obtained) {
      _canRequestAds = false;
    }

    // 2. iOS ATT (only if UMP consent is obtained)
    if (Platform.isIOS) {
      try {
        final status =
            await AppTrackingTransparency.requestTrackingAuthorization();
        debugPrint('ATT Status: $status');
      } on PlatformException catch (e) {
        debugPrint('ATT Error: ${e.message}');
      }
    }

    // 3. Update UMP consent status
    final params = ConsentRequestParameters();
    ConsentInformation.instance.requestConsentInfoUpdate(
      params,
      () async {
        _canRequestAds = await ConsentInformation.instance.canRequestAds();
        _privacyOptionsRequired = await _isPrivacyOptionsRequired();
        await Future.delayed(Duration(seconds: 4));
        if (!_canRequestAds) {
          final success = await _loadAndShowConsentForm();
          if (success) {
            _canRequestAds = await ConsentInformation.instance.canRequestAds();
          }
        }
      },
      (FormError error) => throw Exception("Consent error: ${error.message}"),
    );
  }

  /// Loads and shows consent form if required
  static Future<bool> _loadAndShowConsentForm() async {
    try {
      await ConsentForm.loadAndShowConsentFormIfRequired((error) {
        if (error != null) throw Exception("Form error: ${error.message}");
      });
      return true;
    } catch (e) {
      debugPrint('Consent form failed: $e');
      return false;
    }
  }

  /// Checks if privacy options form is required
  static Future<bool> _isPrivacyOptionsRequired() async {
    return await ConsentInformation.instance
            .getPrivacyOptionsRequirementStatus() ==
        PrivacyOptionsRequirementStatus.required;
  }

  /// Shows privacy options form
  static Future<void> showPrivacyOptionsForm() async {
    try {
      await ConsentForm.showPrivacyOptionsForm((error) {
        if (error != null) {
          throw Exception("Privacy form error: ${error.message}");
        }
      });
    } catch (e) {
      debugPrint('Privacy form failed: $e');
    }
  }

  /// Initializes ad networks with proper configuration
  static Future<void> _initializeAdNetworks() async {
    await MobileAds.instance.initialize();

    MobileAds.instance.updateRequestConfiguration(
      RequestConfiguration(
        tagForChildDirectedTreatment: TagForChildDirectedTreatment.unspecified,
        tagForUnderAgeOfConsent: TagForUnderAgeOfConsent.unspecified,
        maxAdContentRating: MaxAdContentRating.g,
      ),
    );
  }

  /// Generates AdRequest with proper consent settings
  /// Always returns an AdRequest (fallback to non-personalized if needed)
  static Future<AdRequest> getAdRequest() async {
    try {
      // 1. Check if we have valid consent for at least non-personalized ads
      final hasConsent = await _checkBasicConsent();
      if (!hasConsent) {
        debugPrint('No valid consent - using fallback NPA');
        return _createNonPersonalizedRequest();
      }

      // 2. Check if personalized ads are allowed
      final trackingAllowed = _canRequestAds &&
          (Platform.isAndroid ||
              await AppTrackingTransparency.trackingAuthorizationStatus ==
                  TrackingStatus.authorized);

      debugPrint('Personalized ads allowed: $trackingAllowed');

      return trackingAllowed
          ? AdRequest() // Personalized
          : _createNonPersonalizedRequest(); // NPA
    } catch (e) {
      debugPrint("AdRequest error: $e - using fallback NPA");
      return _createNonPersonalizedRequest();
    }
  }

  /// Checks if we have minimum consent for non-personalized ads
  static Future<bool> _checkBasicConsent() async {
    final status = await ConsentInformation.instance.getConsentStatus();
    return status == ConsentStatus.obtained;
  }

  /// Creates a compliant non-personalized ad request
  static AdRequest _createNonPersonalizedRequest() {
    return AdRequest(
      nonPersonalizedAds: true,
      keywords: _getNonPersonalizedKeywords(),
    );
  }

  /// Keywords for non-personalized ads
  static List<String> _getNonPersonalizedKeywords() => [
        'bible',
        'christian',
        'faith',
        'prayer',
        'church',
        'devotional',
        'scripture'
      ];
}
