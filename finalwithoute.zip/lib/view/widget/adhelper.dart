// import 'package:google_mobile_ads/google_mobile_ads.dart';

// class InterstitialAdHelper {
//   static final InterstitialAdHelper _instance =
//       InterstitialAdHelper._internal();
//   factory InterstitialAdHelper() => _instance;

//   InterstitialAdHelper._internal();

//   InterstitialAd? _interstitialAd;
//   bool _isAdLoaded = false;

//   /// Load Interstitial Ad
//   void loadAd({required Function onAdLoaded, Function? onAdFailed}) {
//     InterstitialAd.load(
//       adUnitId:
//           'ca-app-pub-3940256099942544/1033173712', // Replace with your real AdMob ID in production
//       request: const AdRequest(),
//       adLoadCallback: InterstitialAdLoadCallback(
//         onAdLoaded: (InterstitialAd ad) {
//           _interstitialAd = ad;
//           _isAdLoaded = true;
//           onAdLoaded(); // Notify UI
//         },
//         onAdFailedToLoad: (LoadAdError error) {
//           print('InterstitialAd failed to load: $error');
//           _isAdLoaded = false;
//           if (onAdFailed != null) onAdFailed();
//         },
//       ),
//     );
//   }

//   /// Show Interstitial Ad
//   void showAd({required Function onAdClosed}) {
//     if (_isAdLoaded && _interstitialAd != null) {
//       _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
//         onAdDismissedFullScreenContent: (ad) {
//           ad.dispose();
//           _isAdLoaded = false;
//           loadAd(onAdLoaded: () {}); // Preload the next ad
//           onAdClosed(); // Notify UI
//         },
//         onAdFailedToShowFullScreenContent: (ad, error) {
//           print('Failed to show interstitial ad: $error');
//           ad.dispose();
//           _isAdLoaded = false;
//           loadAd(onAdLoaded: () {}); // Preload the next ad
//         },
//       );
//       _interstitialAd!.show();
//     } else {
//       print('Ad is not ready yet');
//       onAdClosed(); // Proceed without ad if it's not available
//     }
//   }
// }

import 'package:biblebookapp/view/constants/constant.dart';
import 'package:biblebookapp/view/constants/share_preferences.dart';
import 'package:biblebookapp/view/screens/auth/splash.dart';
import 'package:biblebookapp/view/screens/dashboard/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class RewardedAdService {
  static RewardedAd? _rewardedAd;
  static bool _isAdLoaded = false;

  static Future<void> loadAd({required VoidCallback onAdLoaded}) async {
    final trackingAllowed = await isTrackingAllowed();
    debugPrint('ad pop RewardedAdService -  ${!trackingAllowed}');
    String? adUnitId =
        await SharPreferences.getString(SharPreferences.rewardedAd);
    RewardedAd.load(
      adUnitId: adUnitId.toString(), // Test Ad Unit
      request: await AdConsentManager.getAdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (RewardedAd ad) {
          _rewardedAd = ad;
          _isAdLoaded = true;
          onAdLoaded();
        },
        onAdFailedToLoad: (LoadAdError error) {
          debugPrint('RewardedAd failed to load: $error');

          _isAdLoaded = false;
        },
      ),
    );
  }

  static void showAd({
    required VoidCallback onRewardEarned,
    required VoidCallback onAdDismissed,
  }) {
    if (_isAdLoaded && _rewardedAd != null) {
      _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) async {
          ad.dispose();
          _isAdLoaded = false;
          await SharPreferences.setString('OpenAd', '1');
          onAdDismissed();
        },
        onAdFailedToShowFullScreenContent: (ad, error) {
          // DebugConsole.log('rewardedAd show Ad error1: ${error.message} - $ad');
          ad.dispose();
          _isAdLoaded = false;
          onAdDismissed();
        },
      );

      _rewardedAd!.show(
        onUserEarnedReward: (AdWithoutView ad, RewardItem reward) async {
          onRewardEarned();
          await SharPreferences.setString('OpenAd', '1');
        },
      );
    } else {
      Constants.showToast("Ad not available.");
      debugPrint('RewardedAd not ready');
    }
  }
}
