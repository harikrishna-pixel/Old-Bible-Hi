import 'dart:convert';

import 'package:biblebookapp/Model/product_details_model.dart';
import 'package:biblebookapp/controller/dashboard_controller.dart';
import 'package:biblebookapp/core/notifiers/cache.notifier.dart';
import 'package:biblebookapp/utils/custom_alert.dart';
import 'package:biblebookapp/view/constants/share_preferences.dart';
import 'package:biblebookapp/view/screens/auth/splash.dart';
import 'package:biblebookapp/view/screens/dashboard/constants.dart';
import 'package:biblebookapp/view/screens/dashboard/home_screen.dart';
import 'package:biblebookapp/view/widget/home_content_edit_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DownloadProvider with ChangeNotifier {
  DownloadProvider() {
    _loadShownStatus();

    DashBoardController().loadApi();
    debugPrint(" Api is called now ");
  }

  static const String _key = 'appCount';
  int _appCount = 100;
  final int _appCountper = 0;

  int get appCount => _appCount;

  bool _adEnabled = false;
  int _adCount = 0;

  int get adCount => _adCount;

  InterstitialAd? _interstitialAd;

  bool get adEnabled => _adEnabled;

// count for one time
  int _bookmarkCount = 0;
  bool _hasShown = false;

  bool get hasShown => _hasShown;

  // ad
  static const _pdkey = 'product_details_list';

  // Save list of ProductDetails
  Future<void> saveProductList(List<ProductDetails> products) async {
    final prefs = await SharedPreferences.getInstance();
    final List<String> jsonList =
        products.map((product) => jsonEncode(product.toJson())).toList();
    await prefs.setStringList(_pdkey, jsonList);
  }

// download limit
  int clickCount = 0;
  bool isAdReady = false;

  Future<void> requestConsentInfo() async {
    final params = ConsentRequestParameters();
    final consentInfo = ConsentInformation.instance;

    consentInfo.requestConsentInfoUpdate(
      params,
      () async {
        // Consent info updated successfully.
        await loadAndShowConsentFormIfRequired();
      },
      (FormError error) {
        // Handle the error.
        debugPrint('Consent info update failed: ${error.message}');
      },
    );
  }

  Future<void> loadAndShowConsentFormIfRequired() async {
    await ConsentForm.loadAndShowConsentFormIfRequired(
      (FormError? formError) {
        if (formError != null) {
          // Handle the error.
          debugPrint('Consent form load/show failed: ${formError.message}');
        } else {
          // Consent form was shown successfully.
          debugPrint('Consent form displayed.');
        }
      },
    );
  }

  void _loadShownStatus() async {
    final prefs = await SharedPreferences.getInstance();
    _hasShown = prefs.getBool('hasShownAlert') ?? false;
    notifyListeners();
  }

  void incrementBookmarkCount(BuildContext context) async {
    if (_hasShown) return;
    CacheNotifier cacheNotifier = CacheNotifier();
    final data = await cacheNotifier.readCache(key: 'user');

    if (data == null) {
      _bookmarkCount++;

      if (_bookmarkCount >= BibleInfo.appcount) {
        _bookmarkCount = 0;
        if (context.mounted) {
          // Show Alert
          showDialog(
            context: context,
            builder: (_) => const BibleAlertBox(),
          );
        }

        final prefs = await SharedPreferences.getInstance();
        await prefs.setBool('hasShownAlert', true);
        _hasShown = true;
        notifyListeners();
      }
    }
  }

  // Future<void> checkConsentAndLoadAds() async {
  //   final consentInfo = ConsentInformation.instance;
  //   final canRequestAds = await consentInfo.canRequestAds();

  //   if (canRequestAds) {
  //     // Load and display ads.
  //   } else {
  //     // Do not load ads.
  //     print('Cannot request ads without user consent.');
  //   }
  // }

  Future handleDownloadClick(BuildContext context) async {
    // final data = await SharPreferences.getString(SharPreferences.offerenabled);
    final adEnable =
        await SharPreferences.getBoolean(SharPreferences.isAdsEnabledApi);
    final checkDownload = await SharPreferences.getBoolean("downloadreward");
    final adEnable2 = await SharPreferences.shouldLoadAd();
    final subEnable = await SharPreferences.getBoolean('isSubscriptionEnabled');

    debugPrint(
        "offer enabled 0 or - ad $adEnable - $adEnable2 & sub $subEnable  ");

    final clickcountcachefn =
        await SharPreferences.getInt('downloadrewardcount');

    if (clickcountcachefn != null) {
      clickCount = clickcountcachefn;
    }

    if (subEnable!) {
      if (adEnable2) {
        clickCount++;
        await SharPreferences.setInt("downloadrewardcount", clickCount);

        final clickcountcache =
            await SharPreferences.getInt('downloadrewardcount');
        debugPrint(
            "offer enabled 1 or - ad $adEnable - $adEnable2 & sub $subEnable  click count - $clickcountcache");
        if (clickcountcache == 4) {
          await setDownloadReward();
          // showLimitDialog(context);
          return true;
        } else if (!checkDownload!) {
          clickCount = 3;
          await SharPreferences.setInt("downloadrewardcount", clickCount);
          return false;
        }
      } else {
        clickCount = 3;
        await SharPreferences.setBoolean("downloadreward", true);
        await SharPreferences.setInt("downloadrewardcount", clickCount);
        return false;
      }
    } else {
      clickCount = 3;
      await SharPreferences.setBoolean("downloadreward", true);
      await SharPreferences.setInt("downloadrewardcount", clickCount);
      return false;
    }

    notifyListeners();
    return false;
  }

  Future<void> setDownloadReward() async {
    await SharPreferences.setBoolean("downloadreward", false);
    clickCount = 0;
    await SharPreferences.setInt("downloadrewardcount", clickCount);
    notifyListeners();
  }

  // Load list of ProductDetails
  Future<List<ProductDetails>> loadProductList() async {
    final prefs = await SharedPreferences.getInstance();
    final List<String>? jsonList = prefs.getStringList(_pdkey);
    if (jsonList == null) return [];

    return jsonList
        .map((jsonStr) => ProductDetails.fromJson(
            jsonDecode(jsonStr) as Map<String, dynamic>))
        .toList();
  }

  // Optional: clear stored products
  Future<void> clearProductList() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_pdkey);
  }

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _adEnabled = await shouldLoadAd();
    _adCount = int.tryParse(prefs.getString('showinterstitialo') ?? '0') ?? 0;
    notifyListeners();
  }

  Future<bool> shouldLoadAd() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('ad_enabled') ?? true;
  }

  Future<void> checkAndShowAd(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    final prefsadcount =
        await SharPreferences.getString(SharPreferences.showinterstitialrow) ??
            "0";

    final data = prefs.getString('showinterstitialo') ?? '0';

    _adCount = int.tryParse(data) ?? 0;

    _adEnabled = await shouldLoadAd();
    final adcount = int.tryParse(prefsadcount) ?? 0;
    debugPrint(" ad check $_adCount  & $adcount  ");
    if (_adEnabled && _adCount % adcount == 0) {
      EasyLoading.showInfo('Please wait...');
      await Future.delayed(const Duration(seconds: 2));
      if (context.mounted) {
        _loadAndShowInterstitialAd(context);
      }
      EasyLoading.dismiss();
      // Reset counter after showing ad
      _adCount = 0;
    }
  }

  Future<void> updateAdCount(int newCount) async {
    final prefs = await SharedPreferences.getInstance();
    _adCount = newCount;
    await prefs.setString('showinterstitialo', _adCount.toString());
  }

  void _loadAndShowInterstitialAd(BuildContext context) async {
    final trackingAllowed = await isTrackingAllowed();
    debugPrint('ad pop InterstitialAd -  ${!trackingAllowed}');
    String? adUnitId =
        await SharPreferences.getString(SharPreferences.googleInterstitialAd);
    InterstitialAd.load(
      adUnitId: adUnitId.toString(),
      request: await AdConsentManager.getAdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (InterstitialAd ad) async {
          _interstitialAd = ad;
          _interstitialAd?.show();
          await SharPreferences.setString('OpenAd', '1');
          _interstitialAd?.fullScreenContentCallback =
              FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) async {
              await SharPreferences.setString('OpenAd', '1');
              ad.dispose();
            },
            onAdFailedToShowFullScreenContent: (ad, error) {
              ad.dispose();
            },
          );
        },
        onAdFailedToLoad: (LoadAdError error) {
          debugPrint('InterstitialAd failed to load: $error');
        },
      ),
    );
  }

  /// download

  Future<void> _loadAppCount() async {
    final data = await SharPreferences.getInt(SharPreferences.offercount);
    //  await SharPreferences.setInt("offercountper", data ?? 0);
    //final data2 = await SharPreferences.getInt("offercountper");
    final prefs = await SharedPreferences.getInstance();
    //await prefs.setInt(_key, data ?? 10);
    _appCount = prefs.getInt(_key) ?? data ?? 10;
    debugPrint(" offer count is api $_appCount  $data");
    notifyListeners();
  }

  Future<void> _saveAppCount() async {
    final prefs = await SharedPreferences.getInstance();
    debugPrint(" offer count is $_appCount ");
    await prefs.setInt(_key, _appCount);
  }

  Future decrementCount(BuildContext context) async {
    await _loadAppCount();
    if (_appCount > 0) {
      _appCount--;
      _saveAppCount();
      notifyListeners();
      final data =
          await SharPreferences.getString(SharPreferences.offerenabled) ?? '';
      final adenable =
          await SharPreferences.getBoolean(SharPreferences.isAdsEnabledApi) ??
              true;
      final subenable =
          await SharPreferences.getBoolean('isSubscriptionEnabled') ?? true;
      // await Future.delayed(Duration(seconds: 1));
      debugPrint("offer enabled or - $_appCount $data $adenable $subenable");
      if (subenable) {
        debugPrint("sub enabled or - $subenable");
        if (data == '1') {
          if (adenable) {
            if (_appCount == 0) {
              if (context.mounted) {
                Navigator.of(context).pop();
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (_) => const PremiumAccessDialog(),
                );
              }
            }
          } else {
            resetCount();
          }
        } else {
          resetCount();
        }
      } else {
        resetCount();
      }
    } else {
      resetCount();
    }
  }

  Future<void> resetCount() async {
    final data = await SharPreferences.getInt(SharPreferences.offercount) ?? 20;
    _appCount = data;
    await _saveAppCount();
    notifyListeners();
  }
}
