import 'package:biblebookapp/view/constants/colors.dart';
import 'package:biblebookapp/view/screens/authenitcation/view/signup_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BibleAlertBox extends StatelessWidget {
  const BibleAlertBox({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    // Responsive sizes
    final titleFontSize = screenWidth < 380
        ? 17.0
        : screenWidth > 450
            ? 26.0
            : 20.0;

    final subtitleFontSize = screenWidth < 380
        ? 14.0
        : screenWidth > 450
            ? 18.0
            : 16.0;

    final iconSize = screenWidth < 380
        ? 20.0
        : screenWidth > 450
            ? 30.0
            : 25.0;

    final progressSize = screenWidth < 380
        ? 120.0
        : screenWidth > 450
            ? 160.0
            : 145.0;

    final buttonHeight = screenWidth < 380
        ? 40.0
        : screenWidth > 450
            ? 55.0
            : 48.0;

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: screenWidth < 600 ? screenWidth * 0.9 : 420,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: () async {
                      Get.back();

                      // Navigator.of(context).pushAndRemoveUntil(
                      //     MaterialPageRoute(builder: (context) {
                      //   return HomeScreen(
                      //       From: "splash",
                      //       selectedVerseNumForRead: "",
                      //       selectedBookForRead: "",
                      //       selectedChapterForRead: "",
                      //       selectedBookNameForRead: "",
                      //       selectedVerseForRead: "");
                      // }), (v) => false);
                    },
                    child: Icon(
                      Icons.close,
                      size: 25,
                      color: CommanColor.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Text(
                'Unlock Your Bible Journey! \n Sign in Now!',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: titleFontSize, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Text(
                'Want to keep track of your spiritual journey?',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: subtitleFontSize),
              ),
              const SizedBox(height: 15),

              BibleProgressCircle(
                progressSize: progressSize,
                fontSize: subtitleFontSize,
              ),
              // Stack(
              //   alignment: Alignment.center,
              //   children: [
              //     SizedBox(
              //       width: progressSize,
              //       height: progressSize,
              //       child: CircularProgressIndicator(
              //         value: 0.58,
              //         strokeWidth: 6,
              //         backgroundColor: Colors.brown.shade100,
              //         valueColor: AlwaysStoppedAnimation<Color>(Colors.brown),
              //       ),
              //     ),
              //     Text(
              //       '58%\nBible\nCompleted',
              //       textAlign: TextAlign.center,
              //       style: TextStyle(
              //           fontSize: subtitleFontSize,
              //           fontWeight: FontWeight.bold),
              //     ),
              //   ],
              // ),
              const SizedBox(height: 15),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildIconText(Icons.check, 'Save your reading progress',
                      iconSize, context),
                  _buildIconText(
                      Icons.bookmark,
                      'View all your bookmarks & highlights',
                      iconSize,
                      context),
                  _buildIconText(
                      Icons.pie_chart,
                      'See how much of the Bible you\'ve completed',
                      iconSize,
                      context),
                  _buildIconText(Icons.cloud_done,
                      'Get easy backup across devices', iconSize, context),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Don\'t lose your progress – Sign in and keep growing!',
                style: TextStyle(
                  fontStyle: FontStyle.italic,
                  fontSize: subtitleFontSize - 2,
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: buttonHeight,
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.brown,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                    Get.to(() => SignupScreen());
                  },
                  child: const Text(
                    'Continue',
                    style: TextStyle(color: CommanColor.white, fontSize: 19),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIconText(IconData icon, String text, double iconSize, context) {
    final screenWidth = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: iconSize, color: Colors.brown),
          const SizedBox(width: 10),
          Expanded(
              child: Text(
            text,
            style: TextStyle(
                fontSize: screenWidth < 380
                    ? 14.0
                    : screenWidth > 450
                        ? 18.0
                        : 16.0),
          )),
        ],
      ),
    );
  }
}

class BibleProgressCircle extends StatelessWidget {
  final double progressSize;
  final double fontSize;

  const BibleProgressCircle({
    super.key,
    required this.progressSize,
    required this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: progressSize,
      height: progressSize,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Background Image
          Image.asset(
            'assets/progr2.png', // ✅ ensure this path is correct
            width: progressSize,
            height: progressSize,
            fit: BoxFit.contain,
          ),

          // Center Text
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '5%',
                style: TextStyle(
                  fontSize: fontSize + 2,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Text(
                'Bible\nCompleted',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: fontSize - 2,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
